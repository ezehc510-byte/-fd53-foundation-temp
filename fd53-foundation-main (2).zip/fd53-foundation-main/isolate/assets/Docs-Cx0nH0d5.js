import{j as e}from"./framer-motion-CuQQxZAe.js";import{r as y}from"./react-vendor-CpNMDODO.js";import{u as f,a as b,C as a}from"./ui-DGR1H1rM.js";import{B as l}from"./badge-BaksHxLI.js";import{x as j,L as k,T as w,y as N}from"./radix-ui-BNdemzGv.js";import{c as d,a as c,L as P}from"./index-DVKLb9oz.js";import{a as T}from"./fd53-D4zzsyNw.js";import{B as S}from"./boxes-o71tMFS_.js";import{D as A}from"./database-BDLcuDiv.js";import{H as I}from"./hard-drive-BS5dUqxE.js";import{R as C}from"./radio--Eh-SzVZ.js";import{S as _}from"./shield-check-DBW_6CvL.js";import"./charts-a2yfpWfl.js";const E=[["path",{d:"M8 3H7a2 2 0 0 0-2 2v5a2 2 0 0 1-2 2 2 2 0 0 1 2 2v5c0 1.1.9 2 2 2h1",key:"ezmyqa"}],["path",{d:"M16 21h1a2 2 0 0 0 2-2v-5c0-1.1.9-2 2-2a2 2 0 0 1-2-2V5a2 2 0 0 0-2-2h-1",key:"e1hn23"}]],O=d("braces",E);const F=[["path",{d:"M4 12.15V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.706.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2h-3.35",key:"1wthlu"}],["path",{d:"M14 2v5a1 1 0 0 0 1 1h5",key:"wfsgrz"}],["path",{d:"m5 16-3 3 3 3",key:"331omg"}],["path",{d:"m9 22 3-3-3-3",key:"lsp7cz"}]],R=d("file-code-corner",F);const H=[["path",{d:"M16 10a4 4 0 0 1-8 0",key:"1ltviw"}],["path",{d:"M3.103 6.034h17.794",key:"awc11p"}],["path",{d:"M3.4 5.467a2 2 0 0 0-.4 1.2V20a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6.667a2 2 0 0 0-.4-1.2l-2-2.667A2 2 0 0 0 17 2H7a2 2 0 0 0-1.6.8z",key:"o988cm"}]],q=d("shopping-bag",H);const D=[["rect",{width:"14",height:"20",x:"5",y:"2",rx:"2",ry:"2",key:"1yt0o3"}],["path",{d:"M12 18h.01",key:"mhygvu"}]],B=d("smartphone",D);function K({className:o,...i}){return e.jsx(j,{"data-slot":"tabs",className:c("flex flex-col gap-2",o),...i})}function L({className:o,...i}){return e.jsx(k,{"data-slot":"tabs-list",className:c("bg-muted text-muted-foreground inline-flex h-9 w-fit items-center justify-center rounded-lg p-[3px]",o),...i})}function X({className:o,...i}){return e.jsx(w,{"data-slot":"tabs-trigger",className:c("data-[state=active]:bg-background dark:data-[state=active]:text-foreground focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:outline-ring dark:data-[state=active]:border-input dark:data-[state=active]:bg-input/30 text-foreground dark:text-muted-foreground inline-flex h-[calc(100%-1px)] flex-1 items-center justify-center gap-1.5 rounded-md border border-transparent px-2 py-1 text-sm font-medium whitespace-nowrap transition-[color,box-shadow] focus-visible:ring-[3px] focus-visible:outline-1 disabled:pointer-events-none disabled:opacity-50 data-[state=active]:shadow-sm [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4",o),...i})}function n({className:o,...i}){return e.jsx(N,{"data-slot":"tabs-content",className:c("flex-1 outline-none",o),...i})}const U=[{value:"quickstart",label:"Quickstart",icon:S},{value:"openapi",label:"OpenAPI",icon:R},{value:"auth",label:"Auth",icon:P},{value:"database",label:"Database",icon:A},{value:"storage",label:"Storage",icon:I},{value:"realtime",label:"Realtime",icon:C},{value:"loopuni",label:"LoopUni",icon:q},{value:"flutterflow",label:"FlutterFlow",icon:B},{value:"architecture",label:"Architecture",icon:O},{value:"security",label:"Security",icon:_}];function s({method:o,path:i,description:p}){const t=o==="GET"?"text-chart-3":o==="POST"?"text-chart-1":o==="DELETE"?"text-destructive":"text-chart-2";return e.jsxs("div",{className:"flex flex-col gap-1 border-b border-border py-2.5 last:border-0 sm:flex-row sm:items-baseline sm:gap-3",children:[e.jsx("code",{className:`shrink-0 font-mono text-xs font-semibold ${t}`,children:o}),e.jsx("code",{className:"font-mono text-xs text-muted-foreground",children:i}),e.jsx("span",{className:"text-sm text-muted-foreground",children:p})]})}function ae(){const{projectId:o}=f(),[i,p]=y.useState("quickstart"),t=T(),h=!!o,m=`curl -X POST ${t}/v1/auth/register \\
  -H "X-API-Key: fd53_live_…" \\
  -H "Content-Type: application/json" \\
  -d '{"email":"sam@example.com","password":"correct-horse","name":"Sam"}'`,u=`curl -X POST ${t}/v1/auth/login \\
  -H "X-API-Key: fd53_live_…" \\
  -H "Content-Type: application/json" \\
  -d '{"email":"sam@example.com","password":"correct-horse"}'`,x=`curl ${t}/v1/auth/me \\
  -H "X-API-Key: fd53_live_…" \\
  -H "Authorization: Bearer <token from login>"`,g=["# 1. Register — get a token and a @handle",`curl -X POST ${t}/v1/auth/register \\`,'  -H "X-API-Key: fd53_live_…" -H "Content-Type: application/json" \\',`  -d '{"email":"sam@example.com","password":"correct-horse","username":"sam"}'`,"","# 2. Upload a photo to the post-media bucket",`curl -X POST "${t}/v1/storage/upload?bucket=post-media" \\`,'  -H "X-API-Key: fd53_live_…" -H "Content-Type: application/json" \\',`  -d '{"path":"posts/1.png","mimeType":"image/png","contentBase64":"iVBORw0..."}'`,"","# 3. Create the post",`curl -X POST ${t}/v1/posts/create \\`,'  -H "X-API-Key: fd53_live_…" \\','  -H "Authorization: Bearer <token>" -H "Content-Type: application/json" \\',`  -d '{"text":"hello #launch","media":[{"fileId":"<id>","kind":"image","width":1080,"height":1920}]}'`].join(`
`),v=["# Follow by @handle",`curl -X POST ${t}/v1/users/sam/follow \\`,'  -H "X-API-Key: fd53_live_…" -H "Authorization: Bearer <token>"',"","# Sell a digital product — the asset must live in the private receipts bucket",`curl -X POST "${t}/v1/storage/upload?bucket=receipts" \\`,'  -H "X-API-Key: fd53_live_…" -H "Content-Type: application/json" \\',`  -d '{"path":"assets/course.pdf","mimeType":"application/pdf","contentBase64":"JVBER..."}'`,"",`curl -X POST ${t}/v1/marketplace/products \\`,'  -H "X-API-Key: fd53_live_…" -H "Authorization: Bearer <seller token>" \\','  -H "Content-Type: application/json" \\',`  -d '{"title":"Masterclass","priceCents":4999,"assetFileId":"<id>"}'`,"","# Buy it",`curl -X POST ${t}/v1/marketplace/orders/checkout \\`,'  -H "X-API-Key: fd53_live_…" -H "Authorization: Bearer <buyer token>" \\','  -H "Content-Type: application/json" \\',`  -d '{"productId":"<id>","quantity":2}'`].join(`
`);return e.jsxs("div",{className:"space-y-6",children:[e.jsx(b,{title:"API documentation",description:`Everything your app talks to. Base URL: ${t}`}),e.jsxs(K,{value:i,onValueChange:p,children:[e.jsx(L,{className:"flex h-auto flex-wrap justify-start gap-1",children:U.map(r=>e.jsxs(X,{value:r.value,className:"cursor-pointer",children:[e.jsx(r.icon,{className:"size-3.5"}),r.label]},r.value))}),e.jsxs(n,{value:"quickstart",className:"mt-6 space-y-6",children:[e.jsxs("section",{className:"space-y-3",children:[e.jsx("h2",{className:"tracking-tight font-bold",children:"1 · Get a key"}),e.jsx("p",{className:"text-sm text-muted-foreground",children:"Create a project, then a key on the API Keys page. Keys are shown once and stored as a SHA-256 hash."})]}),e.jsxs("section",{className:"space-y-3",children:[e.jsx("h2",{className:"tracking-tight font-bold",children:"2 · Call the API"}),e.jsxs("p",{className:"text-sm text-muted-foreground",children:["Every ",e.jsx("code",{className:"font-mono",children:"/v1"})," endpoint needs the key in the ",e.jsx("code",{className:"font-mono",children:"X-API-Key"})," header (or as a bearer token). End-user tokens go in"," ",e.jsx("code",{className:"font-mono",children:"Authorization: Bearer"})," instead."]}),e.jsx(a,{code:`curl ${t}/v1/health   # no key needed

curl ${t}/v1/db/tables \\
  -H "X-API-Key: fd53_live_…"`})]}),e.jsxs("section",{className:"space-y-3",children:[e.jsx("h2",{className:"tracking-tight font-bold",children:"3 · Response envelope"}),e.jsx(a,{language:"json",code:`{
  "ok": true,
  "data": { "…": "endpoint specific" }
}

// errors
{
  "ok": false,
  "error": { "code": "invalid_row", "message": "\\"views\\" must be a finite number." }
}`}),e.jsxs("p",{className:"text-sm text-muted-foreground",children:["Status codes: 2xx success · 400 invalid request · 401 missing/invalid key or token · 403 permission denied · 404 not found · 413 too large / quota · 429 rate limited (with ",e.jsx("code",{className:"font-mono",children:"Retry-After"}),") · 500 internal."]})]}),h?null:e.jsx("p",{className:"rounded-md border border-chart-2/40 bg-chart-2/10 px-3 py-2 text-sm",children:"Create a project first — the console pages below need one."})]}),e.jsxs(n,{value:"openapi",className:"mt-6 space-y-5",children:[e.jsx("p",{className:"text-sm text-muted-foreground",children:"FD53 publishes an OpenAPI 3.1 specification covering every endpoint. It is generated from the live route table, so it can never drift from what the API actually serves. Point Swagger UI, Postman, FlutterFlow's API importer, or any SDK generator at the URL below."}),e.jsxs("section",{className:"space-y-2",children:[e.jsx("h3",{className:"font-semibold",children:"Specification endpoint"}),e.jsx(a,{language:"text",code:`${t}/v1/openapi.json`}),e.jsx("p",{className:"text-sm text-muted-foreground",children:"No API key required — it contains no project data. Common consumers: Swagger UI, Postman, Insomnia, FlutterFlow, and the FD53 SDK generator."})]}),e.jsxs("section",{className:"space-y-2",children:[e.jsx("h3",{className:"font-semibold",children:"Browse it interactively"}),e.jsx(a,{language:"text",code:`https://petstore.swagger.io/?url=${t}/v1/openapi.json`})]}),e.jsxs("section",{className:"space-y-2",children:[e.jsx("h3",{className:"font-semibold",children:"What the spec declares"}),e.jsx("div",{className:"grid gap-3 sm:grid-cols-2",children:[{title:"Security schemes",body:"Two, kept deliberately separate: the X-API-Key header authenticates your backend, and a bearer JWT authenticates your end users."},{title:"Every endpoint",body:"All routes appear with their method, path parameters, request bodies and status codes — including the ones outside auth, storage and database."},{title:"Shared schemas",body:"Error envelopes, sessions, end users, tables, rows, files and buckets are defined once and referenced everywhere."},{title:"FD53 extensions",body:"An x-fd53 block carries the permission list, plan limits and bucket definitions so generators can produce correct client code."}].map(r=>e.jsxs("div",{className:"rounded-lg border border-border bg-card p-4",children:[e.jsx("p",{className:"font-semibold",children:r.title}),e.jsx("p",{className:"mt-1 text-sm text-muted-foreground",children:r.body})]},r.title))})]}),e.jsx(a,{language:"generating a client",code:`# Generate a typed client from the live spec
npx @openapitools/openapi-generator-cli generate \\
  -i ${t}/v1/openapi.json \\
  -g typescript-fetch -o ./src/fd53

# Or import it straight into FlutterFlow
# Integrations → REST API → Add → Import OpenAPI → paste the URL above`})]}),e.jsxs(n,{value:"auth",className:"mt-6 space-y-5",children:[e.jsx("p",{className:"text-sm text-muted-foreground",children:"FD53 Auth issues HS256 access tokens (24 h) backed by revocable server-side sessions. Passwords are hashed with PBKDF2-SHA256 (60k iterations) and never leave the backend."}),e.jsxs("div",{children:[e.jsx(s,{method:"POST",path:"/v1/auth/register",description:"Create an account (email + password, phone, or both)."}),e.jsx(s,{method:"POST",path:"/v1/auth/login",description:"Email or phone + password → token."}),e.jsx(s,{method:"POST",path:"/v1/auth/otp/request",description:"Send a 6-digit code to a phone number."}),e.jsx(s,{method:"POST",path:"/v1/auth/otp/verify",description:"Verify the code → token (creates the user on first sign-in)."}),e.jsx(s,{method:"GET",path:"/v1/auth/me",description:"Current user, role and permissions."}),e.jsx(s,{method:"POST",path:"/v1/auth/logout",description:"Revoke the current session."}),e.jsx(s,{method:"POST",path:"/v1/auth/token/verify",description:"Check whether a token is still valid."}),e.jsx(s,{method:"POST",path:"/v1/auth/password",description:"Change password (current + new)."}),e.jsx(s,{method:"POST",path:"/v1/auth/password/reset",description:"Request a reset token."}),e.jsx(s,{method:"POST",path:"/v1/auth/password/reset/confirm",description:"Set a new password; revokes all sessions."}),e.jsx(s,{method:"GET",path:"/v1/auth/roles",description:"List roles and their permissions."})]}),e.jsxs("div",{className:"grid gap-4 lg:grid-cols-2",children:[e.jsx(a,{language:"register",code:m}),e.jsxs("div",{className:"space-y-4",children:[e.jsx(a,{language:"login",code:u}),e.jsx(a,{language:"authenticated call",code:x})]})]}),e.jsxs("div",{className:"rounded-md border border-chart-2/40 bg-chart-2/10 p-3 text-sm",children:[e.jsx("p",{className:"font-medium",children:"v1 delivery note"}),e.jsxs("p",{className:"text-muted-foreground",children:["No SMS or email provider is wired up yet, so OTP codes and password reset tokens come back in the response (",e.jsx("code",{className:"font-mono",children:"devCode"})," /"," ",e.jsx("code",{className:"font-mono",children:"resetToken"}),") so flows are testable. Send them through a real provider before production — the hook points are in ",e.jsx("code",{className:"font-mono",children:"src/convex/rest/auth.ts"}),"."]})]})]}),e.jsxs(n,{value:"database",className:"mt-6 space-y-5",children:[e.jsx("p",{className:"text-sm text-muted-foreground",children:"Tables are defined with columns of type string, number, boolean, datetime, json or reference. Every write is validated: required columns, types, unique constraints and reference integrity."}),e.jsxs("div",{children:[e.jsx(s,{method:"GET",path:"/v1/db/tables",description:"List tables + schema."}),e.jsx(s,{method:"POST",path:"/v1/db/tables",description:"Create a table."}),e.jsx(s,{method:"GET",path:"/v1/db/tables/:table",description:"Schema of one table."}),e.jsx(s,{method:"PATCH",path:"/v1/db/tables/:table",description:"Update columns or access level."}),e.jsx(s,{method:"DELETE",path:"/v1/db/tables/:table",description:"Drop a table and its rows."}),e.jsx(s,{method:"GET",path:"/v1/db/:table",description:"List rows — ?limit= &offset= &column=value filters."}),e.jsx(s,{method:"POST",path:"/v1/db/:table",description:"Insert a row."}),e.jsx(s,{method:"GET",path:"/v1/db/:table/:id",description:"Read one row."}),e.jsx(s,{method:"PATCH",path:"/v1/db/:table/:id",description:"Partial update (merged with existing values)."}),e.jsx(s,{method:"DELETE",path:"/v1/db/:table/:id",description:"Delete a row."})]}),e.jsx(a,{language:"define + query",code:`curl -X POST ${t}/v1/db/tables \\
  -H "X-API-Key: fd53_live_…" -H "Content-Type: application/json" \\
  -d '{
    "name": "posts",
    "access": "owner",
    "fields": [
      {"name": "title", "type": "string", "required": true},
      {"name": "views", "type": "number"},
      {"name": "tag",  "type": "string", "unique": true},
      {"name": "author", "type": "reference", "refTable": "authors"}
    ]
  }'

# Query (filters apply to any indexed column)
curl "${t}/v1/db/posts?published=true&limit=20&offset=0" \\
  -H "X-API-Key: fd53_live_…"`}),e.jsxs("div",{className:"space-y-2",children:[e.jsx("h3",{className:"font-semibold",children:"Access levels"}),e.jsxs("ul",{className:"space-y-1 text-sm text-muted-foreground",children:[e.jsxs("li",{children:[e.jsx(l,{variant:"secondary",className:"mr-2",children:"public"}),"any call with your API key (used for FlutterFlow server actions)."]}),e.jsxs("li",{children:[e.jsx(l,{variant:"secondary",className:"mr-2",children:"authenticated"}),"end users must send a valid token with ",e.jsx("code",{className:"font-mono",children:"db:read"})," / ",e.jsx("code",{className:"font-mono",children:"db:write"}),"."]}),e.jsxs("li",{children:[e.jsx(l,{variant:"secondary",className:"mr-2",children:"owner"}),"each end user only sees and edits rows they created (admins see all)."]})]})]})]}),e.jsxs(n,{value:"storage",className:"mt-6 space-y-5",children:[e.jsxs("p",{className:"text-sm text-muted-foreground",children:["Images, video, audio and documents, organised into buckets. Free plan: 250 MB per project, 25 MB per file. Files without an explicit"," ",e.jsx("code",{className:"font-mono",children:"bucket"})," fall into one based on their mime type."]}),e.jsxs("div",{children:[e.jsx(s,{method:"GET",path:"/v1/storage/buckets",description:"Bucket definitions + per-bucket file counts and bytes."}),e.jsx(s,{method:"POST",path:"/v1/storage/upload",description:"Upload — multipart, raw binary or JSON+base64. ?bucket= sets the target."}),e.jsx(s,{method:"GET",path:"/v1/storage/files",description:"List files — ?prefix= &bucket= &limit=."}),e.jsx(s,{method:"GET",path:"/v1/storage/files/:id",description:"File metadata + signed URL (?redirect=true to 302)."}),e.jsx(s,{method:"DELETE",path:"/v1/storage/files/:id",description:"Delete and free quota."})]}),e.jsxs("div",{className:"space-y-2",children:[e.jsx("h3",{className:"font-semibold",children:"Buckets"}),e.jsxs("ul",{className:"space-y-2 text-sm text-muted-foreground",children:[e.jsxs("li",{className:"flex flex-col gap-1 sm:flex-row sm:items-baseline sm:gap-3",children:[e.jsx(l,{variant:"secondary",className:"shrink-0 font-mono",children:"avatars"}),e.jsxs("span",{children:["Profile pictures and header banners. ",e.jsx("strong",{children:"Public"})," —"," ",e.jsx("code",{className:"font-mono",children:"GET /v1/storage/buckets"})," reports its visibility. Images/video/audio only."]})]}),e.jsxs("li",{className:"flex flex-col gap-1 sm:flex-row sm:items-baseline sm:gap-3",children:[e.jsx(l,{variant:"secondary",className:"shrink-0 font-mono",children:"post-media"}),e.jsxs("span",{children:["Post images and video streams. ",e.jsx("strong",{children:"Public"}),", media mime types only."]})]}),e.jsxs("li",{className:"flex flex-col gap-1 sm:flex-row sm:items-baseline sm:gap-3",children:[e.jsx(l,{variant:"secondary",className:"shrink-0 font-mono",children:"receipts"}),e.jsxs("span",{children:["Digital downloads and purchase invoices. ",e.jsx("strong",{children:"Private"})," — the bucket forces private visibility and only the uploader, the buyer or an admin can read the file."]})]})]}),e.jsxs("p",{className:"text-sm text-muted-foreground",children:["Bucket visibility is enforced server-side: passing"," ",e.jsx("code",{className:"font-mono",children:"?visibility=public"})," to a"," ",e.jsx("code",{className:"font-mono",children:"receipts"})," upload is ignored."]})]}),e.jsxs("div",{className:"grid gap-4 lg:grid-cols-2",children:[e.jsx(a,{language:"multipart (FlutterFlow)",code:`curl -X POST "${t}/v1/storage/upload?bucket=avatars" \\
  -H "X-API-Key: fd53_live_…" \\
  -F "file=@avatar.png"`}),e.jsx(a,{language:"base64 / raw",code:`# JSON + base64
curl -X POST "${t}/v1/storage/upload?bucket=post-media" \\
  -H "X-API-Key: fd53_live_…" -H "Content-Type: application/json" \\
  -d '{"path":"me.png","mimeType":"image/png","contentBase64":"iVBORw0K…"}'

# raw binary
curl -X POST "${t}/v1/storage/upload?bucket=receipts&path=invoice.pdf" \\
  -H "X-API-Key: fd53_live_…" \\
  -H "Content-Type: application/pdf" --data-binary @invoice.pdf`})]})]}),e.jsxs(n,{value:"realtime",className:"mt-6 space-y-5",children:[e.jsx("p",{className:"text-sm text-muted-foreground",children:"Publish events to channels (chat rooms, notifications, live scores). The console feed updates instantly because it subscribes to Convex queries. Client apps can poll the REST endpoint or subscribe with the Convex client for true push delivery — see the roadmap."}),e.jsxs("div",{children:[e.jsx(s,{method:"POST",path:"/v1/realtime/publish",description:"Publish {channel, type, payload}."}),e.jsx(s,{method:"GET",path:"/v1/realtime/channels",description:"Channels with event counts."}),e.jsx(s,{method:"GET",path:"/v1/realtime/channels/:channel/events",description:"Recent events on a channel."})]}),e.jsx(a,{code:`curl -X POST ${t}/v1/realtime/publish \\
  -H "X-API-Key: fd53_live_…" -H "Content-Type: application/json" \\
  -d '{"channel":"chat.room1","type":"message","payload":{"text":"hello"}}'`})]}),e.jsxs(n,{value:"loopuni",className:"mt-6 space-y-5",children:[e.jsxs("p",{className:"text-sm text-muted-foreground",children:["A complete social + marketplace backend, ready to drive from an app. Registration mints a LoopUni identity and a public"," ",e.jsx("code",{className:"font-mono",children:"@handle"}),"; all social and marketplace writes need an end-user token and pass through per-user anti-spam limits."]}),e.jsxs("div",{className:"space-y-2",children:[e.jsx("h3",{className:"font-semibold",children:"Auth"}),e.jsxs("div",{children:[e.jsx(s,{method:"POST",path:"/v1/auth/register",description:'Create an account → JWT + profile. Optional "username" claims a @handle.'}),e.jsx(s,{method:"POST",path:"/v1/auth/login",description:"Email + password → JWT + profile."})]})]}),e.jsxs("div",{className:"space-y-2",children:[e.jsx("h3",{className:"font-semibold",children:"Profiles & social graph"}),e.jsxs("div",{children:[e.jsx(s,{method:"GET",path:"/v1/users/profile/:username",description:"Profile by @handle (case-insensitive) + their recent posts."}),e.jsx(s,{method:"POST",path:"/v1/users/:id/follow",description:"Follow a user. :id accepts a user id or an @handle. 201 first time, 200 after."}),e.jsx(s,{method:"POST",path:"/v1/users/:id/unfollow",description:"Remove a follow edge and decrement both counters."})]})]}),e.jsxs("div",{className:"space-y-2",children:[e.jsx("h3",{className:"font-semibold",children:"Feed"}),e.jsxs("div",{children:[e.jsx(s,{method:"POST",path:"/v1/posts/create",description:"Create a text/photo/video post. Media references files uploaded to post-media."}),e.jsx(s,{method:"GET",path:"/v1/posts/:id",description:"One post with its media and author."}),e.jsx(s,{method:"GET",path:"/v1/feed/home",description:"Home feed — followed authors when signed in, otherwise discovery. ?limit=."})]})]}),e.jsxs("div",{className:"space-y-2",children:[e.jsx("h3",{className:"font-semibold",children:"Messaging & moderation"}),e.jsxs("div",{children:[e.jsx(s,{method:"POST",path:"/v1/messages/send",description:'Send a message. "to": "@handle" opens the 1:1 room, "roomId" replies in one.'}),e.jsx(s,{method:"GET",path:"/v1/messages/:roomId",description:"Message history (newest last). ?limit=."}),e.jsx(s,{method:"POST",path:"/v1/reports/create",description:"Flag a user/post/comment/message/product for moderation."})]})]}),e.jsxs("div",{className:"space-y-2",children:[e.jsx("h3",{className:"font-semibold",children:"Marketplace"}),e.jsxs("div",{children:[e.jsx(s,{method:"POST",path:"/v1/marketplace/products",description:"Create a listing. priceCents is an integer; digital assets must live in the receipts bucket."}),e.jsx(s,{method:"GET",path:"/v1/marketplace/products",description:"Browse listings — ?seller=@handle, ?category=, ?limit=."}),e.jsx(s,{method:"GET",path:"/v1/marketplace/products/:id",description:"One listing."}),e.jsx(s,{method:"POST",path:"/v1/marketplace/orders/checkout",description:"Purchase → order + creatorEarnings ledger row. Fee is computed server-side (10%)."}),e.jsx(s,{method:"GET",path:"/v1/marketplace/orders",description:"The caller's purchase history."}),e.jsx(s,{method:"GET",path:"/v1/marketplace/earnings",description:"Seller wallet: gross, platform fee, available and pending balances."})]})]}),e.jsxs("div",{className:"grid gap-4 lg:grid-cols-2",children:[e.jsx(a,{language:"register + post",code:g}),e.jsx(a,{language:"follow + checkout",code:v})]}),e.jsxs("div",{className:"space-y-2",children:[e.jsx("h3",{className:"font-semibold",children:"Per-user anti-spam"}),e.jsxs("p",{className:"text-sm text-muted-foreground",children:["On top of the per-key limit, each write path has a fixed window per end user so one abusive account cannot burn your app's quota. Over the limit you get ",e.jsx("code",{className:"font-mono",children:"429"})," with"," ",e.jsx("code",{className:"font-mono",children:"Retry-After"}),"; currently throttled callers are listed on the Usage page."]}),e.jsx(a,{language:"limits",code:`register   10 / hour   per IP
login      20 / 15 min per email or phone
post       30 / hour   per user
follow    200 / hour   per user
message    60 / min    per user
checkout   20 / hour   per user
product    60 / hour   per user
report     10 / hour   per user`})]}),e.jsxs("p",{className:"text-sm text-muted-foreground",children:["Money is always integer minor units (",e.jsx("code",{className:"font-mono",children:"priceCents"}),") — never floats — and the 10% platform fee is computed on the server, so a client can never choose its own payout."]})]}),e.jsxs(n,{value:"flutterflow",className:"mt-6 space-y-5",children:[e.jsxs("div",{className:"space-y-2",children:[e.jsx("h3",{className:"font-semibold",children:"1 · Define your backend once"}),e.jsxs("ol",{className:"list-decimal space-y-1 pl-5 text-sm text-muted-foreground",children:[e.jsx("li",{children:"Create a project in this console (one per app)."}),e.jsx("li",{children:"Add your tables under Database, and files under Storage."}),e.jsx("li",{children:"Create an API key per environment — keep the production key server-side."})]})]}),e.jsxs("div",{className:"space-y-2",children:[e.jsx("h3",{className:"font-semibold",children:"2 · Call it from FlutterFlow"}),e.jsxs("ul",{className:"list-disc space-y-1 pl-5 text-sm text-muted-foreground",children:[e.jsxs("li",{children:[e.jsx("strong",{children:"API calls / server actions"}),": add header"," ",e.jsx("code",{className:"font-mono",children:"X-API-Key: fd53_live_…"})," and URL"," ",e.jsxs("code",{className:"font-mono",children:[t,"/v1/db/<table>"]}),"."]}),e.jsxs("li",{children:[e.jsx("strong",{children:"Authentication"}),": call"," ",e.jsx("code",{className:"font-mono",children:"/v1/auth/login"})," from a server action, store the returned token in a FlutterFlow State Variable and send it as ",e.jsx("code",{className:"font-mono",children:"Authorization: Bearer …"})," on later calls."]}),e.jsxs("li",{children:[e.jsx("strong",{children:"File upload"}),": use an API call with"," ",e.jsx("code",{className:"font-mono",children:"multipart/form-data"})," — the same shape as FlutterFlow's native upload, so you can keep the default file widget and just change the URL."]}),e.jsxs("li",{children:[e.jsx("strong",{children:"Displaying files"}),": use the"," ",e.jsx("code",{className:"font-mono",children:"url"})," returned by the upload/list call in an Image widget."]})]})]}),e.jsx(a,{language:"FlutterFlow server action (Dart)",code:`import 'package:http/http.dart' as http;
import 'dart:convert';

const base = '${t}';
const key = 'fd53_live_…';

Future<Map<String, dynamic>> signIn(String email, String password) async {
  final res = await http.post(
    Uri.parse('$base/v1/auth/login'),
    headers: {'X-API-Key': key, 'Content-Type': 'application/json'},
    body: jsonEncode({'email': email, 'password': password}),
  );
  final body = jsonDecode(res.body);
  return body['data'];
}

Future<List<dynamic>> listRows(String token) async {
  final res = await http.get(
    Uri.parse('$base/v1/db/posts?limit=50'),
    headers: {'X-API-Key': key, 'Authorization': 'Bearer $token'},
  );
  return jsonDecode(res.body)['data']['items'] as List<dynamic>;
}`}),e.jsx("p",{className:"text-sm text-muted-foreground",children:"Tip: FlutterFlow web builds call the API from the browser. FD53 sends permissive CORS headers, so no proxy is needed; the API key is still visible in the network tab, so prefer server actions for anything sensitive."})]}),e.jsxs(n,{value:"architecture",className:"mt-6 space-y-5",children:[e.jsxs("section",{className:"space-y-2",children:[e.jsx("h3",{className:"font-semibold",children:"Request flow"}),e.jsx(a,{language:"architecture",code:`FlutterFlow / native app
        │  X-API-Key  +  Authorization: Bearer <user token>
        ▼
/v1/*  (Convex HTTP actions — src/convex/http.ts)
        │  1. authenticateKey()        sha256(key) → apiKeys doc (hashed at rest)
        │  2. enforceQuota()           sliding window per key → 429 + Retry-After
        │  3. authenticateEndUser()    HS256 signature + session lookup + role
        │  4. enforceAntiSpam()        fixed window per end user (LoopUni writes)
        │  5. handler                  src/convex/rest/{auth,database,storage,realtime,
        │                             social,marketplace}.ts
        │  6. requestLog.record()      → the Usage dashboard's request table
        ▼
Convex (queries / mutations / actions + file storage)
        projects · apiKeys · tables · rows · endUsers · sessions · roles
        files · phoneOtps · passwordResets · rateBuckets · usageDaily
        events · requestLogs
        profiles · posts · media · follows · conversations · messages
        products · orders · creatorEarnings · rateLimits · reports`})]}),e.jsxs("section",{className:"space-y-2",children:[e.jsx("h3",{className:"font-semibold",children:"Data model"}),e.jsx(a,{language:"schema.ts",code:`projects     owner, slug, plan, quotas, storageBytes
apiKeys      project, keyPrefix, keyHash(sha256), scopes, rateLimit, revokedAt
tables       project, name, access(public|authenticated|owner), fields[], rowCount
rows         project, table, data{}, ownerId          ← generic document store
uniqueValues project, table, field, value, rowId     ← O(1) unique checks
endUsers     project, email/phone, passwordHash+salt, role, tokenVersion
sessions     project, endUser, sid, expiresAt, revokedAt
roles        project, name, permissions[], isDefault
files        project, path, mime, size, storageId, visibility, bucket, ownerId
phoneOtps    project, phone, codeHash(peppered), expiresAt, attempts
rateBuckets  key, minute-bucket, count               ← per-API-key rate limiting
usageDaily   project, day, category, count, errorCount
events       project, channel, type, payload         ← realtime
requestLogs  project, method, path, route, category, status, durationMs
secrets      fd53.jwt, fd53.otp                      ← server-side only

── LoopUni domain ──
users        name/email, username+usernameLower, isCreator, tokenVersion
profiles     user, handle(+Lower, unique), bio, avatarUrl, bannerUrl,
             followerCount / followingCount / postCount, isCreator, isVerified
posts        author, text, kind(text|photo|video), aspectRatio, mediaCount,
             like/comment/share counts, visibility, hashtags[]
media        post, owner, bucket, fileId, url, kind, width/height,
             aspectRatio, durationMs, position
follows      followerId → followingId, status(active|pending)
conversations project, roomId, type(direct|group), participantIds[],
             lastMessageAt, lastMessagePreview
messages     conversation, roomId, sender, text, kind, mediaIds[], readAt
products     seller, title, priceCents, currency, kind, status, mediaIds[],
             assetFileId (private), inventory, salesCount
orders       buyer, seller, product, quantity, amountCents, platformFeeCents,
             status(pending|paid|failed|refunded), receiptFileId, paymentRef
creatorEarnings creator, order, product, gross/fee/net cents, status, availableAt
rateLimits   project, key("post:<id>"), windowStart, count, blockedUntil
             ↑ per-end-user anti-spam (separate from rateBuckets)
reports      project, reporter, targetType, targetId, reason, status`})]}),e.jsxs("section",{className:"space-y-2",children:[e.jsx("h3",{className:"font-semibold",children:"Folder structure"}),e.jsx(a,{language:"text",code:`src/
├── convex/                  ← the FD53 backend
│   ├── schema.ts            data model
│   ├── http.ts              /v1 REST router wiring
│   ├── rest/                endpoint handlers
│   │   ├── router.ts        route table, auth + quota + anti-spam + request log
│   │   ├── auth.ts          register/login/otp/password/sessions
│   │   ├── database.ts      tables + rows
│   │   ├── storage.ts       uploads (multipart/raw/base64) + buckets
│   │   ├── realtime.ts      publish / channels
│   │   ├── social.ts        profiles, follows, posts, feed, messages, reports
│   │   ├── marketplace.ts   products, checkout, orders, earnings
│   │   ├── actor.ts         end-user token → LoopUni identity resolver
│   │   └── meta.ts          health, service index, usage
│   ├── lib/
│   │   ├── crypto.ts        PBKDF2, HMAC, JWT (Web Crypto)
│   │   ├── rest.ts          CORS, envelope, API-key + user auth, quotas, anti-spam
│   │   ├── constants.ts     plan limits, roles, buckets, anti-spam limits
│   │   └── authz.ts         project ownership guard
│   ├── projects.ts          console CRUD + cascade delete
│   ├── apiKeys.ts           key minting (action) / revoke
│   ├── tables.ts            schema CRUD + validation
│   ├── rows.ts              document CRUD + validation
│   ├── endUsers.ts          app users, lockouts
│   ├── sessions.ts          revocation
│   ├── roles.ts             permissions
│   ├── files.ts             storage records, buckets + quota
│   ├── usage.ts             rate buckets + counters
│   ├── realtime.ts          events
│   ├── identity.ts          LoopUni users + profiles
│   ├── social.ts            posts, media, follows
│   ├── messaging.ts         conversations + messages
│   ├── marketplace.ts       products, orders, earnings
│   ├── rateLimits.ts        per-end-user anti-spam
│   ├── reports.ts           moderation queue
│   ├── requestLog.ts        per-request logging for the Usage page
│   └── secrets.ts           server-only secrets
├── pages/
│   ├── Landing.tsx          public site
│   ├── Dashboard.tsx        console shell + sidebar
│   └── dashboard/           overview, projects, keys, db, storage, users, usage, docs
└── components/dashboard/    console UI + project context`})]}),e.jsxs("section",{className:"space-y-2",children:[e.jsx("h3",{className:"font-semibold",children:"Deployment"}),e.jsx(a,{language:"text",code:`# Development
bun install
bun convex dev            # pushes functions + regenerates _generated types
bun run dev              # Vite dev server for the console

# Production
bun convex deploy --prod  # push functions to the production deployment
bun run build            # typecheck + build the console (static output)

# The API is served by the deployment itself:
#   development : https://<deployment>.convex.site/v1
#   production  : https://<deployment>.convex.site/v1
# No extra servers, containers or DNS are required — Convex hosts the
# database, file storage and HTTP endpoints.

# Environment (optional)
FD53_*  — reserved for the SMS/email providers in v2.
JWT/OTP signing keys are generated on first use and stored in the
\`secrets\` table, so nothing has to be configured to get started.`})]}),e.jsxs("section",{className:"space-y-2",children:[e.jsx("h3",{className:"font-semibold",children:"Roadmap"}),e.jsx("div",{className:"overflow-x-auto rounded-lg border border-border",children:e.jsxs("table",{className:"w-full text-sm",children:[e.jsx("thead",{className:"bg-muted/40 text-left text-xs tracking-wide uppercase",children:e.jsxs("tr",{children:[e.jsx("th",{className:"px-3 py-2",children:"Version"}),e.jsx("th",{className:"px-3 py-2",children:"Focus"}),e.jsx("th",{className:"px-3 py-2",children:"What lands"})]})}),e.jsxs("tbody",{className:"divide-y divide-border",children:[e.jsxs("tr",{children:[e.jsx("td",{className:"px-3 py-2 font-mono text-xs",children:"v1 — now"}),e.jsx("td",{className:"px-3 py-2",children:"Foundation"}),e.jsx("td",{className:"px-3 py-2 text-muted-foreground",children:"Auth (email/phone, sessions, roles), database with validation + references + unique, storage with quotas, REST API + keys, console, rate limiting, realtime events."})]}),e.jsxs("tr",{children:[e.jsx("td",{className:"px-3 py-2 font-mono text-xs",children:"v1.1"}),e.jsx("td",{className:"px-3 py-2",children:"Delivery"}),e.jsx("td",{className:"px-3 py-2 text-muted-foreground",children:"Real SMS + email providers for OTP and password reset, custom email templates, email verification flow."})]}),e.jsxs("tr",{children:[e.jsx("td",{className:"px-3 py-2 font-mono text-xs",children:"v1.2"}),e.jsx("td",{className:"px-3 py-2",children:"Realtime"}),e.jsx("td",{className:"px-3 py-2 text-muted-foreground",children:"SSE/WebSocket stream endpoint, presence, typed channels, chat + notification helpers."})]}),e.jsxs("tr",{children:[e.jsx("td",{className:"px-3 py-2 font-mono text-xs",children:"v1.3"}),e.jsx("td",{className:"px-3 py-2",children:"Scale"}),e.jsx("td",{className:"px-3 py-2 text-muted-foreground",children:"Compound filters/aggregation queries, compound indexes, bigger file limits, resumable uploads."})]}),e.jsxs("tr",{children:[e.jsx("td",{className:"px-3 py-2 font-mono text-xs",children:"v2"}),e.jsx("td",{className:"px-3 py-2",children:"Platform"}),e.jsx("td",{className:"px-3 py-2 text-muted-foreground",children:"Multi-tenant accounts, environment branching (dev/staging/prod), webhooks, audit log, usage-based plans."})]})]})]})})]}),e.jsxs("section",{className:"space-y-2",children:[e.jsx("h3",{className:"font-semibold",children:"Known v1 limits"}),e.jsxs("ul",{className:"list-disc space-y-1 pl-5 text-sm text-muted-foreground",children:[e.jsx("li",{children:"Row listing filters a table in memory — fine for personal-scale data."}),e.jsx("li",{children:"Project deletion cascades in one mutation (archive instead for big datasets)."}),e.jsx("li",{children:"Single-region deployment, one Convex deployment per environment."}),e.jsx("li",{children:"Realtime is REST polling for external clients — chat uses the messages tables, not the event log."}),e.jsx("li",{children:"Checkout records orders but does not move money; wire your payment provider and attach the receipt file to the order."})]})]})]}),e.jsxs(n,{value:"security",className:"mt-6 space-y-5",children:[e.jsx("div",{className:"grid gap-3 sm:grid-cols-2",children:[{title:"Passwords",body:"PBKDF2-SHA256, 60 000 iterations, 16-byte random salt, constant-time comparison. Hashes never leave the backend."},{title:"API keys",body:"256-bit random keys stored as SHA-256 hashes; only the first 20 characters are displayed after creation."},{title:"Tokens",body:"HS256 JWTs signed with a server-generated secret, bound to a revocable session and a per-user token version."},{title:"Encryption",body:"TLS in transit; Convex encrypts data and file storage at rest (AES-256). OTP codes are additionally peppered with an HMAC secret."},{title:"Access control",body:"API-key scopes per endpoint, table access levels (public / authenticated / owner) and role permissions checked server-side."},{title:"Abuse protection",body:"A per-IP flood limiter runs before authentication, so an anonymous flood never reaches the database. Repeated failed authentications ban the source outright. Behind that: sliding-window rate limits per key (429 + Retry-After), per-end-user anti-spam limits, account lockout after failed logins, OTP attempt limits, and body/file size caps."},{title:"Network firewall",body:"Per-key IP allowlists and denylists with full IPv4/IPv6 CIDR support, evaluated before any scope decision. Per-key CORS origin allowlists, including wildcard subdomains."},{title:"Web application firewall",body:"Every request is inspected for path traversal (including percent-encoded), SQL and shell injection patterns, null bytes, oversized paths, query strings, headers and bodies, and disallowed HTTP verbs — all before authentication runs."},{title:"Key lifecycle",body:"Keys carry an environment (live/test), an optional expiry, IP and origin restrictions, and per-key scopes. A sandbox key cannot slip into production by accident: the environment encoded in the key is checked against the key record."},{title:"Audit trail",body:"Key lifecycle, authentication failures, IP blocks, WAF trips, scope denials and configuration changes are recorded in an append-only log. Client IPs are hashed, never stored raw. Every response carries an X-FD53-Request-Id linking the request log, the audit trail and server logs."}].map(r=>e.jsxs("div",{className:"rounded-lg border border-border bg-card p-4",children:[e.jsx("p",{className:"font-semibold",children:r.title}),e.jsx("p",{className:"mt-1 text-sm text-muted-foreground",children:r.body})]},r.title))}),e.jsx(a,{language:"hardening checklist",code:`1. Keep API keys in server actions / env vars — never in client code.
2. Use one key per environment so you can revoke independently.
3. Give every key the narrowest scopes that work, and set an expiry.
4. Restrict server-side keys by IP allowlist where you can.
5. Mark sensitive tables "authenticated" or "owner".
6. Give end users the narrowest role that works (viewer / user / editor / admin).
7. Watch the Usage page for error spikes and 429s.`}),e.jsx(a,{language:"gateway pipeline",code:`Every /v1 request passes through these stages, in order.

 1  Correlation      assign or honour X-FD53-Request-Id
 2  Fingerprint      client IP (hashed) + user agent
 3  WAF              traversal · injection · size · bad verb
 4  Origin           CORS resolved against the key allowlist
 5  Edge throttle    per-IP flood limit — BEFORE any database read
 6  API key          format → hash → revoked → expired → environment
                    → project → suspended → IP policy → scope
 7  Quota            per-key rate limit + usage accounting
 8  Dispatch         route handler
 9  Response         envelope + security headers
10  Telemetry        request log + audit trail + Server-Timing

Stages 1-5 deliberately run before authentication: an anonymous flood must
never reach the database or consume a real project's quota.`}),e.jsx(a,{language:"error codes",code:`Branch on the error code, not the message — messages change, codes do not.

401  missing_api_key             no X-API-Key header
401  invalid_api_key             malformed, or not a key we know
401  key_revoked                 revoked in the dashboard
401  key_expired                 past its expiry
401  key_environment_mismatch    test key used where live is implied
403  project_suspended           billing or admin action
403  ip_not_allowed              outside the key's IP allowlist
403  insufficient_scope          key lacks the endpoint's scope
403  blocked_by_waf              a WAF rule matched (see X-FD53-Rule)
429  rate_limited                honour the Retry-After header
413  storage_quota_exceeded      project storage is full

Responses are always { "ok": true, "data": ... } on success, or
{ "ok": false, "error": { "code", "message" } } on failure.`})]})]})]})}export{ae as default};
