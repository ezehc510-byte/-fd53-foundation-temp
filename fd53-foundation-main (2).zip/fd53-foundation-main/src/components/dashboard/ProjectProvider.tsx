import { createContext, useContext, useEffect, useMemo, useState } from "react";
import type { ReactNode } from "react";
import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api";
import type { Doc } from "@/convex/_generated/dataModel";

const STORAGE_KEY = "fd53.activeProject";

type ProjectContextValue = {
  projects: Doc<"projects">[] | undefined;
  project: Doc<"projects"> | undefined;
  projectId: Doc<"projects">["_id"] | undefined;
  setProjectId: (id: Doc<"projects">["_id"]) => void;
};

const ProjectContext = createContext<ProjectContextValue | null>(null);

/**
 * Holds the signed-in developer's projects and which one the console is
 * currently pointed at. Every dashboard page reads it from here instead of
 * duplicating queries and local state.
 */
export function ProjectProvider({ children }: { children: ReactNode }) {
  const projects = useQuery(api.projects.list);
  const [projectId, setProjectIdState] = useState<
    Doc<"projects">["_id"] | undefined
  >(undefined);

  useEffect(() => {
    if (!projects) return;
    if (projects.length === 0) {
      setProjectIdState(undefined);
      return;
    }
    setProjectIdState((current) => {
      if (current && projects.some((p) => p._id === current)) return current;
      const stored =
        typeof window !== "undefined"
          ? window.localStorage.getItem(STORAGE_KEY)
          : null;
      const match = projects.find((p) => p._id === stored) ?? projects[0];
      return match._id;
    });
  }, [projects]);

  const project = projects?.find((p) => p._id === projectId);

  const value = useMemo<ProjectContextValue>(() => {
    return {
      projects,
      project,
      projectId: project?._id,
      setProjectId: (id) => {
        setProjectIdState(id);
        if (typeof window !== "undefined") {
          window.localStorage.setItem(STORAGE_KEY, id);
        }
      },
    };
  }, [projects, project, projectId]);

  return (
    <ProjectContext.Provider value={value}>{children}</ProjectContext.Provider>
  );
}

export function useProject(): ProjectContextValue {
  const context = useContext(ProjectContext);
  if (!context) {
    throw new Error("useProject must be used inside <ProjectProvider>");
  }
  return context;
}