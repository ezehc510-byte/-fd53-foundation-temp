import { useEffect, useMemo, useState } from "react";
import { useMutation, useQuery } from "convex/react";
import {
  Database,
  KeyRound,
  Plus,
  Rows3,
  Search,
  Trash2,
  X,
} from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api";
import type { Id } from "@/convex/_generated/dataModel";
import { useProject } from "@/components/dashboard/ProjectProvider";
import {
  CodeBlock,
  EmptyState,
  LoadingBlock,
  PageHeader,
} from "@/components/dashboard/ui";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { apiBase, formatNumber, previewValue, timeAgo } from "@/lib/fd53";

const FIELD_TYPES = [
  "string",
  "number",
  "boolean",
  "datetime",
  "json",
  "reference",
] as const;

type FieldDraft = {
  name: string;
  type: string;
  required: boolean;
  unique: boolean;
  refTable: string;
};

const emptyField = (): FieldDraft => ({
  name: "",
  type: "string",
  required: false,
  unique: false,
  refTable: "",
});

function TableDialog({
  open,
  onOpenChange,
  existingTables,
  projectId,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  existingTables: string[];
  projectId: Id<"projects">;
}) {
  const createTable = useMutation(api.tables.createTable);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [access, setAccess] = useState<"public" | "authenticated" | "owner">(
    "public",
  );
  const [fields, setFields] = useState<FieldDraft[]>([emptyField()]);
  const [pending, setPending] = useState(false);

  const updateField = (index: number, patch: Partial<FieldDraft>) =>
    setFields((current) =>
      current.map((field, i) => (i === index ? { ...field, ...patch } : field)),
    );

  const submit = async () => {
    setPending(true);
    try {
      const result = await createTable({
        projectId,
        name,
        description,
        access,
        fields: fields
          .filter((field) => field.name.trim())
          .map((field) => ({
            name: field.name.trim().toLowerCase(),
            type: field.type as (typeof FIELD_TYPES)[number],
            required: field.required,
            unique: field.unique,
            refTable: field.type === "reference" ? field.refTable : undefined,
          })),
      });
      if (result.status === "created") {
        toast.success(`Table "${name}" created`);
        onOpenChange(false);
        setName("");
        setDescription("");
        setFields([emptyField()]);
      } else {
        toast.error(result.message);
      }
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Could not create table");
    } finally {
      setPending(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle>Create a table</DialogTitle>
          <DialogDescription>
            Tables are schema-on-write: columns are validated on every insert and
            update through the API.
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-2">
            <Label htmlFor="table-name">Table name</Label>
            <Input
              id="table-name"
              value={name}
              onChange={(event) => setName(event.target.value)}
              placeholder="todos"
            />
          </div>
          <div className="space-y-2">
            <Label>Access level</Label>
            <Select
              value={access}
              onValueChange={(value) =>
                setAccess(value as "public" | "authenticated" | "owner")
              }
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="public">public — API key only</SelectItem>
                <SelectItem value="authenticated">authenticated — needs a user token</SelectItem>
                <SelectItem value="owner">owner — each user sees their rows</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2 sm:col-span-2">
            <Label htmlFor="table-description">Description (optional)</Label>
            <Input
              id="table-description"
              value={description}
              onChange={(event) => setDescription(event.target.value)}
              placeholder="What this table stores"
            />
          </div>
        </div>

        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <Label>Columns</Label>
            <Button
              variant="outline"
              size="sm"
              className="cursor-pointer"
              onClick={() => setFields((current) => [...current, emptyField()])}
            >
              <Plus className="size-4" />
              Add column
            </Button>
          </div>

          <div className="space-y-2">
            {fields.map((field, index) => (
              <div
                key={index}
                className="grid gap-2 rounded-md border border-border p-3 sm:grid-cols-[1fr_auto_auto_auto_auto] sm:items-center"
              >
                <Input
                  value={field.name}
                  onChange={(event) => updateField(index, { name: event.target.value })}
                  placeholder="column_name"
                  className="font-mono text-xs"
                />
                <Select
                  value={field.type}
                  onValueChange={(value) => updateField(index, { type: value })}
                >
                  <SelectTrigger className="w-full sm:w-36">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {FIELD_TYPES.map((type) => (
                      <SelectItem key={type} value={type} className="font-mono text-xs">
                        {type}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {field.type === "reference" ? (
                  <Select
                    value={field.refTable}
                    onValueChange={(value) => updateField(index, { refTable: value })}
                  >
                    <SelectTrigger className="w-full sm:w-36">
                      <SelectValue placeholder="target table" />
                    </SelectTrigger>
                    <SelectContent>
                      {existingTables.map((table) => (
                        <SelectItem key={table} value={table} className="font-mono text-xs">
                          {table}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                ) : (
                  <div className="hidden sm:block sm:w-36" />
                )}
                <label className="flex items-center gap-2 text-xs">
                  <Checkbox
                    checked={field.required}
                    onCheckedChange={(checked) =>
                      updateField(index, { required: Boolean(checked) })
                    }
                  />
                  required
                </label>
                <div className="flex items-center gap-2">
                  <label className="flex items-center gap-2 text-xs">
                    <Checkbox
                      checked={field.unique}
                      onCheckedChange={(checked) =>
                        updateField(index, { unique: Boolean(checked) })
                      }
                    />
                    unique
                  </label>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="size-7 cursor-pointer text-muted-foreground"
                    onClick={() =>
                      setFields((current) =>
                        current.length > 1
                          ? current.filter((_, i) => i !== index)
                          : [emptyField()],
                      )
                    }
                  >
                    <X className="size-3.5" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" className="cursor-pointer" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button
            className="cursor-pointer"
            disabled={pending || name.trim().length < 1}
            onClick={submit}
          >
            {pending ? "Creating…" : "Create table"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function RowDialog({
  open,
  onOpenChange,
  fields,
  projectId,
  tableId,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  fields: Array<{ name: string; type: string; required?: boolean }>;
  projectId: Id<"projects">;
  tableId: Id<"tables">;
}) {
  const insertRow = useMutation(api.rows.insertRowFromDashboard);
  const [values, setValues] = useState<Record<string, string | boolean>>({});
  const [pending, setPending] = useState(false);

  const submit = async () => {
    setPending(true);
    try {
      const data: Record<string, unknown> = {};
      for (const field of fields) {
        const raw = values[field.name];
        if (raw === undefined || raw === "") {
          if (field.required) throw new Error(`"${field.name}" is required`);
          continue;
        }
        switch (field.type) {
          case "number":
            data[field.name] = Number(raw);
            break;
          case "boolean":
            data[field.name] = Boolean(raw);
            break;
          case "json":
            try {
              data[field.name] = JSON.parse(String(raw));
            } catch {
              throw new Error(`"${field.name}" isn't valid JSON`);
            }
            break;
          case "datetime":
            data[field.name] = new Date(String(raw)).toISOString();
            break;
          default:
            data[field.name] = raw;
        }
      }
      const result = await insertRow({ projectId, tableId, data });
      if (result.status === "ok") {
        toast.success("Row created");
        onOpenChange(false);
        setValues({});
      } else {
        toast.error(result.message);
      }
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Could not create row");
    } finally {
      setPending(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Insert a row</DialogTitle>
          <DialogDescription>
            The same validation the API applies — unknown columns and bad types are
            rejected.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          {fields.map((field) => (
            <div key={field.name} className="space-y-1.5">
              <Label htmlFor={`field-${field.name}`} className="font-mono text-xs">
                {field.name}
                {field.required ? <span className="text-primary"> *</span> : null}
                <span className="ml-2 text-muted-foreground">{field.type}</span>
              </Label>
              {field.type === "boolean" ? (
                <label className="flex items-center gap-2 text-sm">
                  <Checkbox
                    checked={Boolean(values[field.name])}
                    onCheckedChange={(checked) =>
                      setValues((current) => ({ ...current, [field.name]: Boolean(checked) }))
                    }
                  />
                  true
                </label>
              ) : field.type === "json" ? (
                <Textarea
                  id={`field-${field.name}`}
                  rows={3}
                  className="font-mono text-xs"
                  placeholder='{"key":"value"}'
                  value={String(values[field.name] ?? "")}
                  onChange={(event) =>
                    setValues((current) => ({ ...current, [field.name]: event.target.value }))
                  }
                />
              ) : (
                <Input
                  id={`field-${field.name}`}
                  type={
                    field.type === "number"
                      ? "number"
                      : field.type === "datetime"
                        ? "datetime-local"
                        : "text"
                  }
                  value={String(values[field.name] ?? "")}
                  onChange={(event) =>
                    setValues((current) => ({ ...current, [field.name]: event.target.value }))
                  }
                />
              )}
            </div>
          ))}
        </div>
        <DialogFooter>
          <Button variant="outline" className="cursor-pointer" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button className="cursor-pointer" disabled={pending} onClick={submit}>
            {pending ? "Inserting…" : "Insert row"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export default function DatabasePage() {
  const { projectId } = useProject();
  const [selectedId, setSelectedId] = useState<string | undefined>(undefined);
  const [tableDialogOpen, setTableDialogOpen] = useState(false);
  const [rowDialogOpen, setRowDialogOpen] = useState(false);
  const [search, setSearch] = useState("");

  const tables = useQuery(api.tables.list, projectId ? { projectId } : "skip");
  const deleteTable = useMutation(api.tables.deleteTable);
  const deleteRow = useMutation(api.rows.deleteRowFromDashboard);

  const selected = useMemo(
    () => tables?.find((table) => table._id === selectedId) ?? tables?.[0],
    [tables, selectedId],
  );

  const rows = useQuery(
    api.rows.listForDashboard,
    selected && projectId
      ? { projectId, tableId: selected._id, limit: 50, search: search || undefined }
      : "skip",
  );

  useEffect(() => {
    if (tables && tables.length > 0 && !tables.some((t) => t._id === selectedId)) {
      setSelectedId(tables[0]._id);
    }
  }, [tables, selectedId]);if (!projectId) {
    return (
      <EmptyState
        icon={Database}
        title="No active project"
        description="Create a project to start defining tables."
      />
    );
  }

  if (tables === undefined) return <LoadingBlock label="Loading tables" />;

  return (
    <div className="space-y-6">
      <PageHeader
        title="Database"
        description="Define tables, then read and write them from any app over REST."
        action={
          <Button className="cursor-pointer" onClick={() => setTableDialogOpen(true)}>
            <Plus className="size-4" />
            New table
          </Button>
        }
      />

      {tables.length === 0 ? (
        <EmptyState
          icon={Database}
          title="No tables yet"
          description="Create your first table — for example a todos list for your FlutterFlow app."
          action={
            <Button className="cursor-pointer" onClick={() => setTableDialogOpen(true)}>
              Create a table
            </Button>
          }
        />
      ) : (
        <div className="grid gap-5 lg:grid-cols-[240px_1fr]">
          {/* Table list */}
          <div className="space-y-1">
            {tables.map((table) => (
              <button
                key={table._id}
                type="button"
                onClick={() => setSelectedId(table._id)}
                className={`flex w-full items-center justify-between gap-2 rounded-md px-3 py-2 text-left text-sm transition-colors ${
                  table._id === selected?._id
                    ? "bg-accent text-accent-foreground"
                    : "text-muted-foreground hover:bg-accent/50 hover:text-foreground"
                }`}
              >
                <span className="truncate font-mono text-xs">{table.name}</span>
                <span className="shrink-0 text-xs">{formatNumber(table.rowCount)}</span>
              </button>
            ))}
          </div>

          {/* Selected table */}
          {selected ? (
            <div className="min-w-0 space-y-5">
              <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                <div>
                  <div className="flex flex-wrap items-center gap-2">
                    <h2 className="font-mono text-lg font-semibold tracking-tight">
                      {selected.name}
                    </h2>
                    <Badge variant="secondary">{selected.access}</Badge>
                  </div>
                  <p className="mt-1 text-sm text-muted-foreground">
                    {selected.description ?? "No description"}
                  </p>
                </div>
                <div className="flex gap-2">
                  <Button
                    className="cursor-pointer"
                    size="sm"
                    onClick={() => setRowDialogOpen(true)}
                  >
                    <Rows3 className="size-4" />
                    Add row
                  </Button>
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button variant="outline" size="sm" className="cursor-pointer text-destructive hover:text-destructive">
                        <Trash2 className="size-4" />
                        Drop
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Drop table "{selected.name}"?</DialogTitle>
                        <DialogDescription>
                          Deletes the schema and all {formatNumber(selected.rowCount)}{" "}
                          row(s). This can't be undone.
                        </DialogDescription>
                      </DialogHeader>
                      <DialogFooter>
                        <Button variant="outline" className="cursor-pointer">
                          Cancel
                        </Button>
                        <Button
                          variant="destructive"
                          className="cursor-pointer"
                          onClick={async () => {
                            await deleteTable({
                              projectId,
                              tableId: selected._id,
                            });
                            toast.success(`Table "${selected.name}" dropped`);
                          }}
                        >
                          Drop table
                        </Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                </div>
              </div>

              <div className="flex flex-wrap gap-2">
                {selected.fields.map((field) => (
                  <span
                    key={field.name}
                    className="inline-flex items-center gap-1.5 rounded-md border border-border px-2 py-1 font-mono text-[11px]"
                  >
                    {field.name}
                    <span className="text-muted-foreground">{field.type}</span>
                    {field.required ? <span className="text-primary">*</span> : null}
                    {field.unique ? (
                      <span className="text-chart-2" title="unique">
                        U
                      </span>
                    ) : null}
                    {field.refTable ? (
                      <span className="text-chart-3">→ {field.refTable}</span>
                    ) : null}
                  </span>
                ))}
              </div>

              <CodeBlock
                language={`curl · ${apiBase()}/db/${selected.name}`}
                code={`# List rows (filter any column: ?status=active)
curl "${apiBase()}/db/${selected.name}?limit=50" \\
  -H "X-API-Key: fd53_live_…"

# Insert a row
curl -X POST ${apiBase()}/db/${selected.name} \\
  -H "X-API-Key: fd53_live_…" \\
  -H "Content-Type: application/json" \\
  -d '{"data":{${selected.fields
    .map((f) => {
      if (f.type === "number") return `"${f.name}": 0`;
      if (f.type === "boolean") return `"${f.name}": false`;
      if (f.type === "json") return `"${f.name}": {}`;
      if (f.type === "datetime")
        return `"${f.name}": "2026-01-01T00:00:00.000Z"`;
      if (f.type === "reference")
        return `"${f.name}": "<${f.refTable}-row-id>"`;
      return `"${f.name}": "${f.name}"`;
    })
    .join(", ")}}}'`}
              />

              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <div className="relative flex-1">
                    <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" />
                    <Input
                      value={search}
                      onChange={(event) => setSearch(event.target.value)}
                      placeholder="Search rows…"
                      className="pl-9"
                    />
                  </div>
                  <span className="shrink-0 text-xs text-muted-foreground">
                    {rows ? `${formatNumber(rows.total)} rows` : ""}
                  </span>
                </div>

                <div className="overflow-x-auto rounded-lg border border-border bg-card">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        {selected.fields.map((field) => (
                          <TableHead key={field.name} className="font-mono text-[11px]">
                            {field.name}
                          </TableHead>
                        ))}
                        <TableHead className="w-10" />
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {rows && rows.items.length > 0 ? (
                        rows.items.map((row) => (
                          <TableRow key={row._id}>
                            {selected.fields.map((field) => (
                              <TableCell key={field.name} className="font-mono text-xs">
                                {previewValue(row.data[field.name])}
                              </TableCell>
                            ))}
                            <TableCell>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="size-7 cursor-pointer text-muted-foreground hover:text-destructive"
                                onClick={async () => {
                                  await deleteRow({
                                    projectId,
                                    rowId: row._id,
                                  });
                                  toast.success("Row deleted");
                                }}
                              >
                                <Trash2 className="size-3.5" />
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))
                      ) : (
                        <TableRow>
                          <TableCell
                            colSpan={selected.fields.length + 1}
                            className="py-10 text-center text-sm text-muted-foreground"
                          >
                            No rows yet — insert one from the API or the button above.
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </div>
                {rows && rows.items[0] ? (
                  <p className="text-[11px] text-muted-foreground">
                    Newest row created {timeAgo(rows.items[0]._creationTime)} · id{" "}
                    <code className="font-mono">{rows.items[0]._id}</code>
                  </p>
                ) : null}
              </div>

              <p className="flex items-start gap-2 text-xs text-muted-foreground">
                <KeyRound className="mt-0.5 size-3.5 shrink-0" />
                Access levels apply to end-user tokens. Calls with only your API key
                always have full project access.
              </p>
            </div>
          ) : null}
        </div>
      )}

      {projectId ? (
        <>
          <TableDialog
            open={tableDialogOpen}
            onOpenChange={setTableDialogOpen}
            existingTables={tables.map((t) => t.name)}
            projectId={projectId}
          />
          {selected ? (
            <RowDialog
              open={rowDialogOpen}
              onOpenChange={setRowDialogOpen}
              fields={selected.fields.map((f) => ({
                name: f.name,
                type: f.type,
                required: f.required,
              }))}
              projectId={projectId}
              tableId={selected._id}
            />
          ) : null}
        </>
      ) : null}
    </div>
  );
}