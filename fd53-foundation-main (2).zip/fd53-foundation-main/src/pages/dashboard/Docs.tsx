import { useState } from "react";
import {
  Boxes,
  Braces,
  Database,
  FileCode2,
  HardDrive,
  Lock,
  Radio,
  ShieldCheck,
  ShoppingBag,
  Smartphone,
} from "lucide-react";
import { useProject } from "@/components/dashboard/ProjectProvider";
import { CodeBlock, PageHeader } from "@/components/dashboard/ui";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { apiBase } from "@/lib/fd53";

const TABS = [
  { value: "quickstart", label: "Quickstart", icon: Boxes },
  { value: "openapi", label: "OpenAPI", icon: FileCode2 },
  { value: "auth", label: "Auth", icon: Lock },
  { value: "database", label: "Database", icon: Database },
  { value: "storage", label: "Storage", icon: HardDrive },
  { value: "realtime", label: "Realtime", icon: Radio },
  { value: "loopuni", label: "LoopUni", icon: ShoppingBag },
  { value: "flutterflow", label: "FlutterFlow", icon: Smartphone },
  { value: "architecture", label: "Architecture", icon: Braces },
  { value: "security", label: "Security", icon: ShieldCheck },
];

function Endpoint({
  method,
  path,
  description,
}: {
  method: string;
  path: string;
  description: string;
}) {
  const tone =
    method === "GET"
      ? "text-chart-3"
      : method === "POST"
        ? "text-chart-1"
        : method === "DELETE"
          ? "text-destructive"
          : "text-chart-2";
  return (
    <div className="flex flex-col gap-1 border-b border-border py-2.5 last:border-0 sm:flex-row sm:items-baseline sm:gap-3">
      <code className={`shrink-0 font-mono text-xs font-semibold ${tone}`}>{method}</code>
      <code className="font-mono text-xs text-muted-foreground">{path}</code>
      <span className="text-sm text-muted-foreground">{description}</span>
    </div>
  );
}

export default function Docs() {
  const { projectId } = useProject();
  const [tab, setTab] = useState("quickstart");
  const base = apiBase();
  const hasProject = Boolean(projectId);

  const register = `curl -X POST ${base}/v1/auth/register \\
  -H "X-API-Key: fd53_live_…" \\
  -H "Content-Type: application/json" \\
  -d '{"email":"sam@example.com","password":"correct-horse","name":"Sam"}'`;
  const login = `curl -X POST ${base}/v1/auth/login \\
  -H "X-API-Key: fd53_live_…" \\
  -H "Content-Type: application/json" \\
  -d '{"email":"sam@example.com","password":"correct-horse"}'`;
  const meCall = `curl ${base}/v1/auth/me \\
  -H "X-API-Key: fd53_live_…" \\
  -H "Authorization: Bearer <token from login>"`;

  // Built with array joins so shell line-continuations stay readable without
  // fighting nested template-literal escaping.
  const loopuniPost = [
    "# 1. Register — get a token and a @handle",
    `curl -X POST ${base}/v1/auth/register \\`,
    '  -H "X-API-Key: fd53_live_…" -H "Content-Type: application/json" \\',
    `  -d '{"email":"sam@example.com","password":"correct-horse","username":"sam"}'`,
    "",
    "# 2. Upload a photo to the post-media bucket",
    `curl -X POST "${base}/v1/storage/upload?bucket=post-media" \\`,
    '  -H "X-API-Key: fd53_live_…" -H "Content-Type: application/json" \\',
    `  -d '{"path":"posts/1.png","mimeType":"image/png","contentBase64":"iVBORw0..."}'`,
    "",
    "# 3. Create the post",
    `curl -X POST ${base}/v1/posts/create \\`,
    '  -H "X-API-Key: fd53_live_…" \\',
    '  -H "Authorization: Bearer <token>" -H "Content-Type: application/json" \\',
    `  -d '{"text":"hello #launch","media":[{"fileId":"<id>","kind":"image","width":1080,"height":1920}]}'`,
  ].join("\n");

  const loopuniMarket = [
    "# Follow by @handle",
    `curl -X POST ${base}/v1/users/sam/follow \\`,
    '  -H "X-API-Key: fd53_live_…" -H "Authorization: Bearer <token>"',
    "",
    "# Sell a digital product — the asset must live in the private receipts bucket",
    `curl -X POST "${base}/v1/storage/upload?bucket=receipts" \\`,
    '  -H "X-API-Key: fd53_live_…" -H "Content-Type: application/json" \\',
    `  -d '{"path":"assets/course.pdf","mimeType":"application/pdf","contentBase64":"JVBER..."}'`,
    "",
    `curl -X POST ${base}/v1/marketplace/products \\`,
    '  -H "X-API-Key: fd53_live_…" -H "Authorization: Bearer <seller token>" \\',
    '  -H "Content-Type: application/json" \\',
    `  -d '{"title":"Masterclass","priceCents":4999,"assetFileId":"<id>"}'`,
    "",
    "# Buy it",
    `curl -X POST ${base}/v1/marketplace/orders/checkout \\`,
    '  -H "X-API-Key: fd53_live_…" -H "Authorization: Bearer <buyer token>" \\',
    '  -H "Content-Type: application/json" \\',
    `  -d '{"productId":"<id>","quantity":2}'`,
  ].join("\n");

  return (
    <div className="space-y-6">
      <PageHeader
        title="API documentation"
        description={`Everything your app talks to. Base URL: ${base}`}
      />

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList className="flex h-auto flex-wrap justify-start gap-1">
          {TABS.map((item) => (
            <TabsTrigger key={item.value} value={item.value} className="cursor-pointer">
              <item.icon className="size-3.5" />
              {item.label}
            </TabsTrigger>
          ))}
        </TabsList>

        {/* ---------------------------------------------------------- quickstart */}
        <TabsContent value="quickstart" className="mt-6 space-y-6">
          <section className="space-y-3">
            <h2 className="tracking-tight font-bold">1 · Get a key</h2>
            <p className="text-sm text-muted-foreground">
              Create a project, then a key on the API Keys page. Keys are shown once
              and stored as a SHA-256 hash.
            </p>
          </section>
          <section className="space-y-3">
            <h2 className="tracking-tight font-bold">2 · Call the API</h2>
            <p className="text-sm text-muted-foreground">
              Every <code className="font-mono">/v1</code> endpoint needs the key in
              the <code className="font-mono">X-API-Key</code> header (or as a
              bearer token). End-user tokens go in{" "}
              <code className="font-mono">Authorization: Bearer</code> instead.
            </p>
            <CodeBlock
              code={`curl ${base}/v1/health   # no key needed

curl ${base}/v1/db/tables \\
  -H "X-API-Key: fd53_live_…"`}
            />
          </section>
          <section className="space-y-3">
            <h2 className="tracking-tight font-bold">3 · Response envelope</h2>
            <CodeBlock
              language="json"
              code={`{
  "ok": true,
  "data": { "…": "endpoint specific" }
}

// errors
{
  "ok": false,
  "error": { "code": "invalid_row", "message": "\\"views\\" must be a finite number." }
}`}
            />
            <p className="text-sm text-muted-foreground">
              Status codes: 2xx success · 400 invalid request · 401 missing/invalid key
              or token · 403 permission denied · 404 not found · 413 too large /
              quota · 429 rate limited (with <code className="font-mono">Retry-After</code>) ·
              500 internal.
            </p>
          </section>
          {!hasProject ? (
            <p className="rounded-md border border-chart-2/40 bg-chart-2/10 px-3 py-2 text-sm">
              Create a project first — the console pages below need one.
            </p>
          ) : null}
        </TabsContent>

        {/* ----------------------------------------------------------- openapi */}
        <TabsContent value="openapi" className="mt-6 space-y-5">
          <p className="text-sm text-muted-foreground">
            FD53 publishes an OpenAPI 3.1 specification covering every endpoint.
            It is generated from the live route table, so it can never drift
            from what the API actually serves. Point Swagger UI, Postman,
            FlutterFlow&apos;s API importer, or any SDK generator at the URL
            below.
          </p>

          <section className="space-y-2">
            <h3 className="font-semibold">Specification endpoint</h3>
            <CodeBlock language="text" code={`${base}/v1/openapi.json`} />
            <p className="text-sm text-muted-foreground">
              No API key required — it contains no project data. Common
              consumers: Swagger UI, Postman, Insomnia, FlutterFlow, and the
              FD53 SDK generator.
            </p>
          </section>

          <section className="space-y-2">
            <h3 className="font-semibold">Browse it interactively</h3>
            <CodeBlock
              language="text"
              code={`https://petstore.swagger.io/?url=${base}/v1/openapi.json`}
            />
          </section>

          <section className="space-y-2">
            <h3 className="font-semibold">What the spec declares</h3>
            <div className="grid gap-3 sm:grid-cols-2">
              {[
                {
                  title: "Security schemes",
                  body: "Two, kept deliberately separate: the X-API-Key header authenticates your backend, and a bearer JWT authenticates your end users.",
                },
                {
                  title: "Every endpoint",
                  body: "All routes appear with their method, path parameters, request bodies and status codes — including the ones outside auth, storage and database.",
                },
                {
                  title: "Shared schemas",
                  body: "Error envelopes, sessions, end users, tables, rows, files and buckets are defined once and referenced everywhere.",
                },
                {
                  title: "FD53 extensions",
                  body: "An x-fd53 block carries the permission list, plan limits and bucket definitions so generators can produce correct client code.",
                },
              ].map((item) => (
                <div key={item.title} className="rounded-lg border border-border bg-card p-4">
                  <p className="font-semibold">{item.title}</p>
                  <p className="mt-1 text-sm text-muted-foreground">{item.body}</p>
                </div>
              ))}
            </div>
          </section>

          <CodeBlock
            language="generating a client"
            code={`# Generate a typed client from the live spec
npx @openapitools/openapi-generator-cli generate \\
  -i ${base}/v1/openapi.json \\
  -g typescript-fetch -o ./src/fd53

# Or import it straight into FlutterFlow
# Integrations → REST API → Add → Import OpenAPI → paste the URL above`}
          />
        </TabsContent>

        {/* ------------------------------------------------------------- auth */}
        <TabsContent value="auth" className="mt-6 space-y-5">
          <p className="text-sm text-muted-foreground">
            FD53 Auth issues HS256 access tokens (24 h) backed by revocable
            server-side sessions. Passwords are hashed with PBKDF2-SHA256 (60k
            iterations) and never leave the backend.
          </p>
          <div>
            <Endpoint method="POST" path="/v1/auth/register" description="Create an account (email + password, phone, or both)." />
            <Endpoint method="POST" path="/v1/auth/login" description="Email or phone + password → token." />
            <Endpoint method="POST" path="/v1/auth/otp/request" description="Send a 6-digit code to a phone number." />
            <Endpoint method="POST" path="/v1/auth/otp/verify" description="Verify the code → token (creates the user on first sign-in)." />
            <Endpoint method="GET" path="/v1/auth/me" description="Current user, role and permissions." />
            <Endpoint method="POST" path="/v1/auth/logout" description="Revoke the current session." />
            <Endpoint method="POST" path="/v1/auth/token/verify" description="Check whether a token is still valid." />
            <Endpoint method="POST" path="/v1/auth/password" description="Change password (current + new)." />
            <Endpoint method="POST" path="/v1/auth/password/reset" description="Request a reset token." />
            <Endpoint method="POST" path="/v1/auth/password/reset/confirm" description="Set a new password; revokes all sessions." />
            <Endpoint method="GET" path="/v1/auth/roles" description="List roles and their permissions." />
          </div>
          <div className="grid gap-4 lg:grid-cols-2">
            <CodeBlock language="register" code={register} />
            <div className="space-y-4">
              <CodeBlock language="login" code={login} />
              <CodeBlock language="authenticated call" code={meCall} />
            </div>
          </div>
          <div className="rounded-md border border-chart-2/40 bg-chart-2/10 p-3 text-sm">
            <p className="font-medium">v1 delivery note</p>
            <p className="text-muted-foreground">
              No SMS or email provider is wired up yet, so OTP codes and password
              reset tokens come back in the response (<code className="font-mono">devCode</code> /{" "}
              <code className="font-mono">resetToken</code>) so flows are testable.
              Send them through a real provider before production — the hook points
              are in <code className="font-mono">src/convex/rest/auth.ts</code>.
            </p>
          </div>
        </TabsContent>

        {/* --------------------------------------------------------- database */}
        <TabsContent value="database" className="mt-6 space-y-5">
          <p className="text-sm text-muted-foreground">
            Tables are defined with columns of type string, number, boolean, datetime,
            json or reference. Every write is validated: required columns, types,
            unique constraints and reference integrity.
          </p>
          <div>
            <Endpoint method="GET" path="/v1/db/tables" description="List tables + schema." />
            <Endpoint method="POST" path="/v1/db/tables" description="Create a table." />
            <Endpoint method="GET" path="/v1/db/tables/:table" description="Schema of one table." />
            <Endpoint method="PATCH" path="/v1/db/tables/:table" description="Update columns or access level." />
            <Endpoint method="DELETE" path="/v1/db/tables/:table" description="Drop a table and its rows." />
            <Endpoint method="GET" path="/v1/db/:table" description="List rows — ?limit= &offset= &column=value filters." />
            <Endpoint method="POST" path="/v1/db/:table" description="Insert a row." />
            <Endpoint method="GET" path="/v1/db/:table/:id" description="Read one row." />
            <Endpoint method="PATCH" path="/v1/db/:table/:id" description="Partial update (merged with existing values)." />
            <Endpoint method="DELETE" path="/v1/db/:table/:id" description="Delete a row." />
          </div>
          <CodeBlock
            language="define + query"
            code={`curl -X POST ${base}/v1/db/tables \\
  -H "X-API-Key: fd53_live_…" -H "Content-Type: application/json" \\
  -d '{
    "name": "posts",
    "access": "owner",
    "fields": [
      {"name": "title", "type": "string", "required": true},
      {"name": "views", "type": "number"},
      {"name": "tag",  "type": "string", "unique": true},
      {"name": "author", "type": "reference", "refTable": "authors"}
    ]
  }'

# Query (filters apply to any indexed column)
curl "${base}/v1/db/posts?published=true&limit=20&offset=0" \\
  -H "X-API-Key: fd53_live_…"`}
          />
          <div className="space-y-2">
            <h3 className="font-semibold">Access levels</h3>
            <ul className="space-y-1 text-sm text-muted-foreground">
              <li>
                <Badge variant="secondary" className="mr-2">public</Badge>
                any call with your API key (used for FlutterFlow server actions).
              </li>
              <li>
                <Badge variant="secondary" className="mr-2">authenticated</Badge>
                end users must send a valid token with <code className="font-mono">db:read</code> / <code className="font-mono">db:write</code>.
              </li>
              <li>
                <Badge variant="secondary" className="mr-2">owner</Badge>
                each end user only sees and edits rows they created (admins see all).
              </li>
            </ul>
          </div>
        </TabsContent>

        {/* ---------------------------------------------------------- storage */}
        <TabsContent value="storage" className="mt-6 space-y-5">
          <p className="text-sm text-muted-foreground">
            Images, video, audio and documents, organised into buckets. Free plan: 250
            MB per project, 25 MB per file. Files without an explicit{" "}
            <code className="font-mono">bucket</code> fall into one based on their
            mime type.
          </p>
          <div>
            <Endpoint method="GET" path="/v1/storage/buckets" description="Bucket definitions + per-bucket file counts and bytes." />
            <Endpoint method="POST" path="/v1/storage/upload" description="Upload — multipart, raw binary or JSON+base64. ?bucket= sets the target." />
            <Endpoint method="GET" path="/v1/storage/files" description="List files — ?prefix= &bucket= &limit=." />
            <Endpoint method="GET" path="/v1/storage/files/:id" description="File metadata + signed URL (?redirect=true to 302)." />
            <Endpoint method="DELETE" path="/v1/storage/files/:id" description="Delete and free quota." />
          </div>
          <div className="space-y-2">
            <h3 className="font-semibold">Buckets</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li className="flex flex-col gap-1 sm:flex-row sm:items-baseline sm:gap-3">
                <Badge variant="secondary" className="shrink-0 font-mono">avatars</Badge>
                <span>
                  Profile pictures and header banners. <strong>Public</strong> —{" "}
                  <code className="font-mono">GET /v1/storage/buckets</code> reports its
                  visibility. Images/video/audio only.
                </span>
              </li>
              <li className="flex flex-col gap-1 sm:flex-row sm:items-baseline sm:gap-3">
                <Badge variant="secondary" className="shrink-0 font-mono">post-media</Badge>
                <span>Post images and video streams. <strong>Public</strong>, media mime types only.</span>
              </li>
              <li className="flex flex-col gap-1 sm:flex-row sm:items-baseline sm:gap-3">
                <Badge variant="secondary" className="shrink-0 font-mono">receipts</Badge>
                <span>
                  Digital downloads and purchase invoices. <strong>Private</strong> — the
                  bucket forces private visibility and only the uploader, the buyer or an
                  admin can read the file.
                </span>
              </li>
            </ul>
            <p className="text-sm text-muted-foreground">
              Bucket visibility is enforced server-side: passing{" "}
              <code className="font-mono">?visibility=public</code> to a{" "}
              <code className="font-mono">receipts</code> upload is ignored.
            </p>
          </div>
          <div className="grid gap-4 lg:grid-cols-2">
            <CodeBlock
              language="multipart (FlutterFlow)"
              code={`curl -X POST "${base}/v1/storage/upload?bucket=avatars" \\
  -H "X-API-Key: fd53_live_…" \\
  -F "file=@avatar.png"`}
            />
            <CodeBlock
              language="base64 / raw"
              code={`# JSON + base64
curl -X POST "${base}/v1/storage/upload?bucket=post-media" \\
  -H "X-API-Key: fd53_live_…" -H "Content-Type: application/json" \\
  -d '{"path":"me.png","mimeType":"image/png","contentBase64":"iVBORw0K…"}'

# raw binary
curl -X POST "${base}/v1/storage/upload?bucket=receipts&path=invoice.pdf" \\
  -H "X-API-Key: fd53_live_…" \\
  -H "Content-Type: application/pdf" --data-binary @invoice.pdf`}
            />
          </div>
        </TabsContent>

        {/* --------------------------------------------------------- realtime */}
        <TabsContent value="realtime" className="mt-6 space-y-5">
          <p className="text-sm text-muted-foreground">
            Publish events to channels (chat rooms, notifications, live scores). The
            console feed updates instantly because it subscribes to Convex
            queries. Client apps can poll the REST endpoint or subscribe with the
            Convex client for true push delivery — see the roadmap.
          </p>
          <div>
            <Endpoint method="POST" path="/v1/realtime/publish" description="Publish {channel, type, payload}." />
            <Endpoint method="GET" path="/v1/realtime/channels" description="Channels with event counts." />
            <Endpoint method="GET" path="/v1/realtime/channels/:channel/events" description="Recent events on a channel." />
          </div>
          <CodeBlock
            code={`curl -X POST ${base}/v1/realtime/publish \\
  -H "X-API-Key: fd53_live_…" -H "Content-Type: application/json" \\
  -d '{"channel":"chat.room1","type":"message","payload":{"text":"hello"}}'`}
          />
        </TabsContent>

        {/* --------------------------------------------------------- loopuni */}
        <TabsContent value="loopuni" className="mt-6 space-y-5">
          <p className="text-sm text-muted-foreground">
            A complete social + marketplace backend, ready to drive from an app.
            Registration mints a LoopUni identity and a public{" "}
            <code className="font-mono">@handle</code>; all social and marketplace
            writes need an end-user token and pass through per-user anti-spam limits.
          </p>

          <div className="space-y-2">
            <h3 className="font-semibold">Auth</h3>
            <div>
              <Endpoint method="POST" path="/v1/auth/register" description='Create an account → JWT + profile. Optional "username" claims a @handle.' />
              <Endpoint method="POST" path="/v1/auth/login" description="Email + password → JWT + profile." />
            </div>
          </div>

          <div className="space-y-2">
            <h3 className="font-semibold">Profiles &amp; social graph</h3>
            <div>
              <Endpoint method="GET" path="/v1/users/profile/:username" description="Profile by @handle (case-insensitive) + their recent posts." />
              <Endpoint method="POST" path="/v1/users/:id/follow" description="Follow a user. :id accepts a user id or an @handle. 201 first time, 200 after." />
              <Endpoint method="POST" path="/v1/users/:id/unfollow" description="Remove a follow edge and decrement both counters." />
            </div>
          </div>

          <div className="space-y-2">
            <h3 className="font-semibold">Feed</h3>
            <div>
              <Endpoint method="POST" path="/v1/posts/create" description="Create a text/photo/video post. Media references files uploaded to post-media." />
              <Endpoint method="GET" path="/v1/posts/:id" description="One post with its media and author." />
              <Endpoint method="GET" path="/v1/feed/home" description="Home feed — followed authors when signed in, otherwise discovery. ?limit=." />
            </div>
          </div>

          <div className="space-y-2">
            <h3 className="font-semibold">Messaging &amp; moderation</h3>
            <div>
              <Endpoint method="POST" path="/v1/messages/send" description='Send a message. "to": "@handle" opens the 1:1 room, "roomId" replies in one.' />
              <Endpoint method="GET" path="/v1/messages/:roomId" description="Message history (newest last). ?limit=." />
              <Endpoint method="POST" path="/v1/reports/create" description="Flag a user/post/comment/message/product for moderation." />
            </div>
          </div>

          <div className="space-y-2">
            <h3 className="font-semibold">Marketplace</h3>
            <div>
              <Endpoint method="POST" path="/v1/marketplace/products" description="Create a listing. priceCents is an integer; digital assets must live in the receipts bucket." />
              <Endpoint method="GET" path="/v1/marketplace/products" description="Browse listings — ?seller=@handle, ?category=, ?limit=." />
              <Endpoint method="GET" path="/v1/marketplace/products/:id" description="One listing." />
              <Endpoint method="POST" path="/v1/marketplace/orders/checkout" description="Purchase → order + creatorEarnings ledger row. Fee is computed server-side (10%)." />
              <Endpoint method="GET" path="/v1/marketplace/orders" description="The caller's purchase history." />
              <Endpoint method="GET" path="/v1/marketplace/earnings" description="Seller wallet: gross, platform fee, available and pending balances." />
            </div>
          </div>

          <div className="grid gap-4 lg:grid-cols-2">
            <CodeBlock language="register + post" code={loopuniPost} />
            <CodeBlock language="follow + checkout" code={loopuniMarket} />
          </div>

          <div className="space-y-2">
            <h3 className="font-semibold">Per-user anti-spam</h3>
            <p className="text-sm text-muted-foreground">
              On top of the per-key limit, each write path has a fixed window per end
              user so one abusive account cannot burn your app's quota. Over the
              limit you get <code className="font-mono">429</code> with{" "}
              <code className="font-mono">Retry-After</code>; currently throttled
              callers are listed on the Usage page.
            </p>
            <CodeBlock
              language="limits"
              code={`register   10 / hour   per IP
login      20 / 15 min per email or phone
post       30 / hour   per user
follow    200 / hour   per user
message    60 / min    per user
checkout   20 / hour   per user
product    60 / hour   per user
report     10 / hour   per user`}
            />
          </div>

          <p className="text-sm text-muted-foreground">
            Money is always integer minor units (<code className="font-mono">priceCents</code>) —
            never floats — and the 10% platform fee is computed on the server, so a
            client can never choose its own payout.
          </p>
        </TabsContent>

        {/* ------------------------------------------------------ flutterflow */}
        <TabsContent value="flutterflow" className="mt-6 space-y-5">
          <div className="space-y-2">
            <h3 className="font-semibold">1 · Define your backend once</h3>
            <ol className="list-decimal space-y-1 pl-5 text-sm text-muted-foreground">
              <li>Create a project in this console (one per app).</li>
              <li>Add your tables under Database, and files under Storage.</li>
              <li>Create an API key per environment — keep the production key server-side.</li>
            </ol>
          </div>
          <div className="space-y-2">
            <h3 className="font-semibold">2 · Call it from FlutterFlow</h3>
            <ul className="list-disc space-y-1 pl-5 text-sm text-muted-foreground">
              <li>
                <strong>API calls / server actions</strong>: add header{" "}
                <code className="font-mono">X-API-Key: fd53_live_…</code> and URL{" "}
                <code className="font-mono">{base}/v1/db/&lt;table&gt;</code>.
              </li>
              <li>
                <strong>Authentication</strong>: call{" "}
                <code className="font-mono">/v1/auth/login</code> from a server
                action, store the returned token in a FlutterFlow State Variable and
                send it as <code className="font-mono">Authorization: Bearer …</code> on
                later calls.
              </li>
              <li>
                <strong>File upload</strong>: use an API call with{" "}
                <code className="font-mono">multipart/form-data</code> — the same
                shape as FlutterFlow's native upload, so you can keep the default
                file widget and just change the URL.
              </li>
              <li>
                <strong>Displaying files</strong>: use the{" "}
                <code className="font-mono">url</code> returned by the upload/list
                call in an Image widget.
              </li>
            </ul>
          </div>
          <CodeBlock
            language="FlutterFlow server action (Dart)"
            code={`import 'package:http/http.dart' as http;
import 'dart:convert';

const base = '${base}';
const key = 'fd53_live_…';

Future<Map<String, dynamic>> signIn(String email, String password) async {
  final res = await http.post(
    Uri.parse('\$base/v1/auth/login'),
    headers: {'X-API-Key': key, 'Content-Type': 'application/json'},
    body: jsonEncode({'email': email, 'password': password}),
  );
  final body = jsonDecode(res.body);
  return body['data'];
}

Future<List<dynamic>> listRows(String token) async {
  final res = await http.get(
    Uri.parse('\$base/v1/db/posts?limit=50'),
    headers: {'X-API-Key': key, 'Authorization': 'Bearer \$token'},
  );
  return jsonDecode(res.body)['data']['items'] as List<dynamic>;
}`}
          />
          <p className="text-sm text-muted-foreground">
            Tip: FlutterFlow web builds call the API from the browser. FD53 sends
            permissive CORS headers, so no proxy is needed; the API key is still
            visible in the network tab, so prefer server actions for anything
            sensitive.
          </p>
        </TabsContent>

        {/* ----------------------------------------------------- architecture */}
        <TabsContent value="architecture" className="mt-6 space-y-5">
          <section className="space-y-2">
            <h3 className="font-semibold">Request flow</h3>
            <CodeBlock
              language="architecture"
              code={`FlutterFlow / native app
        │  X-API-Key  +  Authorization: Bearer <user token>
        ▼
/v1/*  (Convex HTTP actions — src/convex/http.ts)
        │  1. authenticateKey()        sha256(key) → apiKeys doc (hashed at rest)
        │  2. enforceQuota()           sliding window per key → 429 + Retry-After
        │  3. authenticateEndUser()    HS256 signature + session lookup + role
        │  4. enforceAntiSpam()        fixed window per end user (LoopUni writes)
        │  5. handler                  src/convex/rest/{auth,database,storage,realtime,
        │                             social,marketplace}.ts
        │  6. requestLog.record()      → the Usage dashboard's request table
        ▼
Convex (queries / mutations / actions + file storage)
        projects · apiKeys · tables · rows · endUsers · sessions · roles
        files · phoneOtps · passwordResets · rateBuckets · usageDaily
        events · requestLogs
        profiles · posts · media · follows · conversations · messages
        products · orders · creatorEarnings · rateLimits · reports`}
            />
          </section>
          <section className="space-y-2">
            <h3 className="font-semibold">Data model</h3>
            <CodeBlock
              language="schema.ts"
              code={`projects     owner, slug, plan, quotas, storageBytes
apiKeys      project, keyPrefix, keyHash(sha256), scopes, rateLimit, revokedAt
tables       project, name, access(public|authenticated|owner), fields[], rowCount
rows         project, table, data{}, ownerId          ← generic document store
uniqueValues project, table, field, value, rowId     ← O(1) unique checks
endUsers     project, email/phone, passwordHash+salt, role, tokenVersion
sessions     project, endUser, sid, expiresAt, revokedAt
roles        project, name, permissions[], isDefault
files        project, path, mime, size, storageId, visibility, bucket, ownerId
phoneOtps    project, phone, codeHash(peppered), expiresAt, attempts
rateBuckets  key, minute-bucket, count               ← per-API-key rate limiting
usageDaily   project, day, category, count, errorCount
events       project, channel, type, payload         ← realtime
requestLogs  project, method, path, route, category, status, durationMs
secrets      fd53.jwt, fd53.otp                      ← server-side only

── LoopUni domain ──
users        name/email, username+usernameLower, isCreator, tokenVersion
profiles     user, handle(+Lower, unique), bio, avatarUrl, bannerUrl,
             followerCount / followingCount / postCount, isCreator, isVerified
posts        author, text, kind(text|photo|video), aspectRatio, mediaCount,
             like/comment/share counts, visibility, hashtags[]
media        post, owner, bucket, fileId, url, kind, width/height,
             aspectRatio, durationMs, position
follows      followerId → followingId, status(active|pending)
conversations project, roomId, type(direct|group), participantIds[],
             lastMessageAt, lastMessagePreview
messages     conversation, roomId, sender, text, kind, mediaIds[], readAt
products     seller, title, priceCents, currency, kind, status, mediaIds[],
             assetFileId (private), inventory, salesCount
orders       buyer, seller, product, quantity, amountCents, platformFeeCents,
             status(pending|paid|failed|refunded), receiptFileId, paymentRef
creatorEarnings creator, order, product, gross/fee/net cents, status, availableAt
rateLimits   project, key("post:<id>"), windowStart, count, blockedUntil
             ↑ per-end-user anti-spam (separate from rateBuckets)
reports      project, reporter, targetType, targetId, reason, status`}
            />
          </section>
          <section className="space-y-2">
            <h3 className="font-semibold">Folder structure</h3>
            <CodeBlock
              language="text"
              code={`src/
├── convex/                  ← the FD53 backend
│   ├── schema.ts            data model
│   ├── http.ts              /v1 REST router wiring
│   ├── rest/                endpoint handlers
│   │   ├── router.ts        route table, auth + quota + anti-spam + request log
│   │   ├── auth.ts          register/login/otp/password/sessions
│   │   ├── database.ts      tables + rows
│   │   ├── storage.ts       uploads (multipart/raw/base64) + buckets
│   │   ├── realtime.ts      publish / channels
│   │   ├── social.ts        profiles, follows, posts, feed, messages, reports
│   │   ├── marketplace.ts   products, checkout, orders, earnings
│   │   ├── actor.ts         end-user token → LoopUni identity resolver
│   │   └── meta.ts          health, service index, usage
│   ├── lib/
│   │   ├── crypto.ts        PBKDF2, HMAC, JWT (Web Crypto)
│   │   ├── rest.ts          CORS, envelope, API-key + user auth, quotas, anti-spam
│   │   ├── constants.ts     plan limits, roles, buckets, anti-spam limits
│   │   └── authz.ts         project ownership guard
│   ├── projects.ts          console CRUD + cascade delete
│   ├── apiKeys.ts           key minting (action) / revoke
│   ├── tables.ts            schema CRUD + validation
│   ├── rows.ts              document CRUD + validation
│   ├── endUsers.ts          app users, lockouts
│   ├── sessions.ts          revocation
│   ├── roles.ts             permissions
│   ├── files.ts             storage records, buckets + quota
│   ├── usage.ts             rate buckets + counters
│   ├── realtime.ts          events
│   ├── identity.ts          LoopUni users + profiles
│   ├── social.ts            posts, media, follows
│   ├── messaging.ts         conversations + messages
│   ├── marketplace.ts       products, orders, earnings
│   ├── rateLimits.ts        per-end-user anti-spam
│   ├── reports.ts           moderation queue
│   ├── requestLog.ts        per-request logging for the Usage page
│   └── secrets.ts           server-only secrets
├── pages/
│   ├── Landing.tsx          public site
│   ├── Dashboard.tsx        console shell + sidebar
│   └── dashboard/           overview, projects, keys, db, storage, users, usage, docs
└── components/dashboard/    console UI + project context`}
            />
          </section>
          <section className="space-y-2">
            <h3 className="font-semibold">Deployment</h3>
            <CodeBlock
              language="text"
              code={`# Development
bun install
bun convex dev            # pushes functions + regenerates _generated types
bun run dev              # Vite dev server for the console

# Production
bun convex deploy --prod  # push functions to the production deployment
bun run build            # typecheck + build the console (static output)

# The API is served by the deployment itself:
#   development : https://<deployment>.convex.site/v1
#   production  : https://<deployment>.convex.site/v1
# No extra servers, containers or DNS are required — Convex hosts the
# database, file storage and HTTP endpoints.

# Environment (optional)
FD53_*  — reserved for the SMS/email providers in v2.
JWT/OTP signing keys are generated on first use and stored in the
\`secrets\` table, so nothing has to be configured to get started.`}
            />
          </section>
          <section className="space-y-2">
            <h3 className="font-semibold">Roadmap</h3>
            <div className="overflow-x-auto rounded-lg border border-border">
              <table className="w-full text-sm">
                <thead className="bg-muted/40 text-left text-xs tracking-wide uppercase">
                  <tr>
                    <th className="px-3 py-2">Version</th>
                    <th className="px-3 py-2">Focus</th>
                    <th className="px-3 py-2">What lands</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  <tr>
                    <td className="px-3 py-2 font-mono text-xs">v1 — now</td>
                    <td className="px-3 py-2">Foundation</td>
                    <td className="px-3 py-2 text-muted-foreground">
                      Auth (email/phone, sessions, roles), database with validation +
                      references + unique, storage with quotas, REST API + keys,
                      console, rate limiting, realtime events.
                    </td>
                  </tr>
                  <tr>
                    <td className="px-3 py-2 font-mono text-xs">v1.1</td>
                    <td className="px-3 py-2">Delivery</td>
                    <td className="px-3 py-2 text-muted-foreground">
                      Real SMS + email providers for OTP and password reset, custom
                      email templates, email verification flow.
                    </td>
                  </tr>
                  <tr>
                    <td className="px-3 py-2 font-mono text-xs">v1.2</td>
                    <td className="px-3 py-2">Realtime</td>
                    <td className="px-3 py-2 text-muted-foreground">
                      SSE/WebSocket stream endpoint, presence, typed channels, chat +
                      notification helpers.
                    </td>
                  </tr>
                  <tr>
                    <td className="px-3 py-2 font-mono text-xs">v1.3</td>
                    <td className="px-3 py-2">Scale</td>
                    <td className="px-3 py-2 text-muted-foreground">
                      Compound filters/aggregation queries, compound indexes, bigger
                      file limits, resumable uploads.
                    </td>
                  </tr>
                  <tr>
                    <td className="px-3 py-2 font-mono text-xs">v2</td>
                    <td className="px-3 py-2">Platform</td>
                    <td className="px-3 py-2 text-muted-foreground">
                      Multi-tenant accounts, environment branching (dev/staging/prod),
                      webhooks, audit log, usage-based plans.
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </section>
          <section className="space-y-2">
            <h3 className="font-semibold">Known v1 limits</h3>
            <ul className="list-disc space-y-1 pl-5 text-sm text-muted-foreground">
              <li>Row listing filters a table in memory — fine for personal-scale data.</li>
              <li>Project deletion cascades in one mutation (archive instead for big datasets).</li>
              <li>Single-region deployment, one Convex deployment per environment.</li>
              <li>Realtime is REST polling for external clients — chat uses the messages tables, not the event log.</li>
              <li>Checkout records orders but does not move money; wire your payment provider and attach the receipt file to the order.</li>
            </ul>
          </section>
        </TabsContent>

        {/* --------------------------------------------------------- security */}
        <TabsContent value="security" className="mt-6 space-y-5">
          <div className="grid gap-3 sm:grid-cols-2">
            {[
              {
                title: "Passwords",
                body: "PBKDF2-SHA256, 60 000 iterations, 16-byte random salt, constant-time comparison. Hashes never leave the backend.",
              },
              {
                title: "API keys",
                body: "256-bit random keys stored as SHA-256 hashes; only the first 20 characters are displayed after creation.",
              },
              {
                title: "Tokens",
                body: "HS256 JWTs signed with a server-generated secret, bound to a revocable session and a per-user token version.",
              },
              {
                title: "Encryption",
                body: "TLS in transit; Convex encrypts data and file storage at rest (AES-256). OTP codes are additionally peppered with an HMAC secret.",
              },
              {
                title: "Access control",
                body: "API-key scopes per endpoint, table access levels (public / authenticated / owner) and role permissions checked server-side.",
              },
              {
                title: "Abuse protection",
                body: "A per-IP flood limiter runs before authentication, so an anonymous flood never reaches the database. Repeated failed authentications ban the source outright. Behind that: sliding-window rate limits per key (429 + Retry-After), per-end-user anti-spam limits, account lockout after failed logins, OTP attempt limits, and body/file size caps.",
              },
              {
                title: "Network firewall",
                body: "Per-key IP allowlists and denylists with full IPv4/IPv6 CIDR support, evaluated before any scope decision. Per-key CORS origin allowlists, including wildcard subdomains.",
              },
              {
                title: "Web application firewall",
                body: "Every request is inspected for path traversal (including percent-encoded), SQL and shell injection patterns, null bytes, oversized paths, query strings, headers and bodies, and disallowed HTTP verbs — all before authentication runs.",
              },
              {
                title: "Key lifecycle",
                body: "Keys carry an environment (live/test), an optional expiry, IP and origin restrictions, and per-key scopes. A sandbox key cannot slip into production by accident: the environment encoded in the key is checked against the key record.",
              },
              {
                title: "Audit trail",
                body: "Key lifecycle, authentication failures, IP blocks, WAF trips, scope denials and configuration changes are recorded in an append-only log. Client IPs are hashed, never stored raw. Every response carries an X-FD53-Request-Id linking the request log, the audit trail and server logs.",
              },
            ].map((item) => (
              <div key={item.title} className="rounded-lg border border-border bg-card p-4">
                <p className="font-semibold">{item.title}</p>
                <p className="mt-1 text-sm text-muted-foreground">{item.body}</p>
              </div>
            ))}
          </div>
          <CodeBlock
            language="hardening checklist"
            code={`1. Keep API keys in server actions / env vars — never in client code.
2. Use one key per environment so you can revoke independently.
3. Give every key the narrowest scopes that work, and set an expiry.
4. Restrict server-side keys by IP allowlist where you can.
5. Mark sensitive tables "authenticated" or "owner".
6. Give end users the narrowest role that works (viewer / user / editor / admin).
7. Watch the Usage page for error spikes and 429s.`}
          />
          <CodeBlock
            language="gateway pipeline"
            code={`Every /v1 request passes through these stages, in order.

 1  Correlation      assign or honour X-FD53-Request-Id
 2  Fingerprint      client IP (hashed) + user agent
 3  WAF              traversal · injection · size · bad verb
 4  Origin           CORS resolved against the key allowlist
 5  Edge throttle    per-IP flood limit — BEFORE any database read
 6  API key          format → hash → revoked → expired → environment
                    → project → suspended → IP policy → scope
 7  Quota            per-key rate limit + usage accounting
 8  Dispatch         route handler
 9  Response         envelope + security headers
10  Telemetry        request log + audit trail + Server-Timing

Stages 1-5 deliberately run before authentication: an anonymous flood must
never reach the database or consume a real project's quota.`}
          />
          <CodeBlock
            language="error codes"
            code={`Branch on the error code, not the message — messages change, codes do not.

401  missing_api_key             no X-API-Key header
401  invalid_api_key             malformed, or not a key we know
401  key_revoked                 revoked in the dashboard
401  key_expired                 past its expiry
401  key_environment_mismatch    test key used where live is implied
403  project_suspended           billing or admin action
403  ip_not_allowed              outside the key's IP allowlist
403  insufficient_scope          key lacks the endpoint's scope
403  blocked_by_waf              a WAF rule matched (see X-FD53-Rule)
429  rate_limited                honour the Retry-After header
413  storage_quota_exceeded      project storage is full

Responses are always { "ok": true, "data": ... } on success, or
{ "ok": false, "error": { "code", "message" } } on failure.`}
          />
        </TabsContent>
      </Tabs>
    </div>
  );
}