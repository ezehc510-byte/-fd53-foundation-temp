import { useState } from "react";
import { useMutation, useQuery } from "convex/react";
import { Search, Shield, Trash2, UserCheck, UserX } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api";
import type { Id } from "@/convex/_generated/dataModel";
import { useProject } from "@/components/dashboard/ProjectProvider";
import {
  EmptyState,
  LoadingBlock,
  PageHeader,
  Section,
  StatCard,
} from "@/components/dashboard/ui";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { formatDate, timeAgo } from "@/lib/fd53";

const PERMISSIONS = [
  "db:read",
  "db:write",
  "storage:read",
  "storage:write",
  "users:manage",
  "realtime:publish",
  "*",
];

export default function Users() {
  const { projectId } = useProject();
  const [search, setSearch] = useState("");
  const [sessionsFor, setSessionsFor] = useState<
    { id: string; name: string | null } | null
  >(null);
  const [roleDialog, setRoleDialog] = useState<
    { id: string; name: string; permissions: string[] } | null
  >(null);
  const [roleDraft, setRoleDraft] = useState<string[]>([]);
  const [pending, setPending] = useState(false);

  const users = useQuery(
    api.endUsers.list,
    projectId ? { projectId, search: search || undefined } : "skip",
  );
  const roles = useQuery(api.roles.list, projectId ? { projectId } : "skip");
  const sessionCounts = useQuery(
    api.endUsers.sessionCounts,
    projectId ? { projectId } : "skip",
  );
  const sessions = useQuery(
    api.sessions.listForUser,
    sessionsFor && projectId
      ? {
          projectId,
          endUserId: sessionsFor.id as Id<"endUsers">,
        }
      : "skip",
  );

  const setRole = useMutation(api.endUsers.setRole);
  const setStatus = useMutation(api.endUsers.setStatus);
  const removeUser = useMutation(api.endUsers.remove);
  const revokeSession = useMutation(api.sessions.revoke);
  const updateRole = useMutation(api.roles.update);

  if (!projectId) {
    return (
      <EmptyState
        icon={UserCheck}
        title="No active project"
        description="End users belong to a project — pick one to see them."
      />
    );
  }
  if (users === undefined || roles === undefined) {
    return <LoadingBlock label="Loading users" />;
  }

  const activeCount = users.users.filter((u) => u.status === "active").length;
  const bannedCount = users.users.length - activeCount;
  const lockedCount = users.users.filter((u) => (u.lockedUntil ?? 0) > Date.now()).length;

  return (
    <div className="space-y-6">
      <PageHeader
        title="Users"
        description="Every end user who signed up through your FD53 Auth endpoints, with roles and session state."
      />

      <div className="grid gap-3 sm:grid-cols-3">
        <StatCard label="Total users" value={String(users.total)} icon={UserCheck} />
        <StatCard label="Active" value={String(activeCount)} icon={UserCheck} />
        <StatCard
          label="Banned / locked"
          value={`${bannedCount} / ${lockedCount}`}
          tone={bannedCount + lockedCount > 0 ? "warning" : "default"}
          icon={UserX}
        />
      </div>

      <div className="relative">
        <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          value={search}
          onChange={(event) => setSearch(event.target.value)}
          placeholder="Search by email, phone, name or role…"
          className="pl-9"
        />
      </div>

      {users.users.length === 0 ? (
        <EmptyState
          icon={UserCheck}
          title={search ? "No matching users" : "No end users yet"}
          description={
            search
              ? "Try a different search term."
              : 'Users appear here as soon as your app calls POST /v1/auth/register or completes a phone OTP sign-in.'
          }
        />
      ) : (
        <div className="overflow-x-auto rounded-lg border border-border bg-card">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>User</TableHead>
                <TableHead>Role</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Sessions</TableHead>
                <TableHead>Joined</TableHead>
                <TableHead>Last login</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {users.users.map((user) => {
                const liveSessions = sessionCounts?.[user.id] ?? 0;
                return (
                  <TableRow key={user.id}>
                    <TableCell>
                      <p className="font-medium">{user.name ?? "—"}</p>
                      <p className="font-mono text-[11px] text-muted-foreground">
                        {user.email ?? user.phone ?? user.id}
                      </p>
                    </TableCell>
                    <TableCell>
                      <Select
                        value={user.role}
                        onValueChange={async (value) => {
                          const result = await setRole({
                            projectId,
                            userId: user.id as Id<"endUsers">,
                            role: value,
                          });
                          if (result.status === "ok") {
                            toast.success(`${user.email ?? user.phone} → ${value}`);
                          } else if ("message" in result) {
                            toast.error(result.message);
                          }
                        }}
                      >
                        <SelectTrigger className="h-8 w-28">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {roles.map((role) => (
                            <SelectItem key={role._id} value={role.name}>
                              {role.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-wrap gap-1">
                        <Badge variant={user.status === "active" ? "secondary" : "destructive"}>
                          {user.status}
                        </Badge>
                        {(user.lockedUntil ?? 0) > Date.now() ? (
                          <Badge variant="outline" className="border-chart-2 text-chart-2">
                            locked
                          </Badge>
                        ) : null}
                        {!user.hasPassword && user.phone ? (
                          <Badge variant="outline">otp</Badge>
                        ) : null}
                      </div>
                    </TableCell>
                    <TableCell>
                      <button
                        type="button"
                        className="cursor-pointer font-mono text-xs text-primary underline-offset-2 hover:underline"
                        onClick={() =>
                          setSessionsFor({
                            id: user.id,
                            name: user.email ?? user.phone ?? user.id,
                          })
                        }
                      >
                        {liveSessions} active
                      </button>
                    </TableCell>
                    <TableCell className="text-xs text-muted-foreground">
                      {formatDate(user.createdAt)}
                    </TableCell>
                    <TableCell className="text-xs text-muted-foreground">
                      {user.lastLoginAt ? timeAgo(user.lastLoginAt) : "never"}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-1">
                        <Button
                          variant="ghost"
                          size="sm"
                          className="cursor-pointer"
                          onClick={async () => {
                            const next = user.status === "active" ? "banned" : "active";
                            await setStatus({
                              projectId,
                              userId: user.id as Id<"endUsers">,
                              status: next,
                            });
                            toast.success(`User ${next === "banned" ? "banned" : "reactivated"}`);
                          }}
                        >
                          {user.status === "active" ? (
                            <UserX className="size-4" />
                          ) : (
                            <UserCheck className="size-4" />
                          )}
                          {user.status === "active" ? "Ban" : "Unban"}
                        </Button>
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="size-8 cursor-pointer text-muted-foreground hover:text-destructive"
                            >
                              <Trash2 className="size-4" />
                            </Button>
                          </DialogTrigger>
                          <DialogContent>
                            <DialogHeader>
                              <DialogTitle>Delete this user?</DialogTitle>
                              <DialogDescription>
                                Sessions are revoked and the account is removed from
                                this project.
                              </DialogDescription>
                            </DialogHeader>
                            <DialogFooter>
                              <Button variant="outline" className="cursor-pointer">
                                Cancel
                              </Button>
                              <Button
                                variant="destructive"
                                className="cursor-pointer"
                                onClick={async () => {
                                  await removeUser({
                                    projectId,
                                    userId: user.id as Id<"endUsers">,
                                  });
                                  toast.success("User deleted");
                                }}
                              >
                                Delete user
                              </Button>
                            </DialogFooter>
                          </DialogContent>
                        </Dialog>
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      )}

      {/* Sessions drawer */}
      <Dialog open={sessionsFor !== null} onOpenChange={(open) => !open && setSessionsFor(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Sessions</DialogTitle>
            <DialogDescription>
              {sessionsFor?.name} — revoking a session invalidates its token
              immediately.
            </DialogDescription>
          </DialogHeader>
          <div className="max-h-80 space-y-2 overflow-y-auto">
            {sessions && sessions.length > 0 ? (
              sessions.map((session) => (
                <div
                  key={session.id}
                  className="flex items-center justify-between gap-3 rounded-md border border-border p-3"
                >
                  <div className="min-w-0">
                    <p className="font-mono text-xs">
                      {session.active ? "active" : session.revokedAt ? "revoked" : "expired"}
                    </p>
                    <p className="truncate text-[11px] text-muted-foreground">
                      {session.userAgent ?? "unknown device"} · expires{" "}
                      {formatDate(session.expiresAt)}
                    </p>
                  </div>
                  {session.active ? (
                    <Button
                      variant="outline"
                      size="sm"
                      className="cursor-pointer"
                      onClick={async () => {
                        await revokeSession({
                          projectId,
                          sessionId: session.id as Id<"sessions">,
                        });
                        toast.success("Session revoked");
                      }}
                    >
                      Revoke
                    </Button>
                  ) : null}
                </div>
              ))
            ) : (
              <p className="py-6 text-center text-sm text-muted-foreground">
                No sessions recorded.
              </p>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Roles + permissions */}
      <Section
        title="Roles & permissions"
        description="Permissions are checked on every end-user call."
      >
        <div className="grid gap-2 md:grid-cols-2">
          {roles.map((role) => (
            <div
              key={role._id}
              className="flex flex-col gap-2 rounded-lg border border-border bg-card p-4"
            >
              <div className="flex items-start justify-between gap-2">
                <div>
                  <p className="flex items-center gap-2 font-semibold">
                    <Shield className="size-3.5 text-primary" />
                    {role.name}
                    {role.isDefault ? (
                      <Badge variant="secondary" className="text-[10px]">
                        default
                      </Badge>
                    ) : null}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {role.description ?? "Custom role"}
                  </p>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  className="cursor-pointer"
                  onClick={() => {
                    setRoleDraft(role.permissions);
                    setRoleDialog({
                      id: role._id,
                      name: role.name,
                      permissions: role.permissions,
                    });
                  }}
                >
                  Edit
                </Button>
              </div>
              <div className="flex flex-wrap gap-1">
                {role.permissions.map((permission) => (
                  <Badge
                    key={permission}
                    variant="outline"
                    className="font-mono text-[10px]"
                  >
                    {permission}
                  </Badge>
                ))}
              </div>
            </div>
          ))}
        </div>

        <Dialog
          open={roleDialog !== null}
          onOpenChange={(open) => !open && setRoleDialog(null)}
        >
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Permissions for "{roleDialog?.name}"</DialogTitle>
              <DialogDescription>
                `*` grants everything. Keep app-facing roles narrow — end users get
                the least privilege they need.
              </DialogDescription>
            </DialogHeader>
            <div className="grid grid-cols-2 gap-2">
              {PERMISSIONS.map((permission) => (
                <label
                  key={permission}
                  className="flex cursor-pointer items-center gap-2 rounded-md border border-border px-3 py-2 font-mono text-xs"
                >
                  <Checkbox
                    checked={roleDraft.includes(permission)}
                    onCheckedChange={(checked) =>
                      setRoleDraft((current) =>
                        checked
                          ? [...current, permission]
                          : current.filter((p) => p !== permission),
                      )
                    }
                  />
                  {permission}
                </label>
              ))}
            </div>
            <DialogFooter>
              <Button
                variant="outline"
                className="cursor-pointer"
                onClick={() => setRoleDialog(null)}
              >
                Cancel
              </Button>
              <Button
                className="cursor-pointer"
                disabled={pending || roleDraft.length === 0}
                onClick={async () => {
                  if (!roleDialog) return;
                  setPending(true);
                  try {
                    const result = await updateRole({
                      projectId,
                      roleId: roleDialog.id as Id<"roles">,
                      permissions: roleDraft,
                    });
                    if (result.status === "ok") {
                      toast.success(`Updated ${roleDialog.name}`);
                      setRoleDialog(null);
                    } else if ("message" in result) {
                      toast.error(result.message);
                    }
                  } finally {
                    setPending(false);
                  }
                }}
              >
                Save permissions
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </Section>

      <p className="text-xs text-muted-foreground">
        Access is enforced server-side on every database, storage and realtime call —
        the roles above are not cosmetic.
      </p>
    </div>
  );
}