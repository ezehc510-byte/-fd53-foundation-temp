import { useQuery } from "convex/react";
import { Activity, AlertTriangle, Gauge, KeyRound, ScrollText, ShieldAlert } from "lucide-react";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { api } from "@/convex/_generated/api";
import { useProject } from "@/components/dashboard/ProjectProvider";
import {
  EmptyState,
  LoadingBlock,
  PageHeader,
  Section,
  StatCard,
} from "@/components/dashboard/ui";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { formatBytes, formatNumber, timeAgo } from "@/lib/fd53";

const CATEGORIES = [
  "auth",
  "database",
  "storage",
  "realtime",
  "social",
  "marketplace",
  "system",
] as const;
const CATEGORY_COLORS: Record<string, string> = {
  auth: "var(--chart-1)",
  database: "var(--chart-3)",
  storage: "var(--chart-2)",
  realtime: "var(--chart-5)",
  social: "var(--chart-1)",
  marketplace: "var(--chart-3)",
  system: "var(--chart-4)",
};

export default function Usage() {
  const { project, projectId } = useProject();
  const usage = useQuery(
    api.usage.summary,
    projectId ? { projectId, days: 14 } : "skip",
  );
  const keys = useQuery(api.apiKeys.list, projectId ? { projectId } : "skip");
  const requestLog = useQuery(
    api.requestLog.recent,
    projectId ? { projectId, limit: 40 } : "skip",
  );
  const throttled = useQuery(
    api.rateLimits.active,
    projectId ? { projectId } : "skip",
  );

  if (!project) {
    return (
      <EmptyState
        icon={Activity}
        title="No active project"
        description="Usage is tracked per project — pick one to see its numbers."
      />
    );
  }

  if (usage === undefined) return <LoadingBlock label="Loading usage" />;

  const today = usage.daily[usage.daily.length - 1];
  const activeKeys = keys?.filter((k) => !k.revokedAt) ?? [];
  const errorRate =
    usage.totals.requests > 0
      ? (usage.totals.errors / usage.totals.requests) * 100
      : 0;

  const dailyData = usage.daily.map((day) => ({
    day: day.day.slice(5),
    ...Object.fromEntries(CATEGORIES.map((category) => [category, day.byCategory[category] ?? 0])),
  }));

  const categoryData = CATEGORIES.map((category) => ({
    category,
    requests: usage.categoryTotals[category] ?? 0,
  })).filter((entry) => entry.requests > 0);

  return (
    <div className="space-y-6">
      <PageHeader
        title="Usage"
        description="Request volume, error rate and limits for this project."
      />

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard
          label="Requests today"
          value={formatNumber(today?.requests ?? 0)}
          hint={`${formatNumber(usage.totals.requests)} in 14 days`}
          icon={Activity}
        />
        <StatCard
          label="Errors (14d)"
          value={formatNumber(usage.totals.errors)}
          hint={`${errorRate.toFixed(1)}% of requests`}
          icon={AlertTriangle}
          tone={usage.totals.errors > 0 ? "warning" : "default"}
        />
        <StatCard
          label="Rate limit"
          value={`${project.requestsPerMinute}/min`}
          hint="per key, sliding window"
          icon={Gauge}
        />
        <StatCard
          label="Storage"
          value={formatBytes(project.storageBytes)}
          hint={`of ${formatBytes(project.storageLimitBytes)}`}
          icon={Activity}
        />
      </div>

      <Section title="Requests by category" description="Last 14 days.">
        <div className="rounded-lg border border-border bg-card p-4">
          <ResponsiveContainer width="100%" height={260}>
            <AreaChart data={dailyData} margin={{ top: 4, right: 8, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
              <XAxis
                dataKey="day"
                stroke="var(--muted-foreground)"
                fontSize={11}
                tickLine={false}
                axisLine={false}
              />
              <YAxis
                stroke="var(--muted-foreground)"
                fontSize={11}
                tickLine={false}
                axisLine={false}
                allowDecimals={false}
              />
              <Tooltip
                contentStyle={{
                  background: "var(--popover)",
                  border: "1px solid var(--border)",
                  borderRadius: 8,
                  fontSize: 12,
                }}
              />
              <Legend wrapperStyle={{ fontSize: 12 }} />
              {CATEGORIES.map((category) => (
                <Area
                  key={category}
                  type="monotone"
                  dataKey={category}
                  stackId="1"
                  stroke={CATEGORY_COLORS[category]}
                  fill={CATEGORY_COLORS[category]}
                  fillOpacity={0.35}
                  strokeWidth={1.5}
                />
              ))}
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </Section>

      <div className="grid gap-6 lg:grid-cols-2">
        <Section title="Totals by category" description="Where your traffic goes.">
          {categoryData.length === 0 ? (
            <EmptyState
              icon={Activity}
              title="No traffic yet"
              description="Call the API with one of your keys and the numbers appear here."
            />
          ) : (
            <div className="rounded-lg border border-border bg-card p-4">
              <ResponsiveContainer width="100%" height={220}>
                <BarChart data={categoryData} margin={{ top: 4, right: 8, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
                  <XAxis
                    dataKey="category"
                    stroke="var(--muted-foreground)"
                    fontSize={11}
                    tickLine={false}
                    axisLine={false}
                  />
                  <YAxis
                    stroke="var(--muted-foreground)"
                    fontSize={11}
                    tickLine={false}
                    axisLine={false}
                    allowDecimals={false}
                  />
                  <Tooltip
                    contentStyle={{
                      background: "var(--popover)",
                      border: "1px solid var(--border)",
                      borderRadius: 8,
                      fontSize: 12,
                    }}
                  />
                  <Bar dataKey="requests" radius={[4, 4, 0, 0]}>
                    {categoryData.map((entry) => (
                      <Cell key={entry.category} fill={CATEGORY_COLORS[entry.category]} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </Section>

        <Section title="Keys" description="Rate limits and last activity.">
          {keys && keys.length > 0 ? (
            <div className="overflow-x-auto rounded-lg border border-border bg-card">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Limit</TableHead>
                    <TableHead>Last used</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {keys.map((key) => (
                    <TableRow key={key._id}>
                      <TableCell className="font-medium">
                        <span className="flex items-center gap-2">
                          <KeyRound className="size-3.5 text-muted-foreground" />
                          {key.name}
                        </span>
                      </TableCell>
                      <TableCell className="font-mono text-xs">
                        {key.rateLimit}/min
                      </TableCell>
                      <TableCell className="text-xs text-muted-foreground">
                        {key.lastUsedAt ? timeAgo(key.lastUsedAt) : "never"}
                      </TableCell>
                      <TableCell className="text-xs">
                        {key.revokedAt ? "revoked" : "active"}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <EmptyState
              icon={KeyRound}
              title="No API keys"
              description="Create a key to start measuring usage."
            />
          )}
        </Section>
      </div>

      <Section
        title="Recent requests"
        description="The last API calls your apps made, newest first. Kept per project (500 rows)."
      >
        {requestLog && requestLog.requests.length > 0 ? (
          <div className="overflow-x-auto rounded-lg border border-border bg-card">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Route</TableHead>
                  <TableHead>Method</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead className="text-right">Time</TableHead>
                  <TableHead className="text-right">When</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {requestLog.requests.map((request) => (
                  <TableRow key={request.id}>
                    <TableCell className="font-mono text-xs">{request.path}</TableCell>
                    <TableCell className="font-mono text-xs text-muted-foreground">
                      {request.method}
                    </TableCell>
                    <TableCell
                      className={
                        request.status >= 400
                          ? "font-mono text-xs text-destructive"
                          : "font-mono text-xs"
                      }
                    >
                      {request.status}
                    </TableCell>
                    <TableCell className="text-xs text-muted-foreground">
                      {request.category}
                    </TableCell>
                    <TableCell className="text-right font-mono text-xs">
                      {request.durationMs}ms
                    </TableCell>
                    <TableCell className="text-right text-xs text-muted-foreground">
                      {timeAgo(request.at)}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        ) : (
          <EmptyState
            icon={ScrollText}
            title="No requests logged"
            description="Every authenticated /v1 call is recorded here — hit an endpoint with one of your keys and it shows up instantly."
          />
        )}
      </Section>

      <div className="grid gap-6 lg:grid-cols-2">
        <Section
          title="Top routes"
          description="Grouped over the same request window."
        >
          {requestLog && requestLog.routes.length > 0 ? (
            <div className="overflow-x-auto rounded-lg border border-border bg-card">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Route</TableHead>
                    <TableHead className="text-right">Calls</TableHead>
                    <TableHead className="text-right">Errors</TableHead>
                    <TableHead className="text-right">Avg</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {requestLog.routes.slice(0, 12).map((route) => (
                    <TableRow key={route.route}>
                      <TableCell className="font-mono text-xs">{route.route}</TableCell>
                      <TableCell className="text-right font-mono text-xs">
                        {route.count}
                      </TableCell>
                      <TableCell
                        className={
                          route.errors > 0
                            ? "text-right font-mono text-xs text-destructive"
                            : "text-right font-mono text-xs"
                        }
                      >
                        {route.errors}
                      </TableCell>
                      <TableCell className="text-right font-mono text-xs">
                        {route.avgMs}ms
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <EmptyState
              icon={Activity}
              title="Nothing to rank yet"
              description="Route breakdowns appear once your app starts calling the API."
            />
          )}
        </Section>

        <Section
          title="Anti-spam (in progress)"
          description="End users currently throttled by the per-user limits."
        >
          {throttled && throttled.length > 0 ? (
            <div className="overflow-x-auto rounded-lg border border-border bg-card">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Limit</TableHead>
                    <TableHead className="text-right">Hits</TableHead>
                    <TableHead className="text-right">Blocked until</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {throttled.map((row) => (
                    <TableRow key={row.key}>
                      <TableCell className="font-mono text-xs">{row.key}</TableCell>
                      <TableCell className="text-right font-mono text-xs">
                        {row.count}
                      </TableCell>
                      <TableCell className="text-right text-xs text-muted-foreground">
                        {row.blockedUntil ? timeAgo(row.blockedUntil) : "—"}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <EmptyState
              icon={ShieldAlert}
              title="Nobody is throttled"
              description="Per-user limits cover posting, following, messaging, checkout and reports. Blocked callers show up here."
            />
          )}
        </Section>
      </div>
    </div>
  );
}