import { useState } from "react";
import { useAction, useMutation, useQuery } from "convex/react";
import { KeyRound, Plus, ShieldAlert, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api";
import { useProject } from "@/components/dashboard/ProjectProvider";
import {
  CodeBlock,
  EmptyState,
  LoadingBlock,
  PageHeader,
  Section,
} from "@/components/dashboard/ui";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { apiBase, copyText, timeAgo } from "@/lib/fd53";

const SCOPES = ["auth", "db", "storage", "realtime", "usage"] as const;

export default function ApiKeys() {
  const { project, projectId } = useProject();
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [rateLimit, setRateLimit] = useState("120");
  const [scopes, setScopes] = useState<string[]>([...SCOPES]);
  const [createdKey, setCreatedKey] = useState<string | null>(null);
  const [pending, setPending] = useState(false);

  const keys = useQuery(api.apiKeys.list, projectId ? { projectId } : "skip");
  const createKey = useAction(api.apiKeys.create);
  const revokeKey = useMutation(api.apiKeys.revoke);

  if (!project) {
    return <EmptyState
      icon={KeyRound}
      title="No active project"
      description="Pick or create a project first — API keys belong to a project."
    />;
  }
  if (keys === undefined) return <LoadingBlock label="Loading API keys" />;

  const handleCreate = async () => {
    setPending(true);
    try {
      const result = await createKey({
        projectId: project._id,
        name,
        rateLimit: Number(rateLimit) || undefined,
        scopes: scopes.length === SCOPES.length ? ["*"] : scopes,
      });
      if (result.status === "created") {
        setCreatedKey(result.key);
        setOpen(false);
        setName("");
      } else {
        toast.error(result.message);
      }
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Could not create key");
    } finally {
      setPending(false);
    }
  };

  const curlSnippet = `curl ${apiBase()}/db/tables \\
  -H "X-API-Key: fd53_live_…"`;

  return (
    <div className="space-y-6">
      <PageHeader
        title="API Keys"
        description="Keys authenticate your app's calls to FD53. They are stored hashed — the full key is shown once."
        action={
          <Dialog open={open} onOpenChange={setOpen}>
            <Button className="cursor-pointer" onClick={() => setOpen(true)}>
              <Plus className="size-4" />
              New key
            </Button>
            <DialogContent className="max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Create an API key</DialogTitle>
                <DialogDescription>
                  Give each environment its own key so you can revoke them
                  independently.
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="key-name">Name</Label>
                  <Input
                    id="key-name"
                    value={name}
                    onChange={(event) => setName(event.target.value)}
                    placeholder="flutterflow-production"
                    autoFocus
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="key-rate">Rate limit (requests / minute)</Label>
                  <Input
                    id="key-rate"
                    type="number"
                    min={1}
                    max={project.requestsPerMinute}
                    value={rateLimit}
                    onChange={(event) => setRateLimit(event.target.value)}
                  />
                  <p className="text-xs text-muted-foreground">
                    Project ceiling is {project.requestsPerMinute}/min. Excess calls
                    get HTTP 429 with Retry-After.
                  </p>
                </div>
                <div className="space-y-2">
                  <Label>Scopes</Label>
                  <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
                    {SCOPES.map((scope) => (
                      <label
                        key={scope}
                        className="flex cursor-pointer items-center gap-2 rounded-md border border-border px-3 py-2 font-mono text-xs"
                      >
                        <Checkbox
                          checked={scopes.includes(scope)}
                          onCheckedChange={(checked) =>
                            setScopes((current) =>
                              checked
                                ? [...current, scope]
                                : current.filter((s) => s !== scope),
                            )
                          }
                        />
                        {scope}
                      </label>
                    ))}
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button
                  variant="outline"
                  className="cursor-pointer"
                  onClick={() => setOpen(false)}
                >
                  Cancel
                </Button>
                <Button
                  className="cursor-pointer"
                  disabled={pending || name.trim().length < 1}
                  onClick={handleCreate}
                >
                  {pending ? "Creating…" : "Create key"}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        }
      />

      {/* One-time plaintext key reveal */}
      <Dialog
        open={createdKey !== null}
        onOpenChange={(next) => !next && setCreatedKey(null)}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Copy your key now</DialogTitle>
            <DialogDescription>
              FD53 stores a SHA-256 hash of this key, so it cannot be shown again.
              If you lose it, create a new one.
            </DialogDescription>
          </DialogHeader>
          <div className="flex items-center gap-2 rounded-md border border-border bg-background p-3">
            <code className="flex-1 break-all font-mono text-xs">{createdKey}</code>
            <Button
              size="sm"
              variant="outline"
              className="cursor-pointer"
              onClick={async () => {
                if (createdKey && (await copyText(createdKey))) {
                  toast.success("Key copied to clipboard");
                }
              }}
            >
              Copy
            </Button>
          </div>
          <DialogFooter>
            <Button className="cursor-pointer" onClick={() => setCreatedKey(null)}>
              Done
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {keys.length === 0 ? (
        <EmptyState
          icon={KeyRound}
          title="No API keys yet"
          description="Create a key to call the FD53 API from FlutterFlow, a script or another app."
        />
      ) : (
        <Section title="Keys">
          <div className="overflow-x-auto rounded-lg border border-border bg-card">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Prefix</TableHead>
                  <TableHead>Scopes</TableHead>
                  <TableHead>Limit</TableHead>
                  <TableHead>Last used</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {keys.map((key) => (
                  <TableRow key={key._id}>
                    <TableCell className="font-medium">{key.name}</TableCell>
                    <TableCell className="font-mono text-xs text-muted-foreground">
                      {key.keyPrefix}…
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-wrap gap-1">
                        {key.scopes.map((scope) => (
                          <Badge
                            key={scope}
                            variant="secondary"
                            className="font-mono text-[10px]"
                          >
                            {scope}
                          </Badge>
                        ))}
                      </div>
                    </TableCell>
                    <TableCell className="font-mono text-xs">
                      {key.rateLimit}/min
                    </TableCell>
                    <TableCell className="text-xs text-muted-foreground">
                      {key.lastUsedAt ? timeAgo(key.lastUsedAt) : "never"}
                    </TableCell>
                    <TableCell className="text-right">
                      {key.revokedAt ? (
                        <Badge variant="outline" className="text-muted-foreground">
                          revoked
                        </Badge>
                      ) : (
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button
                              size="sm"
                              variant="ghost"
                              className="cursor-pointer text-destructive hover:text-destructive"
                            >
                              <Trash2 className="size-4" />
                              Revoke
                            </Button>
                          </DialogTrigger>
                          <DialogContent>
                            <DialogHeader>
                              <DialogTitle>Revoke "{key.name}"?</DialogTitle>
                              <DialogDescription>
                                Calls using this key immediately start failing with
                                HTTP 401. This can't be undone.
                              </DialogDescription>
                            </DialogHeader>
                            <DialogFooter>
                              <Button variant="outline" className="cursor-pointer">
                                Cancel
                              </Button>
                              <Button
                                variant="destructive"
                                className="cursor-pointer"
                                onClick={async () => {
                                  await revokeKey({
                                    projectId: project._id,
                                    keyId: key._id,
                                  });
                                  toast.success(`${key.name} revoked`);
                                }}
                              >
                                Revoke key
                              </Button>
                            </DialogFooter>
                          </DialogContent>
                        </Dialog>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </Section>
      )}

      <Section
        title="Using a key"
        description="Send it in the X-API-Key header (or as a bearer token)."
      >
        <CodeBlock code={curlSnippet} />
        <p className="flex items-start gap-2 text-xs text-muted-foreground">
          <ShieldAlert className="mt-0.5 size-3.5 shrink-0" />
          Keep keys server-side in FlutterFlow server actions and backend functions —
          never in client-side code or a repository.
        </p>
      </Section>
    </div>
  );
}