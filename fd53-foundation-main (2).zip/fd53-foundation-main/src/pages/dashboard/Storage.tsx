import { useRef, useState } from "react";
import { useMutation, useQuery } from "convex/react";
import {
  FileAudio,
  FileText,
  FileVideo,
  HardDrive,
  Image as ImageIcon,
  Package,
  Trash2,
  Upload,
} from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api";
import type { Id } from "@/convex/_generated/dataModel";
import { useProject } from "@/components/dashboard/ProjectProvider";
import {
  CodeBlock,
  EmptyState,
  LoadingBlock,
  PageHeader,
  StatCard,
} from "@/components/dashboard/ui";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { apiBase, formatBytes, timeAgo } from "@/lib/fd53";

const CATEGORY_ICONS = {
  image: ImageIcon,
  video: FileVideo,
  audio: FileAudio,
  document: FileText,
  other: Package,
} as const;

export default function Storage() {
  const { projectId } = useProject();
  const inputRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const [visibility, setVisibility] = useState<"public" | "private">("public");

  const files = useQuery(api.files.list, projectId ? { projectId } : "skip");
  const generateUploadUrl = useMutation(api.files.generateUploadUrl);
  const createRecord = useMutation(api.files.createRecord);
  const setVisibilityMutation = useMutation(api.files.setVisibility);
  const removeFile = useMutation(api.files.remove);if (!projectId) {
    return (
      <EmptyState
        icon={HardDrive}
        title="No active project"
        description="Pick a project to manage its files."
      />
    );
  }

  if (files === undefined) return <LoadingBlock label="Loading storage" />;

  const usedPercent = Math.min(
    100,
    Math.round((files.storageBytes / Math.max(1, files.storageLimitBytes)) * 100),
  );

  const handleUpload = async (fileList: FileList | null) => {
    if (!fileList || fileList.length === 0) return;
    setUploading(true);
    try {
      for (const file of Array.from(fileList)) {
        const uploadUrl = await generateUploadUrl({ projectId });
        const response = await fetch(uploadUrl, {
          method: "POST",
          headers: { "Content-Type": file.type || "application/octet-stream" },
          body: file,
        });
        if (!response.ok) throw new Error(`Upload failed for ${file.name}`);
        const { storageId } = (await response.json()) as { storageId: string };

        const result = await createRecord({
          projectId,
          name: file.name,
          path: file.name,
          mimeType: file.type || "application/octet-stream",
          size: file.size,
          storageId: storageId as Id<"_storage">,
          visibility,
        });
        if (result.status !== "created") {
          toast.error(result.message);
        } else {
          toast.success(`Uploaded ${file.name}`);
        }
      }
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Upload failed");
    } finally {
      setUploading(false);
      if (inputRef.current) inputRef.current.value = "";
    }
  };

  const uploadSnippet = `# FlutterFlow server action / curl
curl -X POST "${apiBase()}/storage/upload?visibility=public" \\
  -H "X-API-Key: fd53_live_…" \\
  -F "file=@avatar.png" \\
  -F "visibility=public"

# Response: { ok: true, data: { file: { id, path, size, … }, url } }`;

  return (
    <div className="space-y-6">
      <PageHeader
        title="Storage"
        description="Profile pictures, images, video, audio and documents — uploaded from the console or any app."
        action={
          <div className="flex flex-wrap items-center gap-2">
            <Select
              value={visibility}
              onValueChange={(value) => setVisibility(value as "public" | "private")}
            >
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="public">public</SelectItem>
                <SelectItem value="private">private</SelectItem>
              </SelectContent>
            </Select>
            <Button
              className="cursor-pointer"
              disabled={uploading}
              onClick={() => inputRef.current?.click()}
            >
              <Upload className="size-4" />
              {uploading ? "Uploading…" : "Upload files"}
            </Button>
            <input
              ref={inputRef}
              type="file"
              multiple
              className="hidden"
              onChange={(event) => handleUpload(event.target.files)}
            />
          </div>
        }
      />

      <div className="grid gap-3 sm:grid-cols-3">
        <StatCard label="Files" value={String(files.total)} icon={Package} />
        <StatCard
          label="Used"
          value={formatBytes(files.storageBytes)}
          hint={`${usedPercent}% of quota`}
          icon={HardDrive}
          tone={usedPercent > 80 ? "warning" : "default"}
        />
        <div className="rounded-lg border border-border bg-card p-4">
          <p className="text-xs tracking-wide text-muted-foreground uppercase">
            Plan quota
          </p>
          <Progress value={usedPercent} className="mt-3" />
          <p className="mt-2 text-xs text-muted-foreground">
            {formatBytes(files.storageBytes)} / {formatBytes(files.storageLimitBytes)} · 25 MB max per file
          </p>
        </div>
      </div>

      {files.files.length === 0 ? (
        <EmptyState
          icon={HardDrive}
          title="No files yet"
          description="Upload from here, or point your app at POST /v1/storage/upload — both end up in the same place."
          action={
            <Button className="cursor-pointer" onClick={() => inputRef.current?.click()}>
              Upload a file
            </Button>
          }
        />
      ) : (
        <ul className="grid gap-2 md:grid-cols-2">
          {files.files.map((file) => {
            const Icon = CATEGORY_ICONS[file.category as keyof typeof CATEGORY_ICONS] ?? Package;
            return (
              <li
                key={file._id}
                className="flex items-center gap-3 rounded-lg border border-border bg-card p-3"
              >
                <div className="flex size-10 shrink-0 items-center justify-center rounded-md bg-primary/10 text-primary">
                  <Icon className="size-5" />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium">{file.name}</p>
                  <p className="truncate font-mono text-[11px] text-muted-foreground">
                    {file.mimeType} · {formatBytes(file.size)} ·{" "}
                    {timeAgo(file._creationTime)}
                  </p>
                </div>
                <Badge
                  variant={file.visibility === "public" ? "secondary" : "outline"}
                  className="shrink-0 cursor-pointer"
                  title="Toggle public / private"
                  onClick={async () => {
                    await setVisibilityMutation({
                      projectId,
                      fileId: file._id,
                      visibility: file.visibility === "public" ? "private" : "public",
                    });
                    toast.success(
                      `${file.name} is now ${file.visibility === "public" ? "private" : "public"}`,
                    );
                  }}
                >
                  {file.visibility}
                </Badge>
                {file.url ? (
                  <a
                    href={file.url}
                    target="_blank"
                    rel="noreferrer"
                    className="shrink-0 text-xs text-primary underline-offset-2 hover:underline"
                  >
                    Open
                  </a>
                ) : null}
                <Dialog>
                  <DialogTrigger asChild>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="size-8 shrink-0 cursor-pointer text-muted-foreground hover:text-destructive"
                    >
                      <Trash2 className="size-4" />
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Delete {file.name}?</DialogTitle>
                      <DialogDescription>
                        The stored object is removed and its quota is freed. Any app
                        still referencing this URL breaks.
                      </DialogDescription>
                    </DialogHeader>
                    <DialogFooter>
                      <Button variant="outline" className="cursor-pointer">
                        Cancel
                      </Button>
                      <Button
                        variant="destructive"
                        className="cursor-pointer"
                        onClick={async () => {
                          await removeFile({ projectId, fileId: file._id });
                          toast.success(`${file.name} deleted`);
                        }}
                      >
                        Delete file
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </li>
            );
          })}
        </ul>
      )}

      <div className="space-y-2">
        <h2 className="tracking-tight font-bold">Upload API</h2>
        <CodeBlock code={uploadSnippet} />
      </div>
    </div>
  );
}