import { useState } from "react";
import { useMutation, useQuery } from "convex/react";
import { useNavigate } from "react-router";
import {
  Activity,
  Boxes,
  Database,
  HardDrive,
  KeyRound,
  Radio,
  Users,
} from "lucide-react";
import { toast } from "sonner";
import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { api } from "@/convex/_generated/api";
import { useProject } from "@/components/dashboard/ProjectProvider";
import {
  CodeBlock,
  EmptyState,
  LoadingBlock,
  PageHeader,
  Section,
  StatCard,
} from "@/components/dashboard/ui";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/use-auth";
import { apiBase, formatBytes, formatNumber, timeAgo } from "@/lib/fd53";

export default function Overview() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { projects, project, projectId } = useProject();
  const [publishing, setPublishing] = useState(false);

  const stats = useQuery(
    api.projects.stats,
    projectId ? { projectId } : "skip",
  );
  const usage = useQuery(
    api.usage.summary,
    projectId ? { projectId, days: 14 } : "skip",
  );
  const events = useQuery(
    api.realtime.listEvents,
    projectId ? { projectId, limit: 6 } : "skip",
  );
  const publishTest = useMutation(api.realtime.publishFromDashboard);

  if (projects && projects.length === 0) {
    return (
      <div className="space-y-6">
        <PageHeader title="Welcome to FD53" description="Create your first project to get an API." />
        <EmptyState
          icon={Boxes}
          title="No projects yet"
          description="A project is one backend: its API keys, tables, files, users and usage. Create one to get started."
          action={
            <Button className="cursor-pointer" onClick={() => navigate("/dashboard/projects")}>
              Create a project
            </Button>
          }
        />
      </div>
    );
  }

  if (!project || stats === undefined || usage === undefined) {
    return <LoadingBlock label="Loading project overview" />;
  }

  const today = usage.daily[usage.daily.length - 1];
  const chartData = usage.daily.map((day) => ({
    day: day.day.slice(5),
    requests: day.requests,
    errors: day.errors,
  }));

  const quickstart = `# 1. Health check
curl ${apiBase()}/health

# 2. Create a table (X-API-Key from API Keys page)
curl -X POST ${apiBase()}/db/tables \\
  -H "X-API-Key: fd53_live_…" \\
  -H "Content-Type: application/json" \\
  -d '{"name":"todos","fields":[{"name":"title","type":"string","required":true}]}'

# 3. Insert and read rows
curl -X POST ${apiBase()}/db/todos \\
  -H "X-API-Key: fd53_live_…" -H "Content-Type: application/json" \\
  -d '{"data":{"title":"Ship FD53"}}'
curl "${apiBase()}/db/todos?limit=10" -H "X-API-Key: fd53_live_…"`;

  return (
    <div className="space-y-8">
      <PageHeader
        title={`Hello${user?.name ? `, ${user.name}` : ""}`}
        description={`${project.name} · live usage and activity`}
        action={
          <Button
            variant="outline"
            className="cursor-pointer"
            onClick={() => navigate("/dashboard/docs")}
          >
            Read the API docs
          </Button>
        }
      />

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatCard
          label="Requests today"
          value={formatNumber(today?.requests ?? 0)}
          hint={`${formatNumber(usage.totals.requests)} in 14 days`}
          icon={Activity}
        />
        <StatCard
          label="End users"
          value={formatNumber(stats.endUsers)}
          hint="signed up through your API"
          icon={Users}
        />
        <StatCard
          label="Documents"
          value={formatNumber(stats.rows)}
          hint={`${stats.tables} table${stats.tables === 1 ? "" : "s"}`}
          icon={Database}
        />
        <StatCard
          label="Storage"
          value={formatBytes(stats.storageBytes)}
          hint={`of ${formatBytes(stats.storageLimitBytes)}`}
          icon={HardDrive}
          tone={stats.storageBytes > stats.storageLimitBytes * 0.8 ? "warning" : "default"}
        />
      </div>

      <Section
        title="API traffic"
        description="Requests and errors per day over the last 14 days."
      >
        <div className="rounded-lg border border-border bg-card p-4">
          <ResponsiveContainer width="100%" height={240}>
            <AreaChart data={chartData} margin={{ top: 4, right: 8, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="fd53Requests" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="var(--chart-1)" stopOpacity={0.5} />
                  <stop offset="100%" stopColor="var(--chart-1)" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
              <XAxis
                dataKey="day"
                stroke="var(--muted-foreground)"
                fontSize={11}
                tickLine={false}
                axisLine={false}
              />
              <YAxis
                stroke="var(--muted-foreground)"
                fontSize={11}
                tickLine={false}
                axisLine={false}
                allowDecimals={false}
              />
              <Tooltip
                contentStyle={{
                  background: "var(--popover)",
                  border: "1px solid var(--border)",
                  borderRadius: 8,
                  fontSize: 12,
                }}
              />
              <Area
                type="monotone"
                dataKey="requests"
                stroke="var(--chart-1)"
                strokeWidth={2}
                fill="url(#fd53Requests)"
              />
              <Area
                type="monotone"
                dataKey="errors"
                stroke="var(--chart-4)"
                strokeWidth={1.5}
                fill="transparent"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </Section>

      <div className="grid gap-6 lg:grid-cols-2">
        <Section
          title="Quickstart"
          description="Three calls to a working backend."
        >
          <CodeBlock code={quickstart} />
        </Section>

        <Section
          title="Realtime feed"
          description="Events published to your channels show up here instantly."
          action={
            <Button
              variant="outline"
              size="sm"
              className="cursor-pointer"
              disabled={publishing}
              onClick={async () => {
                setPublishing(true);
                try {
                  await publishTest({
                    projectId: project._id,
                    channel: "console.test",
                    type: "ping",
                    payload: { at: Date.now() },
                  });
                  toast.success("Published to console.test");
                } catch (error) {
                  toast.error(error instanceof Error ? error.message : "Publish failed");
                } finally {
                  setPublishing(false);
                }
              }}
            >
              <Radio className="size-4" />
              Send test event
            </Button>
          }
        >
          <div className="rounded-lg border border-border bg-card">
            {events && events.length > 0 ? (
              <ul className="divide-y divide-border">
                {events.map((event) => (
                  <li key={event._id} className="flex items-center gap-3 px-4 py-3">
                    <Badge variant="secondary" className="font-mono text-[11px]">
                      {event.channel}
                    </Badge>
                    <span className="font-mono text-xs">{event.type}</span>
                    <span className="truncate text-xs text-muted-foreground">
                      {event.payload ? JSON.stringify(event.payload) : "—"}
                    </span>
                    <span className="ml-auto shrink-0 text-[11px] text-muted-foreground">
                      {timeAgo(event._creationTime)}
                    </span>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="px-4 py-8 text-center text-sm text-muted-foreground">
                No events yet. Publish one from{" "}
                <code className="font-mono">POST /v1/realtime/publish</code>.
              </p>
            )}
          </div>
          <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
            <KeyRound className="size-3.5" />
            {stats.activeKeys} active API key{stats.activeKeys === 1 ? "" : "s"} ·
            base URL <code className="font-mono">{apiBase()}</code>
          </div>
        </Section>
      </div>
    </div>
  );
}