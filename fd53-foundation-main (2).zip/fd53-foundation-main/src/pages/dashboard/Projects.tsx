import { useState } from "react";
import { useMutation } from "convex/react";
import { Boxes, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api";
import { useProject } from "@/components/dashboard/ProjectProvider";
import {
  EmptyState,
  LoadingBlock,
  PageHeader,
  Section,
} from "@/components/dashboard/ui";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { formatDate } from "@/lib/fd53";

export default function Projects() {
  const { projects, projectId, setProjectId } = useProject();
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [pending, setPending] = useState(false);

  const createProject = useMutation(api.projects.create);
  const removeProject = useMutation(api.projects.remove);

  if (projects === undefined) {
    return <LoadingBlock label="Loading projects" />;
  }

  const handleCreate = async () => {
    setPending(true);
    try {
      const result = await createProject({ name, description });
      if (result.status === "created") {
        setProjectId(result.projectId);
        toast.success(`Project "${name}" created`, {
          description: "Next: mint an API key and create your first table.",
        });
        setOpen(false);
        setName("");
        setDescription("");
      } else {
        toast.error(result.message);
      }
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Could not create project");
    } finally {
      setPending(false);
    }
  };

  const handleDelete = async (id: (typeof projects)[number]["_id"], title: string) => {
    try {
      await removeProject({ projectId: id });
      toast.success(`Deleted "${title}"`, {
        description: "Its keys, tables, files and end users were removed too.",
      });
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Could not delete project");
    }
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Projects"
        description="Each project is an isolated backend with its own keys, data, files and users."
        action={
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button className="cursor-pointer">
                <Plus className="size-4" />
                New project
              </Button>
            </DialogTrigger>
            <DialogContent className="max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Create a project</DialogTitle>
                <DialogDescription>
                  Name it after the app it powers — e.g. LoopUni, portfolio app,
                  internal tools.
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="project-name">Name</Label>
                  <Input
                    id="project-name"
                    value={name}
                    onChange={(event) => setName(event.target.value)}
                    placeholder="LoopUni"
                    autoFocus
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="project-description">Description (optional)</Label>
                  <Textarea
                    id="project-description"
                    value={description}
                    onChange={(event) => setDescription(event.target.value)}
                    placeholder="FlutterFlow app for students"
                    rows={3}
                  />
                </div>
              </div>
              <DialogFooter>
                <Button
                  variant="outline"
                  className="cursor-pointer"
                  onClick={() => setOpen(false)}
                >
                  Cancel
                </Button>
                <Button
                  className="cursor-pointer"
                  disabled={pending || name.trim().length < 2}
                  onClick={handleCreate}
                >
                  {pending ? "Creating…" : "Create project"}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        }
      />

      {projects.length === 0 ? (
        <EmptyState
          icon={Boxes}
          title="No projects yet"
          description="Create a project to get a base URL, API keys and isolated data for your app."
        />
      ) : (
        <Section title={`${projects.length} project${projects.length === 1 ? "" : "s"}`}>
          <div className="grid gap-3 md:grid-cols-2">
            {projects.map((project) => {
              const active = project._id === projectId;
              return (
                <div
                  key={project._id}
                  className={`flex flex-col gap-3 rounded-lg border p-4 ${
                    active
                      ? "border-primary/60 bg-accent/40"
                      : "border-border bg-card"
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <p className="truncate font-semibold">{project.name}</p>
                      <p className="truncate font-mono text-xs text-muted-foreground">
                        {project.slug}
                      </p>
                    </div>
                    {active ? (
                      <Badge className="shrink-0">active</Badge>
                    ) : (
                      <Badge variant="secondary" className="shrink-0">
                        {project.status}
                      </Badge>
                    )}
                  </div>

                  {project.description ? (
                    <p className="text-sm text-muted-foreground">
                      {project.description}
                    </p>
                  ) : null}

                  <p className="text-xs text-muted-foreground">
                    Created {formatDate(project._creationTime)} · {project.plan} plan ·{" "}
                    {project.requestsPerMinute} req/min
                  </p>

                  <div className="flex flex-wrap gap-2 pt-1">
                    {!active ? (
                      <Button
                        size="sm"
                        variant="outline"
                        className="cursor-pointer"
                        onClick={() => {
                          setProjectId(project._id);
                          toast.success(`Switched to ${project.name}`);
                        }}
                      >
                        Make active
                      </Button>
                    ) : null}
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button
                          size="sm"
                          variant="ghost"
                          className="cursor-pointer text-destructive hover:text-destructive"
                        >
                          <Trash2 className="size-4" />
                          Delete
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Delete "{project.name}"?</DialogTitle>
                          <DialogDescription>
                            This permanently removes the project with all of its API
                            keys, tables, rows, files, end users and usage history.
                          </DialogDescription>
                        </DialogHeader>
                        <DialogFooter>
                          <Button variant="outline" className="cursor-pointer">
                            Cancel
                          </Button>
                          <Button
                            variant="destructive"
                            className="cursor-pointer"
                            onClick={() => handleDelete(project._id, project.name)}
                          >
                            Delete project
                          </Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>
                  </div>
                </div>
              );
            })}
          </div>
        </Section>
      )}
    </div>
  );
}