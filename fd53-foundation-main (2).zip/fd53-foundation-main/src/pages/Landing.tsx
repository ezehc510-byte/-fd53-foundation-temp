import { useEffect, useState } from "react";
import { Link } from "react-router";
import { motion } from "framer-motion";
import {
  ArrowRight,
  Boxes,
  Database,
  Gauge,
  HardDrive,
  Lock,
  Radio,
  ShieldCheck,
  Terminal,
  Zap,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/use-auth";
import { apiBase } from "@/lib/fd53";
import logo from "@/assets/logo.svg";

const TERMINAL_FRAMES = [
  {
    request: `curl ${apiBase()}/v1/auth/login \\
  -H "X-API-Key: fd53_live_…" \\
  -d '{"email":"sam@example.com","password":"correct-horse"}'`,
    response: `{
  "ok": true,
  "data": {
    "token": "eyJhbGciOiJIUzI1NiIs…",
    "expiresIn": 86400,
    "user": { "id": "k57…", "role": "user" }
  }
}`,
  },
  {
    request: `curl -X POST ${apiBase()}/v1/db/todos \\
  -H "X-API-Key: fd53_live_…" \\
  -d '{"data":{"title":"Ship FD53","done":false}}'`,
    response: `{
  "ok": true,
  "data": {
    "row": {
      "id": "m57dam…",
      "data": { "title": "Ship FD53", "done": false }
    }
  }
}`,
  },
  {
    request: `curl -X POST "${apiBase()}/v1/storage/upload?visibility=public" \\
  -H "X-API-Key: fd53_live_…" \\
  -F "file=@avatar.png"`,
    response: `{
  "ok": true,
  "data": {
    "file": { "id": "kd7f56…", "size": 184320, "category": "image" },
    "url": "https://…convex.cloud/api/storage/e71f…"
  }
}`,
  },
];

const SYSTEMS = [
  {
    icon: Lock,
    title: "Authentication",
    tagline: "Email + phone, sessions, roles",
    body: "Register, log in, phone OTP, password resets. Passwords are PBKDF2-hashed, tokens are HS256 JWTs bound to revocable sessions.",
    endpoint: "POST /v1/auth/login",
  },
  {
    icon: Database,
    title: "Database",
    tagline: "Tables, references, queries",
    body: "Define tables with typed columns, unique constraints and references. Read and write them over REST with filters and pagination.",
    endpoint: "GET /v1/db/:table",
  },
  {
    icon: HardDrive,
    title: "Storage",
    tagline: "Images, video, audio, docs",
    body: "Upload from FlutterFlow, curl or any client. Per-project quotas, public/private visibility and scoped access for end users.",
    endpoint: "POST /v1/storage/upload",
  },
  {
    icon: Boxes,
    title: "API Platform",
    tagline: "Keys, scopes, docs",
    body: "One REST surface for auth, data, files and events — with per-key scopes, rate limits and a console that documents every endpoint.",
    endpoint: "X-API-Key: fd53_live_…",
  },
  {
    icon: ShieldCheck,
    title: "Security",
    tagline: "Encryption, RBAC, limits",
    body: "Keys stored as SHA-256 hashes, PBKDF2 password hashing, table access levels, role permissions and sliding-window rate limits.",
    endpoint: "429 + Retry-After",
  },
  {
    icon: Radio,
    title: "Realtime",
    tagline: "Chat, notifications, events",
    body: "Publish to channels and watch the console feed update instantly. The event log is the foundation for chat and notifications.",
    endpoint: "POST /v1/realtime/publish",
  },
];

const FLUTTERFLOW_STEPS = [
  {
    title: "Create a project",
    body: "One FD53 project per app. It owns the tables, files, users and API keys for that app only.",
  },
  {
    title: "Mint an API key",
    body: "Keep the production key in a server action. Keys are shown once and stored hashed.",
  },
  {
    title: "Point FlutterFlow at /v1",
    body: "API calls, server actions and custom uploads speak the same REST endpoints — no SDK to install.",
  },
];

function TerminalWindow() {
  const [frame, setFrame] = useState(0);

  useEffect(() => {
    const timer = window.setInterval(() => {
      setFrame((current) => (current + 1) % TERMINAL_FRAMES.length);
    }, 5200);
    return () => window.clearInterval(timer);
  }, []);

  const current = TERMINAL_FRAMES[frame];

  return (
    <div className="overflow-hidden rounded-xl border border-border bg-card">
      <div className="flex items-center gap-2 border-b border-border px-4 py-2.5">
        <span className="size-2.5 rounded-full bg-destructive/70" />
        <span className="size-2.5 rounded-full bg-chart-2/70" />
        <span className="size-2.5 rounded-full bg-primary/70" />
        <span className="ml-2 font-mono text-[11px] text-muted-foreground">
          fd53 · api
        </span>
      </div>
      <div className="space-y-3 p-4 font-mono text-[11px] leading-relaxed sm:text-xs">
        <motion.div
          key={`req-${frame}`}
          initial={{ opacity: 0, y: 6 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.35 }}
          className="whitespace-pre-wrap text-foreground/90"
        >
          <span className="text-primary">$ </span>
          {current.request}
        </motion.div>
        <motion.div
          key={`res-${frame}`}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.4, delay: 0.15 }}
          className="whitespace-pre-wrap rounded-md border border-border bg-background/60 p-3 text-muted-foreground"
        >
          {current.response}
        </motion.div>
      </div>
    </div>
  );
}

export default function Landing() {
  const { isAuthenticated } = useAuth();
  const consoleHref = isAuthenticated ? "/dashboard" : "/auth";

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Navbar */}
      <header className="sticky top-0 z-40 border-b border-border bg-background/85 backdrop-blur">
        <div className="mx-auto flex h-16 w-full max-w-6xl items-center justify-between gap-4 px-4 sm:px-6">
          <Link to="/" className="flex items-center gap-2.5">
            <img src={logo} alt="FD53" width={28} height={28} className="rounded-md" />
            <span className="font-mono text-lg font-semibold tracking-tight">FD53</span>
          </Link>

          <nav className="hidden items-center gap-7 text-sm text-muted-foreground md:flex">
            <a href="#systems" className="transition-colors hover:text-foreground">
              Systems
            </a>
            <a href="#flutterflow" className="transition-colors hover:text-foreground">
              FlutterFlow
            </a>
            <Link to="/dashboard/docs" className="transition-colors hover:text-foreground">
              Docs
            </Link>
          </nav>

          <Button asChild size="sm" className="cursor-pointer">
            <Link to={consoleHref}>
              {isAuthenticated ? "Open console" : "Get started"}
              <ArrowRight className="size-4" />
            </Link>
          </Button>
        </div>
      </header>

      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="fd53-grid pointer-events-none absolute inset-0 opacity-60" />
        <div className="pointer-events-none absolute -top-40 left-1/2 size-[520px] -translate-x-1/2 rounded-full bg-primary/12 blur-3xl" />

        <div className="relative mx-auto grid w-full max-w-6xl gap-12 px-4 py-16 sm:px-6 lg:grid-cols-[1.05fr_1fr] lg:items-center lg:py-24">
          <div>
            <motion.div
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4 }}
            >
              <Badge variant="outline" className="gap-1.5 font-mono text-[11px]">
                <Terminal className="size-3" />
                backend-as-a-service · v1
              </Badge>
              <h1 className="mt-5 text-4xl leading-[1.05] font-bold tracking-tight sm:text-5xl lg:text-6xl">
                The backend your apps
                <span className="text-primary"> run on.</span>
              </h1>
              <p className="mt-5 max-w-xl text-base text-muted-foreground sm:text-lg">
                FD53 is your own Firebase-grade backend: authentication, database,
                storage, realtime events and one REST API — wired for FlutterFlow and
                whatever you build next.
              </p>

              <div className="mt-8 flex flex-col gap-3 sm:flex-row">
                <Button asChild size="lg" className="cursor-pointer">
                  <Link to={consoleHref}>
                    {isAuthenticated ? "Open the console" : "Start building"}
                    <ArrowRight className="size-4" />
                  </Link>
                </Button>
                <Button asChild size="lg" variant="outline" className="cursor-pointer">
                  <Link to="/dashboard/docs">Read the API docs</Link>
                </Button>
              </div>

              <dl className="mt-10 grid max-w-lg grid-cols-3 gap-4 text-sm">
                {[
                  { label: "Systems", value: "6" },
                  { label: "Endpoints", value: "30+" },
                  { label: "Setup", value: "1 key" },
                ].map((item) => (
                  <div key={item.label} className="border-l border-border pl-3">
                    <dt className="text-muted-foreground">{item.label}</dt>
                    <dd className="font-mono text-xl font-semibold">{item.value}</dd>
                  </div>
                ))}
              </dl>
            </motion.div>
          </div>

          <motion.div
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.15 }}
          >
            <TerminalWindow />
          </motion.div>
        </div>
      </section>

      {/* Systems */}
      <section id="systems" className="border-t border-border bg-card/30 py-16">
        <div className="mx-auto w-full max-w-6xl px-4 sm:px-6">
          <div className="max-w-2xl">
            <h2 className="tracking-tight font-bold text-3xl">
              Everything a backend has to do, in one platform
            </h2>
            <p className="mt-3 text-muted-foreground">
              Each system is a REST namespace under <code className="font-mono">/v1</code>{" "}
              — usable from the console, a FlutterFlow server action, or a script.
            </p>
          </div>

          <div className="mt-10 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {SYSTEMS.map((system, index) => (
              <motion.div
                key={system.title}
                initial={{ opacity: 0, y: 14 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-60px" }}
                transition={{ duration: 0.35, delay: index * 0.05 }}
                className="flex flex-col rounded-xl border border-border bg-card p-5 transition-colors hover:border-primary/40"
              >
                <div className="mb-4 flex size-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
                  <system.icon className="size-5" />
                </div>
                <h3 className="font-semibold">{system.title}</h3>
                <p className="text-xs text-primary/80">{system.tagline}</p>
                <p className="mt-3 flex-1 text-sm leading-relaxed text-muted-foreground">
                  {system.body}
                </p>
                <code className="mt-4 rounded-md border border-border bg-background px-2 py-1.5 font-mono text-[11px] text-muted-foreground">
                  {system.endpoint}
                </code>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* FlutterFlow */}
      <section id="flutterflow" className="border-t border-border py-16">
        <div className="mx-auto grid w-full max-w-6xl gap-10 px-4 sm:px-6 lg:grid-cols-2 lg:items-center">
          <motion.div
            initial={{ opacity: 0, x: -16 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.4 }}
          >
            <Badge variant="outline" className="gap-1.5 font-mono text-[11px]">
              <Zap className="size-3" />
              FlutterFlow ready
            </Badge>
            <h2 className="mt-5 tracking-tight font-bold text-3xl">
              Connect an app in minutes
            </h2>
            <p className="mt-3 text-muted-foreground">
              No SDK, no plugin. FlutterFlow talks to FD53 with ordinary API calls,
              server actions and file uploads — including auth, database requests
              and storage.
            </p>

            <ol className="mt-8 space-y-5">
              {FLUTTERFLOW_STEPS.map((step, index) => (
                <li key={step.title} className="flex gap-4">
                  <span className="flex size-7 shrink-0 items-center justify-center rounded-full border border-primary/40 font-mono text-xs text-primary">
                    {index + 1}
                  </span>
                  <div>
                    <p className="font-medium">{step.title}</p>
                    <p className="text-sm text-muted-foreground">{step.body}</p>
                  </div>
                </li>
              ))}
            </ol>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.4 }}
            className="space-y-4"
          >
            <div className="overflow-hidden rounded-xl border border-border bg-card">
              <div className="border-b border-border px-4 py-2.5 font-mono text-[11px] text-muted-foreground">
                server-action.dart
              </div>
              <pre className="overflow-auto px-4 py-4 font-mono text-[11px] leading-relaxed">
                <code>{`final key = 'fd53_live_…';
final base = '${apiBase()}';

Future<Map<String, dynamic>> signIn(
    String email, String password) async {
  final res = await http.post(
    Uri.parse('\$base/v1/auth/login'),
    headers: {
      'X-API-Key': key,
      'Content-Type': 'application/json',
    },
    body: jsonEncode({'email': email, 'password': password}),
  );
  final data = jsonDecode(res.body)['data'];
  // store data['token'] in a FlutterFlow State Variable
  return data;
}

// Upload an image with the same REST call FlutterFlow's
// native uploader uses: multipart/form-data
Future<String> uploadAvatar(String token, File file) async {
  final res = await http.MultipartRequest(
      'POST', Uri.parse('\$base/v1/storage/upload'))
    ..headers['X-API-Key'] = key
    ..headers['Authorization'] = 'Bearer \$token'
    ..files.add(await http.MultipartFile.fromPath('file', file.path));
  final sent = await res.send();
  final body = jsonDecode(await sent.stream.bytesToString());
  return body['data']['url'];
}`}</code>
              </pre>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Architecture */}
      <section className="border-t border-border bg-card/30 py-16">
        <div className="mx-auto w-full max-w-6xl px-4 sm:px-6">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <h2 className="tracking-tight font-bold text-3xl">
                Built to be the foundation
              </h2>
              <p className="mt-3 max-w-2xl text-muted-foreground">
                FD53 is layered so each piece stays replaceable: a REST gateway, an
                auth layer that understands both API keys and user tokens, and a
                document store that validates every write.
              </p>
            </div>
            <Button asChild variant="outline" className="cursor-pointer">
              <Link to="/dashboard/docs">Architecture & roadmap</Link>
            </Button>
          </div>

          <div className="mt-10 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {[
              {
                icon: Boxes,
                title: "Apps",
                body: "FlutterFlow, native mobile, web, scripts.",
              },
              {
                icon: Terminal,
                title: "REST gateway",
                body: "/v1 endpoints with CORS, keys, quotas, errors.",
              },
              {
                icon: Lock,
                title: "Auth layer",
                body: "API keys + end-user tokens, roles, sessions.",
              },
              {
                icon: Gauge,
                title: "Data & storage",
                body: "Tables, rows, files, events, usage counters.",
              },
            ].map((layer, index) => (
              <motion.div
                key={layer.title}
                initial={{ opacity: 0, y: 12 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-60px" }}
                transition={{ duration: 0.3, delay: index * 0.06 }}
                className="relative rounded-xl border border-border bg-card p-5"
              >
                <layer.icon className="mb-3 size-5 text-primary" />
                <p className="font-semibold">{layer.title}</p>
                <p className="mt-1 text-sm text-muted-foreground">{layer.body}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="border-t border-border py-20">
        <div className="mx-auto w-full max-w-3xl px-4 text-center sm:px-6">
          <motion.div
            initial={{ opacity: 0, y: 14 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.4 }}
          >
            <h2 className="tracking-tight font-bold text-3xl sm:text-4xl">
              Give your next app a real backend
            </h2>
            <p className="mx-auto mt-4 max-w-xl text-muted-foreground">
              Create a project, mint a key, make your first request. Everything else —
              users, files, realtime, quotas — is already there.
            </p>
            <div className="mt-8 flex flex-col justify-center gap-3 sm:flex-row">
              <Button asChild size="lg" className="cursor-pointer">
                <Link to={consoleHref}>
                  {isAuthenticated ? "Open the console" : "Start building free"}
                  <ArrowRight className="size-4" />
                </Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="cursor-pointer">
                <Link to="/dashboard/docs">Browse the docs</Link>
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-8">
        <div className="mx-auto flex w-full max-w-6xl flex-col items-center justify-between gap-3 px-4 text-sm text-muted-foreground sm:flex-row sm:px-6">
          <div className="flex items-center gap-2">
            <img src={logo} alt="FD53" width={20} height={20} className="rounded" />
            <span className="font-mono">FD53</span>
            <span>· your backend as a service</span>
          </div>
          <div className="flex gap-5">
            <Link to="/dashboard/docs" className="transition-colors hover:text-foreground">
              Docs
            </Link>
            <Link to={consoleHref} className="transition-colors hover:text-foreground">
              Console
            </Link>
          </div>
        </div>
      </footer>
    </div>
  );
}