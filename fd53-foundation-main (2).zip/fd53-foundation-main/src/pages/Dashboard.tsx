import { useState } from "react";
import { Link, NavLink, Outlet, useNavigate } from "react-router";
import { motion } from "framer-motion";
import {
  Activity,
  BookOpen,
  Boxes,
  Database,
  HardDrive,
  KeyRound,
  LayoutDashboard,
  LogOut,
  Menu,
  Plus,
  Users,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { ProjectProvider, useProject } from "@/components/dashboard/ProjectProvider";
import { LoadingBlock } from "@/components/dashboard/ui";
import { useAuth } from "@/hooks/use-auth";
import logo from "@/assets/logo.svg";

const NAV_SECTIONS = [
  {
    label: "Build",
    items: [
      { to: "/dashboard", label: "Overview", icon: LayoutDashboard, end: true },
      { to: "/dashboard/projects", label: "Projects", icon: Boxes },
      { to: "/dashboard/api-keys", label: "API Keys", icon: KeyRound },
    ],
  },
  {
    label: "Data",
    items: [
      { to: "/dashboard/database", label: "Database", icon: Database },
      { to: "/dashboard/storage", label: "Storage", icon: HardDrive },
      { to: "/dashboard/users", label: "Users", icon: Users },
    ],
  },
  {
    label: "Operations",
    items: [
      { to: "/dashboard/usage", label: "Usage", icon: Activity },
      { to: "/dashboard/docs", label: "API Docs", icon: BookOpen },
    ],
  },
];

function Brand() {
  return (
    <Link to="/" className="flex items-center gap-2.5">
      <img src={logo} alt="FD53" width={28} height={28} className="rounded-md" />
      <span className="font-mono text-lg font-semibold tracking-tight">
        FD53
      </span>
    </Link>
  );
}

function ProjectSwitcher({ onNavigate }: { onNavigate?: () => void }) {
  const { projects, project, projectId, setProjectId } = useProject();
  const navigate = useNavigate();

  if (projects && projects.length === 0) {
    return (
      <Button
        type="button"
        variant="outline"
        size="sm"
        className="w-full cursor-pointer gap-2"
        onClick={() => {
          onNavigate?.();
          navigate("/dashboard/projects");
        }}
      >
        <Plus className="size-4" />
        Create your first project
      </Button>
    );
  }

  return (
    <div className="space-y-2">
      <Select
        value={projectId ?? undefined}
        onValueChange={(value) => {
          setProjectId(value as typeof projectId & string);
          onNavigate?.();
        }}
      >
        <SelectTrigger className="w-full" aria-label="Active project">
          <SelectValue placeholder={projects ? "Select a project" : undefined} />
        </SelectTrigger>
        <SelectContent>
          {(projects ?? []).map((p) => (
            <SelectItem key={p._id} value={p._id}>
              {p.name}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
      {project ? (
        <p className="px-1 font-mono text-[11px] text-muted-foreground">
          {project.slug} · {project.plan} plan
        </p>
      ) : null}
    </div>
  );
}

function NavLinks({ onNavigate }: { onNavigate?: () => void }) {
  return (
    <nav className="flex-1 space-y-6 overflow-y-auto px-3 py-4">
      {NAV_SECTIONS.map((section) => (
        <div key={section.label}>
          <p className="px-2 pb-2 text-[11px] font-medium tracking-widest text-muted-foreground uppercase">
            {section.label}
          </p>
          <ul className="space-y-0.5">
            {section.items.map((item) => (
              <li key={item.to}>
                <NavLink
                  to={item.to}
                  end={item.end}
                  onClick={onNavigate}
                  className={({ isActive }) =>
                    `flex items-center gap-2.5 rounded-md px-2 py-2 text-sm transition-colors ${
                      isActive
                        ? "bg-accent text-accent-foreground"
                        : "text-muted-foreground hover:bg-accent/60 hover:text-foreground"
                    }`
                  }
                >
                  <item.icon className="size-4" />
                  {item.label}
                </NavLink>
              </li>
            ))}
          </ul>
        </div>
      ))}
    </nav>
  );
}

function SidebarFooter() {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();

  return (
    <div className="border-t border-border px-3 py-3">
      <p className="truncate px-2 text-xs text-muted-foreground">
        {user?.email ?? user?.name ?? "Signed in"}
      </p>
      <Button
        type="button"
        variant="ghost"
        size="sm"
        className="mt-1 w-full cursor-pointer justify-start gap-2 px-2"
        onClick={async () => {
          await signOut();
          navigate("/");
        }}
      >
        <LogOut className="size-4" />
        Sign out
      </Button>
    </div>
  );
}

function ConsoleShell() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const { projects } = useProject();

  if (projects === undefined) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-background">
        <LoadingBlock label="Opening your FD53 console" />
      </main>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="flex min-h-screen">
        <aside className="sticky top-0 hidden h-screen w-64 shrink-0 flex-col border-r border-border bg-sidebar lg:flex">
          <div className="border-b border-border px-5 py-4">
            <Brand />
          </div>
          <div className="px-3 py-4">
            <ProjectSwitcher />
          </div>
          <NavLinks />
          <SidebarFooter />
        </aside>

        <div className="flex min-w-0 flex-1 flex-col">
          <header className="sticky top-0 z-30 flex items-center gap-3 border-b border-border bg-background/90 px-4 py-3 backdrop-blur lg:hidden">
            <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
              <SheetTrigger asChild>
                <Button variant="outline" size="icon" className="cursor-pointer">
                  <Menu className="size-4" />
                  <span className="sr-only">Open navigation</span>
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-72 p-0">
                <SheetHeader className="border-b border-border px-5 py-4">
                  <SheetTitle>
                    <Brand />
                  </SheetTitle>
                </SheetHeader>
                <div className="px-3 py-4">
                  <ProjectSwitcher onNavigate={() => setMobileOpen(false)} />
                </div>
                <NavLinks onNavigate={() => setMobileOpen(false)} />
                <SidebarFooter />
              </SheetContent>
            </Sheet>
            <Brand />
          </header>

          <motion.main
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.2 }}
            className="flex-1 px-4 py-6 sm:px-6 lg:px-8 lg:py-10"
          >
            <div className="mx-auto w-full max-w-6xl">
              <Outlet />
            </div>
          </motion.main>
        </div>
      </div>
    </div>
  );
}

export default function Dashboard() {
  return (
    <ProjectProvider>
      <ConsoleShell />
    </ProjectProvider>
  );
}