import { httpRouter } from "convex/server";
import { auth } from "./auth";
import { handle, options } from "./rest/router";
import { httpAction } from "./_generated/server";

const http = httpRouter();

// Convex Auth (the developer console sign-in) keeps its own routes.
auth.addHttpRoutes(http);

// --- FD53 public API --------------------------------------------------------
// Everything under /v1 is API-key authenticated, CORS enabled and rate limited.

http.route({
  pathPrefix: "/v1/",
  method: "OPTIONS",
  handler: httpAction(async (_ctx, request) => options(request)),
});

http.route({
  pathPrefix: "/v1/",
  method: "GET",
  handler: httpAction(async (ctx, request) => await handle(ctx, request, "GET")),
});

http.route({
  pathPrefix: "/v1/",
  method: "POST",
  handler: httpAction(async (ctx, request) => await handle(ctx, request, "POST")),
});

http.route({
  pathPrefix: "/v1/",
  method: "PUT",
  handler: httpAction(async (ctx, request) => await handle(ctx, request, "PUT")),
});

http.route({
  pathPrefix: "/v1/",
  method: "PATCH",
  handler: httpAction(async (ctx, request) => await handle(ctx, request, "PATCH")),
});

http.route({
  pathPrefix: "/v1/",
  method: "DELETE",
  handler: httpAction(async (ctx, request) => await handle(ctx, request, "DELETE")),
});

// Exact match for the service root: GET /v1
http.route({
  path: "/v1",
  method: "GET",
  handler: httpAction(async (ctx, request) => await handle(ctx, request, "GET")),
});

export default http;