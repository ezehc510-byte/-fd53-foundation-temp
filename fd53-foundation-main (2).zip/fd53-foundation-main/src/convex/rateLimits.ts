/**
 * Application-level rate limiting (anti-spam).
 *
 * This sits *in front of* the per-API-key limiter in `usage.ts`. The API-key
 * limiter protects the project's quota; this one protects individual end
 * users from spamming the app (posting, following, messaging, checking out)
 * with their own valid token. Windows are fixed (not sliding) so a blocked
 * caller always gets a concrete `Retry-After`.
 */
import { v } from "convex/values";
import { ANTI_SPAM_LIMITS } from "./lib/constants";
import type { Id } from "./_generated/dataModel";
import {
  internalMutation,
  query,
  type MutationCtx,
} from "./_generated/server";

export type HitResult =
  | { allowed: true; remaining: number; limit: number; resetAt: number }
  | {
      allowed: false;
      remaining: 0;
      limit: number;
      resetAt: number;
      retryAfterSeconds: number;
    };

type HitArgs = {
  projectId: Id<"projects">;
  key: string;
  limit: number;
  windowMs: number;
};

/**
 * Count one call against `key` and report whether it is allowed.
 * Stale rows for the same key are pruned so a caller cannot build history.
 */
async function doHit(ctx: MutationCtx, args: HitArgs): Promise<HitResult> {
  const now = Date.now();
  const windowStart = Math.floor(now / args.windowMs) * args.windowMs;
  const resetAt = windowStart + args.windowMs;

  // Keep at most the two most recent windows for this key.
  const history = await ctx.db
    .query("rateLimits")
    .withIndex("by_key", (q) =>
      q.eq("projectId", args.projectId).eq("key", args.key),
    )
    .collect();
  for (const row of history) {
    if (row.windowStart < windowStart - args.windowMs) {
      await ctx.db.delete(row._id);
    }
  }

  const current = history.find((row) => row.windowStart === windowStart);
  const count = (current?.count ?? 0) + 1;

  // A previous overrun keeps the caller blocked for the rest of the window.
  const blocked = (current?.blockedUntil ?? 0) > now || count > args.limit;

  if (current) {
    await ctx.db.patch(current._id, {
      count,
      blockedUntil: blocked ? resetAt : undefined,
    });
  } else {
    await ctx.db.insert("rateLimits", {
      projectId: args.projectId,
      key: args.key,
      windowStart,
      count,
      blockedUntil: blocked ? resetAt : undefined,
    });
  }

  if (blocked) {
    return {
      allowed: false,
      remaining: 0,
      limit: args.limit,
      resetAt,
      retryAfterSeconds: Math.max(1, Math.ceil((resetAt - now) / 1000)),
    };
  }
  return {
    allowed: true,
    remaining: Math.max(0, args.limit - count),
    limit: args.limit,
    resetAt,
  };
}

export const hit = internalMutation({
  args: {
    projectId: v.id("projects"),
    name: v.string(),
    key: v.string(),
    limit: v.optional(v.number()),
    windowMs: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const config = ANTI_SPAM_LIMITS[args.name];
    if (!config) {
      // An unlisted action is a programming error, not a client error: fail
      // closed rather than silently allowing unlimited traffic.
      console.warn("FD53: no anti-spam limit configured for", args.name);
      return {
        allowed: false,
        remaining: 0,
        limit: 0,
        resetAt: Date.now() + 60_000,
        retryAfterSeconds: 60,
      };
    }
    return await doHit(ctx, {
      projectId: args.projectId,
      key: `${args.name}:${args.key}`,
      limit: args.limit ?? config.limit,
      windowMs: args.windowMs ?? config.windowMs,
    });
  },
});

/** Dashboard view of callers that are currently throttled. */
export const active = query({
  args: { projectId: v.id("projects") },
  handler: async (ctx, args) => {
    const now = Date.now();
    const rows = await ctx.db
      .query("rateLimits")
      .withIndex("by_project", (q) => q.eq("projectId", args.projectId))
      .collect();
    return rows
      .filter((row) => (row.blockedUntil ?? 0) > now)
      .map((row) => ({
        key: row.key,
        count: row.count,
        blockedUntil: row.blockedUntil ?? null,
      }));
  },
});