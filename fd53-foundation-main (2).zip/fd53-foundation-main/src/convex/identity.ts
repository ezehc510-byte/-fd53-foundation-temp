/**
 * LoopUni identity: the `users` credential row plus its public `profile`.
 *
 * FD53's `endUsers` table holds the per-project auth account (PBKDF2 hash,
 * lockout state, token version). `users` is the global LoopUni identity that
 * owns credentials and a unique @handle; `profiles` is everything about that
 * identity that other users may read. Keeping them apart means an app's auth
 * account can be banned per-project without destroying the identity.
 */
import { v } from "convex/values";
import { requireOwnedProject } from "./lib/authz";
import type { Doc, Id } from "./_generated/dataModel";
import { internalMutation, internalQuery, query } from "./_generated/server";

/** Handles are lowercase-safe: 3–30 chars of a-z, 0-9 and underscore. */
export const HANDLE_PATTERN = /^[a-zA-Z0-9_]{3,30}$/;

/** Reserved handles that must never be claimed. */
const RESERVED_HANDLES = new Set([
  "admin",
  "administrator",
  "root",
  "system",
  "support",
  "help",
  "api",
  "loopuni",
  "fd53",
  "null",
  "undefined",
]);

export function isValidHandle(handle: string): boolean {
  return (
    HANDLE_PATTERN.test(handle) &&
    !RESERVED_HANDLES.has(handle.toLowerCase())
  );
}

/** Turn an email/name into a candidate handle when none was supplied. */
export function suggestHandle(seed: string): string {
  const base = seed
    .split("@")[0]
    .toLowerCase()
    .replace(/[^a-z0-9_]/g, "_")
    .replace(/_{2,}/g, "_")
    .replace(/^_|_$/g, "")
    .slice(0, 30);
  const trimmed = base.length >= 3 ? base : `user_${base}`.slice(0, 30);
  return isValidHandle(trimmed) ? trimmed : "user";
}

// ---------------------------------------------------------------------------
// Shapers
// ---------------------------------------------------------------------------

export function publicProfile(
  profile: Doc<"profiles"> & { isFollowing?: boolean | null },
) {
  return {
    id: profile._id,
    userId: profile.userId,
    handle: profile.handle,
    displayName: profile.displayName ?? null,
    bio: profile.bio ?? null,
    avatarUrl: profile.avatarUrl ?? null,
    bannerUrl: profile.bannerUrl ?? null,
    location: profile.location ?? null,
    website: profile.website ?? null,
    followerCount: profile.followerCount,
    followingCount: profile.followingCount,
    postCount: profile.postCount,
    isCreator: profile.isCreator ?? false,
    isVerified: profile.isVerified ?? false,
    isFollowing: profile.isFollowing ?? null,
    createdAt: profile._creationTime,
  };
}

// ---------------------------------------------------------------------------
// Internal queries
// ---------------------------------------------------------------------------

export const byUsername = internalQuery({
  args: { usernameLower: v.string() },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("users")
      .withIndex("by_username", (q) => q.eq("usernameLower", args.usernameLower))
      .first();
  },
});

export const byId = internalQuery({
  args: { userId: v.id("users") },
  handler: async (ctx, args) => await ctx.db.get(args.userId),
});

export const profileByUser = internalQuery({
  args: { projectId: v.id("projects"), userId: v.id("users") },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("profiles")
      .withIndex("by_user", (q) => q.eq("userId", args.userId))
      .filter((q) => q.eq(q.field("projectId"), args.projectId))
      .unique();
  },
});

/** Resolve the LoopUni profile from the FD53 end-user token subject. */
export const profileByEndUser = internalQuery({
  args: { projectId: v.id("projects"), endUserId: v.id("endUsers") },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("profiles")
      .withIndex("by_end_user", (q) =>
        q.eq("projectId", args.projectId).eq("endUserId", args.endUserId),
      )
      .first();
  },
});

export const profileByHandle = internalQuery({
  args: { projectId: v.id("projects"), handleLower: v.string() },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("profiles")
      .withIndex("by_project_handle", (q) =>
        q.eq("projectId", args.projectId).eq("handleLower", args.handleLower),
      )
      .first();
  },
});

/** Batch profile lookup — avoids N+1 queries when shaping a feed. */
export const profilesForUsers = internalQuery({
  args: { projectId: v.id("projects"), userIds: v.array(v.id("users")) },
  handler: async (ctx, args) => {
    if (args.userIds.length === 0) return [];
    const rows = await ctx.db
      .query("profiles")
      .withIndex("by_project_handle", (q) => q.eq("projectId", args.projectId))
      .collect();
    return rows.filter((p) => args.userIds.includes(p.userId));
  },
});

// ---------------------------------------------------------------------------
// Internal mutations
// ---------------------------------------------------------------------------

/**
 * Create the LoopUni identity + profile for a freshly registered end user.
 * Handles are unique globally, so a collision retried with `handleSuffix`.
 */
export const createIdentity = internalMutation({
  args: {
    projectId: v.id("projects"),
    endUserId: v.id("endUsers"),
    email: v.optional(v.string()),
    name: v.optional(v.string()),
    username: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    // Idempotent: a re-register for the same end user returns the existing rows.
    const existingUser = await ctx.db
      .query("profiles")
      .withIndex("by_end_user", (q) =>
        q.eq("projectId", args.projectId).eq("endUserId", args.endUserId),
      )
      .first();
    if (existingUser) {
      const user = await ctx.db.get(existingUser.userId);
      return {
        status: "existing" as const,
        userId: existingUser.userId,
        profileId: existingUser._id,
        handle: existingUser.handle,
        user: user ?? null,
      };
    }

    const base = args.username
      ? args.username.trim()
      : suggestHandle(args.name ?? args.email ?? `user_${args.endUserId}`);

    let handle: string | null = null;
    for (let attempt = 0; attempt < 12 && handle === null; attempt++) {
      const candidate =
        attempt === 0 ? base : `${base.slice(0, 27)}${attempt}`;
      if (!isValidHandle(candidate)) continue;
      const taken = await ctx.db
        .query("users")
        .withIndex("by_username", (q) => q.eq("usernameLower", candidate.toLowerCase()))
        .first();
      if (!taken) handle = candidate;
    }
    if (!handle) {
      return {
        status: "no_handle_available" as const,
        message: "Could not allocate a unique handle. Try registering again.",
      };
    }

    const userId = await ctx.db.insert("users", {
      name: args.name ?? handle,
      email: args.email,
      username: handle,
      usernameLower: handle.toLowerCase(),
      tokenVersion: 1,
      role: "member",
    });

    const profileId = await ctx.db.insert("profiles", {
      projectId: args.projectId,
      userId: userId as Id<"users">,
      endUserId: args.endUserId,
      handle,
      handleLower: handle.toLowerCase(),
      displayName: args.name ?? handle,
      followerCount: 0,
      followingCount: 0,
      postCount: 0,
      isCreator: false,
    });

    const user = await ctx.db.get(userId);
    return {
      status: "created" as const,
      userId: userId as Id<"users">,
      profileId,
      handle,
      user: user ?? null,
    };
  },
});

/** Patch the public profile (dashboard or app-driven profile editor). */
export const updateProfile = internalMutation({
  args: {
    projectId: v.id("projects"),
    userId: v.id("users"),
    displayName: v.optional(v.string()),
    bio: v.optional(v.string()),
    avatarUrl: v.optional(v.string()),
    bannerUrl: v.optional(v.string()),
    location: v.optional(v.string()),
    website: v.optional(v.string()),
    isCreator: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    const profile = await ctx.db
      .query("profiles")
      .withIndex("by_user", (q) => q.eq("userId", args.userId))
      .filter((q) => q.eq(q.field("projectId"), args.projectId))
      .unique();
    if (!profile) return { status: "not_found" as const };
    await ctx.db.patch(profile._id, {
      displayName: args.displayName,
      bio: args.bio,
      avatarUrl: args.avatarUrl,
      bannerUrl: args.bannerUrl,
      location: args.location,
      website: args.website,
      isCreator: args.isCreator,
    });
    return { status: "ok" as const, profileId: profile._id };
  },
});

// ---------------------------------------------------------------------------
// Dashboard
// ---------------------------------------------------------------------------

export const stats = query({
  args: { projectId: v.id("projects") },
  handler: async (ctx, args) => {
    await requireOwnedProject(ctx, args.projectId);
    const profiles = await ctx.db
      .query("profiles")
      .withIndex("by_project_handle", (q) => q.eq("projectId", args.projectId))
      .collect();
    const users = await ctx.db
      .query("users")
      .withIndex("by_username")
      .collect();
    return {
      profiles: profiles.length,
      identities: users.filter((u) => u.username).length,
      creators: profiles.filter((p) => p.isCreator).length,
    };
  },
});