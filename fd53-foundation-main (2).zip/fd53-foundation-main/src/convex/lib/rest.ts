/**
 * Shared plumbing for the FD53 REST API (`/v1/*`):
 * CORS, response envelope, errors, API-key auth, end-user token auth and
 * rate limiting / usage accounting.
 */
import type { Doc, Id } from "../_generated/dataModel";
import type { ActionCtx } from "../_generated/server";
import { internal } from "../_generated/api";
import { TOKEN_TTL_SECONDS } from "./constants";
import {
  randomHex,
  sha256Hex,
  signJwt,
  verifyJwt,
  type JwtPayload,
} from "./crypto";

// ---------------------------------------------------------------------------
// Responses + CORS
// ---------------------------------------------------------------------------

export function corsHeaders(): Record<string, string> {
  return {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, POST, PUT, PATCH, DELETE, OPTIONS",
    "Access-Control-Allow-Headers":
      "Content-Type, Authorization, X-API-Key, X-FD53-Key",
    "Access-Control-Expose-Headers":
      "X-RateLimit-Limit, X-RateLimit-Remaining, X-RateLimit-Reset",
    "Access-Control-Max-Age": "86400",
  };
}

export function json(
  body: unknown,
  status = 200,
  headers: Record<string, string> = {},
): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json", ...corsHeaders(), ...headers },
  });
}

export function ok(
  data: unknown,
  headers: Record<string, string> = {},
): Response {
  return json({ ok: true, data }, 200, headers);
}

export function fail(
  status: number,
  code: string,
  message: string,
  headers: Record<string, string> = {},
): Response {
  return json({ ok: false, error: { code, message } }, status, headers);
}

export class HttpError extends Error {
  status: number;
  code: string;
  headers: Record<string, string>;

  constructor(
    status: number,
    code: string,
    message: string,
    headers: Record<string, string> = {},
  ) {
    super(message);
    this.status = status;
    this.code = code;
    this.headers = headers;
  }
}

// ---------------------------------------------------------------------------
// Request helpers
// ---------------------------------------------------------------------------

const MAX_JSON_BYTES = 512 * 1024;

/** Read + parse a JSON body with a size cap. `{}` on empty bodies. */
export async function readJson(request: Request): Promise<Record<string, unknown>> {
  const text = await request.text();
  if (!text) return {};
  if (text.length > MAX_JSON_BYTES) {
    throw new HttpError(413, "payload_too_large", "Request body exceeds 512 KB.");
  }
  try {
    const parsed = JSON.parse(text);
    if (parsed === null || typeof parsed !== "object" || Array.isArray(parsed)) {
      throw new HttpError(400, "invalid_body", "Body must be a JSON object.");
    }
    return parsed as Record<string, unknown>;
  } catch (err) {
    if (err instanceof HttpError) throw err;
    throw new HttpError(400, "invalid_json", "Request body is not valid JSON.");
  }
}

export function str(
  body: Record<string, unknown>,
  field: string,
  opts: { required?: boolean; max?: number } = {},
): string | undefined {
  const value = body[field];
  if (value === undefined || value === null || value === "") {
    if (opts.required) {
      throw new HttpError(400, "missing_field", `"${field}" is required.`);
    }
    return undefined;
  }
  if (typeof value !== "string") {
    throw new HttpError(400, "invalid_field", `"${field}" must be a string.`);
  }
  if (opts.max && value.length > opts.max) {
    throw new HttpError(
      400,
      "invalid_field",
      `"${field}" must be at most ${opts.max} characters.`,
    );
  }
  return value;
}

export function clientIp(request: Request): string | undefined {
  const forwarded = request.headers.get("x-forwarded-for");
  if (forwarded) return forwarded.split(",")[0].trim();
  return undefined;
}

function bearerValue(request: Request): string | undefined {
  const header = request.headers.get("authorization");
  if (!header) return undefined;
  const match = /^Bearer\s+(.+)$/i.exec(header.trim());
  return match ? match[1].trim() : undefined;
}

/** Raw presented credential: X-API-Key / X-FD53-Key or Authorization bearer. */
export function presentedKey(request: Request): string | undefined {
  return (
    request.headers.get("x-api-key") ??
    request.headers.get("x-fd53-key") ??
    bearerValue(request)
  );
}

// ---------------------------------------------------------------------------
// API-key authentication (app-level, e.g. FlutterFlow backend calls)
// ---------------------------------------------------------------------------

export type Principal = {
  project: Doc<"projects">;
  key: Doc<"apiKeys">;
};

/** Usage categories — mirror the `usageCategoryValidator` in the schema. */
export type UsageCategory =
  | "auth"
  | "database"
  | "storage"
  | "realtime"
  | "social"
  | "marketplace"
  | "system";

export async function authenticateKey(
  ctx: ActionCtx,
  request: Request,
  scope: string,
): Promise<Principal> {
  const raw = presentedKey(request);
  if (!raw) {
    throw new HttpError(
      401,
      "missing_api_key",
      'Provide your FD53 API key via the "X-API-Key" header (or "Authorization: Bearer fd53_live_...").',
    );
  }

  const key = await ctx.runQuery(internal.apiKeys.byHash, {
    hash: await sha256Hex(raw),
  });
  if (!key || key.revokedAt) {
    throw new HttpError(401, "invalid_api_key", "This API key is invalid or revoked.");
  }

  const project = await ctx.runQuery(internal.projects.byId, {
    id: key.projectId,
  });
  if (!project) {
    throw new HttpError(401, "invalid_api_key", "The project for this key no longer exists.");
  }
  if (project.status !== "active") {
    throw new HttpError(403, "project_suspended", "This project is suspended.");
  }

  if (key.scopes.length > 0 && !key.scopes.includes("*") && !key.scopes.includes(scope)) {
    throw new HttpError(
      403,
      "insufficient_scope",
      `This API key is not allowed to use the "${scope}" scope.`,
    );
  }

  return { project, key };
}

/** Rate limit + usage accounting, performed once per authenticated request. */
export async function enforceQuota(
  ctx: ActionCtx,
  principal: Principal,
  category: UsageCategory,
): Promise<void> {
  const limit = Math.min(principal.key.rateLimit, principal.project.requestsPerMinute);
  const result = await ctx.runMutation(internal.usage.consumeQuota, {
    keyId: principal.key._id,
    projectId: principal.project._id,
    category,
    limit,
  });
  if (result.limited) {
    throw new HttpError(
      429,
      "rate_limited",
      `Rate limit of ${limit} requests/minute exceeded. Retry in ${Math.ceil(
        result.retryAfterSeconds,
      )}s.`,
      {
        "X-RateLimit-Limit": String(limit),
        "X-RateLimit-Remaining": "0",
        "X-RateLimit-Reset": String(result.resetAt),
        "Retry-After": String(Math.ceil(result.retryAfterSeconds)),
      },
    );
  }
}

export async function recordError(
  ctx: ActionCtx,
  principal: Principal | null,
  category: UsageCategory,
): Promise<void> {
  if (!principal) return;
  try {
    await ctx.runMutation(internal.usage.recordError, {
      projectId: principal.project._id,
      category,
    });
  } catch {
    // accounting must never break the request path
  }
}

// ---------------------------------------------------------------------------
// Application-level anti-spam (per end user, not per API key)
// ---------------------------------------------------------------------------

/**
 * Count one end-user action against a named limit ("post", "follow", …).
 * Throws 429 with a Retry-After when the caller is over their allowance, so a
 * single abusive token cannot burn a shared app's whole API-key quota.
 */
export async function enforceAntiSpam(
  ctx: ActionCtx,
  projectId: Id<"projects">,
  name: string,
  key: string,
): Promise<void> {
  const result = await ctx.runMutation(internal.rateLimits.hit, {
    projectId,
    name,
    key,
  });
  if (!result.allowed) {
    throw new HttpError(
      429,
      "rate_limited",
      `Too many ${name} requests. Try again in ${result.retryAfterSeconds}s.`,
      {
        "X-RateLimit-Limit": String(result.limit),
        "X-RateLimit-Remaining": "0",
        "X-RateLimit-Reset": String(result.resetAt),
        "Retry-After": String(result.retryAfterSeconds),
      },
    );
  }
}

// ---------------------------------------------------------------------------
// End-user authentication (FD53 Auth tokens issued to an app's users)
// ---------------------------------------------------------------------------

export type EndUserContext = {
  user: Doc<"endUsers">;
  session: Doc<"sessions">;
  permissions: string[];
};

/**
 * Read a server-side secret, generating one on first use.
 * Actions may be non-deterministic, so the value is minted here (once).
 */
export async function getOrCreateSecret(
  ctx: ActionCtx,
  key: string,
): Promise<string> {
  const existing = await ctx.runQuery(internal.secrets.get, { key });
  if (existing) return existing;
  return await ctx.runMutation(internal.secrets.ensure, {
    key,
    value: randomHex(32),
  });
}

export async function getJwtSecret(ctx: ActionCtx): Promise<string> {
  return await getOrCreateSecret(ctx, "fd53.jwt");
}

function authorizationHeader(request: Request): string | undefined {
  return bearerValue(request);
}

export async function authenticateEndUser(
  ctx: ActionCtx,
  request: Request,
  projectId: Id<"projects">,
): Promise<EndUserContext> {
  const token = authorizationHeader(request);
  if (!token) {
    throw new HttpError(
      401,
      "missing_token",
      'Sign in first and send the access token via "Authorization: Bearer <token>".',
    );
  }

  const secret = await getJwtSecret(ctx);
  const payload = await verifyJwt(token, secret);
  if (!payload || payload.pid !== projectId) {
    throw new HttpError(401, "invalid_token", "The access token is invalid or expired.");
  }

  const user = await ctx.runQuery(internal.endUsers.byId, {
    id: payload.sub as Id<"endUsers">,
    projectId,
  });
  if (!user) {
    throw new HttpError(401, "invalid_token", "The access token is invalid or expired.");
  }
  if (user.status === "banned") {
    throw new HttpError(403, "account_banned", "This account has been disabled.");
  }
  if (user.tokenVersion !== payload.v) {
    throw new HttpError(401, "token_revoked", "This token has been revoked. Sign in again.");
  }

  const session = await ctx.runQuery(internal.sessions.bySid, {
    projectId,
    sid: payload.sid,
  });
  if (!session || session.revokedAt || session.expiresAt < Date.now()) {
    throw new HttpError(
      401,
      "session_expired",
      "This session has ended. Sign in again.",
    );
  }

  const role = await ctx.runQuery(internal.roles.byName, {
    projectId,
    name: user.role,
  });

  return {
    user,
    session,
    permissions: role?.permissions ?? ["db:read", "storage:read"],
  };
}

/**
 * Resolve the end user from the bearer token if one was supplied.
 * Never throws — used on endpoints that are public but scope data per user.
 */
export async function maybeEndUser(
  ctx: ActionCtx,
  request: Request,
  projectId: Id<"projects">,
): Promise<EndUserContext | null> {
  if (!authorizationHeader(request)) return null;
  try {
    return await authenticateEndUser(ctx, request, projectId);
  } catch {
    return null;
  }
}

export function hasPermission(
  endUser: EndUserContext,
  permission: string,
): boolean {
  return (
    endUser.permissions.includes("*") ||
    endUser.permissions.includes(permission)
  );
}

// ---------------------------------------------------------------------------
// Token issuance
// ---------------------------------------------------------------------------

export type IssuedToken = {
  token: string;
  /** Session id embedded in the token and stored server-side. */
  sid: string;
};

/** Create a session record and sign a matching HS256 access token. */
export async function issueSession(
  ctx: ActionCtx,
  user: Doc<"endUsers">,
  userAgent?: string | null,
): Promise<IssuedToken> {
  const secret = await getJwtSecret(ctx);
  const sid = randomHex(16);
  const nowSeconds = Math.floor(Date.now() / 1000);
  const payload: JwtPayload = {
    sub: user._id,
    pid: user.projectId,
    sid,
    role: user.role,
    v: user.tokenVersion,
    iat: nowSeconds,
    exp: nowSeconds + TOKEN_TTL_SECONDS,
  };
  const token = await signJwt(payload, secret);
  await ctx.runMutation(internal.sessions.create, {
    projectId: user.projectId,
    endUserId: user._id,
    sid,
    expiresAt: Date.now() + TOKEN_TTL_SECONDS * 1000,
    userAgent: userAgent ?? undefined,
  });
  return { token, sid };
}

// ---------------------------------------------------------------------------
// Access-control checks for database tables
// ---------------------------------------------------------------------------

export function checkTableAccess(
  table: Doc<"tables">,
  endUser: EndUserContext | null,
  action: "read" | "write",
): void {
  if (table.access === "public") return;
  if (!endUser) {
    throw new HttpError(
      401,
      "auth_required",
      `This table requires an end-user token ("${table.access}" access).`,
    );
  }
  const permission =
    action === "read"
      ? "db:read"
      : "db:write";
  if (!hasPermission(endUser, permission)) {
    throw new HttpError(
      403,
      "forbidden",
      `Your role does not allow ${permission} on this table.`,
    );
  }
}

/** Build a 401 problem for a missing/invalid end-user token. */
export function requireToken(present: boolean): void {
  if (!present) {
    throw new HttpError(
      401,
      "auth_required",
      'This endpoint needs an FD53 end-user token: "Authorization: Bearer <token>".',
    );
  }
}

// ---------------------------------------------------------------------------
// Defensive id handling
// ---------------------------------------------------------------------------

/**
 * Convex validates `v.id(...)` arguments before a function runs, so a client
 * that sends an id from the wrong collection (or a fabricated one) would
 * otherwise get a 500. Convert that specific failure into a clean 404 and
 * re-throw anything else untouched.
 */
export async function runOrNotFound<T>(
  fn: () => Promise<T>,
  status: number,
  code: string,
  message: string,
): Promise<T> {
  try {
    return await fn();
  } catch (error) {
    if (error instanceof HttpError) throw error;
    const text = error instanceof Error ? error.message : String(error);
    if (text.includes("ArgumentValidationError")) {
      throw new HttpError(status, code, message);
    }
    throw error;
  }
}
