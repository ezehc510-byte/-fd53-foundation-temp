import { getAuthUserId } from "@convex-dev/auth/server";
import type { Doc, Id } from "../_generated/dataModel";
import type { MutationCtx, QueryCtx } from "../_generated/server";

/**
 * Fetch a project and assert the signed-in developer owns it.
 * Shared by every dashboard-facing query/mutation.
 */
export async function requireOwnedProject(
  ctx: QueryCtx | MutationCtx,
  projectId: Id<"projects">,
): Promise<Doc<"projects">> {
  const userId = await getAuthUserId(ctx);
  if (userId === null) throw new Error("Not signed in.");
  const project = await ctx.db.get(projectId);
  if (!project) throw new Error("Project not found.");
  if (project.ownerId !== userId) throw new Error("Not authorized for this project.");
  return project;
}

/** Signed-in user id or null. */
export async function currentUserId(ctx: QueryCtx | MutationCtx) {
  return await getAuthUserId(ctx);
}
