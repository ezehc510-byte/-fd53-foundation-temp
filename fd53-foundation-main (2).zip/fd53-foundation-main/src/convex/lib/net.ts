/**
 * FD53 network-layer helpers: client IP extraction, CIDR matching and the
 * WAF rule set.
 *
 * Everything in this file is pure (no Convex imports, no I/O) so it can be
 * unit-tested and reused by any runtime the gateway is later ported to.
 */

// ---------------------------------------------------------------------------
// Client IP extraction
// ---------------------------------------------------------------------------

/**
 * Resolve the client IP from proxy headers.
 *
 * Trust order matters. In production FD53 sits behind Cloudflare and/or an
 * ingress controller, so the rightmost-forwarded-header value is the one that
 * can actually be spoofed. We prefer the provider-specific headers that a
 * proxy *overwrites* (rather than appends to), and fall back to XFF only if
 * none are present.
 */
export function extractClientIp(headers: Headers): string | undefined {
  const direct =
    headers.get("cf-connecting-ip") ??
    headers.get("x-real-ip") ??
    headers.get("true-client-ip");
  if (direct) {
    const trimmed = direct.trim();
    if (trimmed) return normalizeIp(trimmed);
  }
  const forwarded = headers.get("x-forwarded-for");
  if (forwarded) {
    const first = forwarded.split(",")[0]?.trim();
    if (first) return normalizeIp(first);
  }
  return undefined;
}

/** Strip a port suffix and brackets from an address; lowercase the result. */
export function normalizeIp(value: string): string {
  let ip = value.trim().toLowerCase();
  if (ip.startsWith("[")) {
    // [::1]:443 -> ::1
    const close = ip.indexOf("]");
    if (close !== -1) ip = ip.slice(1, close);
  } else if (ip.includes(":") && ip.split(":").length === 2) {
    // 1.2.3.4:443 -> 1.2.3.4  (a single colon means host:port for IPv4)
    ip = ip.slice(0, ip.lastIndexOf(":"));
  }
  return ip;
}

/** True when the string is a syntactically valid IPv4 or IPv6 address. */
export function isValidIp(value: string): boolean {
  const ip = normalizeIp(value);
  if (!ip) return false;
  return isIpv4(ip) || isIpv6(ip);
}

export function isIpv4(value: string): boolean {
  const parts = value.split(".");
  if (parts.length !== 4) return false;
  return parts.every((part) => {
    if (!/^\d{1,3}$/.test(part)) return false;
    if (part.length > 1 && part.startsWith("0")) return false;
    const n = Number(part);
    return n >= 0 && n <= 255;
  });
}

export function isIpv6(value: string): boolean {
  if (!value.includes(":")) return false;
  if ((value.match(/::/g) ?? []).length > 1) return false;
  const doubleColonAt = value.indexOf("::");
  const head = doubleColonAt === -1 ? value : value.slice(0, doubleColonAt);
  const tail = doubleColonAt === -1 ? "" : value.slice(doubleColonAt + 2);
  const groups = [...head.split(":"), ...tail.split(":")].filter((g) => g !== "");
  if (groups.length === 0 || groups.length > 8) return false;
  return groups.every((group) => /^[0-9a-f]{1,4}$/.test(group));
}

/** Convert an IPv4 address to a 32-bit integer for range comparisons. */
export function ipv4ToInt(value: string): number | null {
  if (!isIpv4(value)) return null;
  const parts = value.split(".").map(Number);
  return (
    (((parts[0] << 24) >>> 0) +
      (parts[1] << 16) +
      (parts[2] << 8) +
      parts[3]) >>>
    0
  );
}

/** Convert an IPv6 address to a 128-bit integer expressed as 4 x 32 bits. */
export function ipv6ToWords(value: string): number[] | null {
  const ip = normalizeIp(value);
  if (!isIpv6(ip)) return null;
  const expanded = expandIpv6(ip);
  if (!expanded) return null;
  const words: number[] = [];
  for (let i = 0; i < 16; i += 4) {
    const group = parseInt(expanded.slice(i, i + 4), 16);
    words.push(group >>> 0);
  }
  return words;
}

/** Expand `::` shorthand into 8 fully written 4-digit groups. */
function expandIpv6(value: string): string | null {
  const doubleColonAt = value.indexOf("::");
  if (doubleColonAt === -1) {
    const groups = value.split(":");
    return groups.length === 8 ? groups.join("") : null;
  }
  const head = value.slice(0, doubleColonAt).split(":").filter(Boolean);
  const tail = value.slice(doubleColonAt + 2).split(":").filter(Boolean);
  const missing = 8 - head.length - tail.length;
  if (missing < 0) return null;
  const filler = Array.from({ length: missing }, () => "0").join(":");
  return [...head, filler, ...tail].join("");
}

// ---------------------------------------------------------------------------
// CIDR / allowlist matching
// ---------------------------------------------------------------------------

/**
 * True when `ip` matches a single address or a CIDR block.
 *
 * Supports IPv4 and IPv6. An unparseable rule never matches — a typo in a
 * security rule must fail closed (deny), never fail open (allow).
 */
export function ipMatchesRule(ip: string, rule: string): boolean {
  const candidate = normalizeIp(ip);
  const trimmedRule = rule.trim();
  if (!trimmedRule) return false;

  if (!trimmedRule.includes("/")) {
    return candidate === normalizeIp(trimmedRule);
  }

  const slash = trimmedRule.lastIndexOf("/");
  const base = normalizeIp(trimmedRule.slice(0, slash));
  const prefixText = trimmedRule.slice(slash + 1);
  const prefix = Number(prefixText);
  if (!Number.isInteger(prefix)) return false;

  if (isIpv4(base)) {
    if (!isIpv4(candidate)) return false;
    if (prefix < 0 || prefix > 32) return false;
    const baseInt = ipv4ToInt(base);
    const candidateInt = ipv4ToInt(candidate);
    if (baseInt === null || candidateInt === null) return false;
    if (prefix === 0) return true;
    // Mask to the prefix boundary so trailing host bits cannot widen the rule.
    const mask = (0xffffffff << (32 - prefix)) >>> 0;
    return ((baseInt & mask) >>> 0) === ((candidateInt & mask) >>> 0);
  }

  if (isIpv6(base)) {
    const baseWords = ipv6ToWords(base);
    const candidateWords = ipv6ToWords(candidate);
    if (!baseWords || !candidateWords) return false;
    if (prefix < 0 || prefix > 128) return false;
    if (prefix === 0) return true;
    for (let word = 0; word < 4; word++) {
      const bits = Math.min(32, Math.max(0, prefix - word * 32));
      if (bits === 0) continue;
      const mask = bits === 32 ? 0xffffffff : (0xffffffff << (32 - bits)) >>> 0;
      if (((baseWords[word] & mask) >>> 0) !== ((candidateWords[word] & mask) >>> 0)) {
        return false;
      }
    }
    return true;
  }

  return false;
}

/**
 * Apply a key's IP policy.
 *
 * Order is deliberate: an explicit block always beats an allow, and a non-empty
 * allowlist becomes exclusive (anything not listed is denied). An empty
 * allowlist means "no restriction".
 */
export function evaluateIpPolicy(
  ip: string | undefined,
  allowed: string[] | undefined,
  blocked: string[] | undefined,
): { allowed: boolean; reason?: string } {
  if (!ip) return { allowed: true };
  for (const rule of blocked ?? []) {
    if (ipMatchesRule(ip, rule)) {
      return { allowed: false, reason: `Client IP is blocked by rule ${rule}.` };
    }
  }
  if (allowed && allowed.length > 0) {
    const matched = allowed.some((rule) => ipMatchesRule(ip, rule));
    if (!matched) {
      return {
        allowed: false,
        reason: "This API key is restricted to a fixed set of IP addresses.",
      };
    }
  }
  return { allowed: true };
}

// ---------------------------------------------------------------------------
// Origin handling
// ---------------------------------------------------------------------------

/**
 * Resolve the CORS `Access-Control-Allow-Origin` value for a request.
 *
 * Returns `undefined` to send no CORS header at all, which is what a browser
 * treats as a blocked cross-origin request. A wildcard is only sent when the
 * caller allows it, because a wildcard plus credentials is rejected by
 * browsers and would mask a genuine origin misconfiguration.
 */
export function resolveAllowedOrigin(
  origin: string | undefined,
  keyOrigins: string[] | undefined,
  platformDefault: "*",
): { allowOrigin?: string; varyOrigin: boolean } {
  if (!origin) return { varyOrigin: true };
  if (keyOrigins && keyOrigins.length > 0) {
    const matched = keyOrigins.some((allowed) =>
      originMatches(origin, allowed),
    );
    return matched
      ? { allowOrigin: origin, varyOrigin: true }
      : { varyOrigin: true };
  }
  return platformDefault === "*"
    ? { allowOrigin: "*", varyOrigin: true }
    : { varyOrigin: true };
}

/** Exact match, or `*.example.com` wildcard matching one or more labels. */
export function originMatches(origin: string, rule: string): boolean {
  const candidate = origin.trim().toLowerCase();
  const allowed = rule.trim().toLowerCase();
  if (candidate === allowed) return true;
  if (!allowed.startsWith("*.")) return false;
  const suffix = allowed.slice(1); // ".example.com"
  if (!candidate.endsWith(suffix)) return false;
  const label = candidate.slice(0, candidate.length - suffix.length);
  return label.length > 0 && !label.includes(".");
}

// ---------------------------------------------------------------------------
// WAF rules
// ---------------------------------------------------------------------------

export type WafVerdict =
  | { action: "allow" }
  | { action: "block"; rule: string; detail: string };

/** Limits applied before a route is even matched. */
export const WAF_LIMITS = {
  maxPathLength: 2048,
  maxQueryLength: 4096,
  maxHeaderBytes: 16 * 1024,
  maxBodyBytes: 26 * 1024 * 1024, // above the 25 MB upload cap
  /** Blocked verbs that should never reach a JSON API. */
  allowedMethods: ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
} as const;

/**
 * Path traversal / injection patterns. These are checked against the raw
 * decoded path so percent-encoded traversal (`%2e%2e%2f`) is caught too.
 */
const TRAVERSAL_PATTERNS: Array<[RegExp, string]> = [
  [/\.\.[/\\]/, "parent-directory traversal"],
  [/\.\.$/, "parent-directory traversal"],
  [/%2e%2e/i, "encoded parent-directory traversal"],
  [/%2f|%5c/i, "encoded path separator"],
  [/\0/, "null byte in path"],
  [/<script/i, "script tag in path"],
  [/[;|]\s*(cat|ls|id|whoami|wget|curl)\b/i, "shell metacharacters in path"],
  [/\bunion\b.*\bselect\b/i, "sql injection pattern in path"],
  [/<\s*script|\bonerror\s*=/i, "xss pattern in path"],
];

/**
 * Evaluate the WAF rule set for an inbound request.
 *
 * Returns the first matching rule so the audit trail records *why* a request
 * was rejected. Order runs cheapest-and-most-decisive first.
 */
export function inspectRequest(request: Request): WafVerdict {
  const method = request.method.toUpperCase();
  if (!WAF_LIMITS.allowedMethods.includes(method as never)) {
    return {
      action: "block",
      rule: "method_not_allowed",
      detail: `HTTP method ${method} is not accepted by the FD53 API.`,
    };
  }

  let url: URL;
  try {
    url = new URL(request.url);
  } catch {
    return {
      action: "block",
      rule: "malformed_url",
      detail: "The request URL could not be parsed.",
    };
  }

  if (url.pathname.length > WAF_LIMITS.maxPathLength) {
    return {
      action: "block",
      rule: "path_too_long",
      detail: "Request path exceeds the 2048 character limit.",
    };
  }
  if (url.search.length > WAF_LIMITS.maxQueryLength) {
    return {
      action: "block",
      rule: "query_too_long",
      detail: "Query string exceeds the 4096 character limit.",
    };
  }

  const declaredLength = Number(request.headers.get("content-length") ?? "0");
  if (Number.isFinite(declaredLength) && declaredLength > WAF_LIMITS.maxBodyBytes) {
    return {
      action: "block",
      rule: "body_too_large",
      detail: "Request body exceeds the 25 MB platform limit.",
    };
  }

  let totalHeaderBytes = 0;
  request.headers.forEach((value, name) => {
    totalHeaderBytes += name.length + value.length;
  });
  if (totalHeaderBytes > WAF_LIMITS.maxHeaderBytes) {
    return {
      action: "block",
      rule: "headers_too_large",
      detail: "Request headers exceed 16 KB.",
    };
  }

  // Check both the raw and the decoded form so encoded traversal is caught.
  const decoded = safeDecode(url.pathname);
  for (const target of [url.pathname, decoded]) {
    for (const [pattern, label] of TRAVERSAL_PATTERNS) {
      if (pattern.test(target)) {
        return {
          action: "block",
          rule: "path_traversal",
          detail: `Blocked ${label}.`,
        };
      }
    }
  }

  return { action: "allow" };
}

function safeDecode(value: string): string {
  try {
    return decodeURIComponent(value);
  } catch {
    return value;
  }
}

// ---------------------------------------------------------------------------
// API key format
// ---------------------------------------------------------------------------

/** `fd53_live_<40 hex chars>` / `fd53_test_<40 hex chars>`. */
export const API_KEY_PATTERN = /^fd53_(live|test)_[0-9a-f]{40}$/;

export type ParsedApiKey = {
  environment: "live" | "test";
  /** The random half — never logged or stored in plaintext. */
  secret: string;
};

/**
 * Parse and shape-check an API key before it reaches the database.
 *
 * Rejecting malformed keys here means a scanner spraying garbage at
 * `X-API-Key` never reaches a query, and never counts against a real key.
 */
export function parseApiKey(raw: string): ParsedApiKey | null {
  const match = API_KEY_PATTERN.exec(raw.trim());
  if (!match) return null;
  return { environment: match[1] as "live" | "test", secret: match[2] };
}