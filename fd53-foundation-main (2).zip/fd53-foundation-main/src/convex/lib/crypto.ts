/**
 * FD53 crypto helpers.
 *
 * Everything here is pure (no Convex imports) and runs on the Web Crypto API,
 * which the default Convex runtime supports. Rules of use:
 *  - Deterministic operations (hash / sign / verify) are safe anywhere.
 *  - `randomHex` / `randomBytes` MUST only be called from actions or HTTP
 *    actions, which are allowed to be non-deterministic.
 */

const encoder = new TextEncoder();

export function toHex(bytes: Uint8Array): string {
  let out = "";
  for (const b of bytes) out += b.toString(16).padStart(2, "0");
  return out;
}

export function fromHex(hex: string): Uint8Array {
  const out = new Uint8Array(hex.length / 2);
  for (let i = 0; i < out.length; i++) {
    out[i] = parseInt(hex.slice(i * 2, i * 2 + 2), 16);
  }
  return out;
}

/** Cryptographic randomness — actions / HTTP actions only. */
export function randomBytes(length: number): Uint8Array {
  const bytes = new Uint8Array(length);
  crypto.getRandomValues(bytes);
  return bytes;
}

/** Cryptographic randomness as a hex string — actions / HTTP actions only. */
export function randomHex(length: number): string {
  return toHex(randomBytes(length));
}

export async function sha256Hex(
  input: string | Uint8Array,
): Promise<string> {
  const bytes = typeof input === "string" ? encoder.encode(input) : input;
  const digest = await crypto.subtle.digest("SHA-256", bytes as BufferSource);
  return toHex(new Uint8Array(digest));
}

async function hmacBytes(
  secret: string,
  message: string,
): Promise<Uint8Array> {
  const key = await crypto.subtle.importKey(
    "raw",
    encoder.encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"],
  );
  const sig = await crypto.subtle.sign("HMAC", key, encoder.encode(message));
  return new Uint8Array(sig);
}

/** Keyed hash used to pepper OTP codes, reset tokens and session ids. */
export async function hmacHex(
  secret: string,
  message: string,
): Promise<string> {
  return toHex(await hmacBytes(secret, message));
}

export function timingSafeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

// ---------------------------------------------------------------------------
// Password hashing — PBKDF2-SHA256
// ---------------------------------------------------------------------------

export const PBKDF2_ITERATIONS = 60_000;

/** Derive a hex password hash from a password + hex salt. */
export async function pbkdf2Hash(
  password: string,
  saltHex: string,
  iterations = PBKDF2_ITERATIONS,
): Promise<string> {
  const key = await crypto.subtle.importKey(
    "raw",
    encoder.encode(password),
    "PBKDF2",
    false,
    ["deriveBits"],
  );
  const bits = await crypto.subtle.deriveBits(
    {
      name: "PBKDF2",
      hash: "SHA-256",
      salt: fromHex(saltHex) as BufferSource,
      iterations,
    },
    key,
    256,
  );
  return toHex(new Uint8Array(bits));
}

/** Constant-time password verification. */
export async function pbkdf2Verify(
  password: string,
  saltHex: string,
  expectedHashHex: string,
  iterations = PBKDF2_ITERATIONS,
): Promise<boolean> {
  const actual = await pbkdf2Hash(password, saltHex, iterations);
  return timingSafeEqual(actual, expectedHashHex);
}

// ---------------------------------------------------------------------------
// Base64url + JWT (HS256)
// ---------------------------------------------------------------------------

function bytesToBase64(bytes: Uint8Array): string {
  let binary = "";
  for (const b of bytes) binary += String.fromCharCode(b);
  return btoa(binary);
}

export function base64UrlEncode(input: string | Uint8Array): string {
  const bytes = typeof input === "string" ? encoder.encode(input) : input;
  return bytesToBase64(bytes)
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/, "");
}

export function base64UrlDecodeToString(input: string): string {
  const padded =
    input.replace(/-/g, "+").replace(/_/g, "/") +
    "===".slice((input.length + 3) % 4);
  const binary = atob(padded);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return new TextDecoder().decode(bytes);
}

export function base64UrlDecodeBytes(input: string): Uint8Array {
  const padded =
    input.replace(/-/g, "+").replace(/_/g, "/") +
    "===".slice((input.length + 3) % 4);
  const binary = atob(padded);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

export type JwtPayload = {
  /** subject — the end user id */
  sub: string;
  /** project id */
  pid: string;
  /** session id */
  sid: string;
  /** role name */
  role: string;
  /** token version */
  v: number;
  /** issued at / expiry (epoch seconds) */
  iat: number;
  exp: number;
};

export async function signJwt(
  payload: JwtPayload,
  secret: string,
): Promise<string> {
  const header = base64UrlEncode(JSON.stringify({ alg: "HS256", typ: "JWT" }));
  const body = base64UrlEncode(JSON.stringify(payload));
  const signingInput = `${header}.${body}`;
  const sig = await hmacBytes(secret, signingInput);
  return `${signingInput}.${base64UrlEncode(sig)}`;
}

/**
 * Read the `sub` claim from an Authorization header **without verifying the
 * signature**. Used only to label a request in the dashboard's request log —
 * authorisation always goes through `verifyJwt` in `authenticateEndUser`.
 * Returns undefined when there is no bearer token or the token is malformed.
 */
export function decodeTokenSubject(authorization: string | null): string | undefined {
  if (!authorization) return undefined;
  const match = /^Bearer\s+(.+)$/i.exec(authorization.trim());
  if (!match) return undefined;
  const parts = match[1].trim().split(".");
  if (parts.length !== 3) return undefined;
  try {
    const payload = JSON.parse(base64UrlDecodeToString(parts[1])) as {
      sub?: unknown;
    };
    return typeof payload.sub === "string" && /^[A-Za-z0-9_-]{16,64}$/.test(payload.sub)
      ? payload.sub
      : undefined;
  } catch {
    return undefined;
  }
}

/** Verify signature + expiry. Returns the payload, or null when invalid. */
export async function verifyJwt(
  token: string,
  secret: string,
): Promise<JwtPayload | null> {
  const parts = token.split(".");
  if (parts.length !== 3) return null;
  const [header, body, sig] = parts;

  let decodedHeader: { alg?: string };
  let payload: JwtPayload;
  try {
    decodedHeader = JSON.parse(base64UrlDecodeToString(header));
    payload = JSON.parse(base64UrlDecodeToString(body)) as JwtPayload;
  } catch {
    return null;
  }
  if (decodedHeader.alg !== "HS256") return null;

  let expected: Uint8Array;
  let actual: Uint8Array;
  try {
    expected = await hmacBytes(secret, `${header}.${body}`);
    actual = base64UrlDecodeBytes(sig);
  } catch {
    return null;
  }
  if (!timingSafeEqual(toHex(expected), toHex(actual))) return null;
  if (typeof payload.exp !== "number" || payload.exp * 1000 < Date.now())
    return null;
  return payload;
}
