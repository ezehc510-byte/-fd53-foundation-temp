/** FD53 platform constants shared by the REST API and the dashboard. */

export const FD53_VERSION = "1.0.0";
export const FD53_NAME = "FD53";

/** Free plan limits (v1). */
export const FREE_PLAN = {
  id: "free",
  requestsPerMinute: 120,
  storageLimitBytes: 250 * 1024 * 1024, // 250 MB
  maxUploadBytes: 25 * 1024 * 1024, // 25 MB per file
  maxTablesPerProject: 50,
  maxRowsPerPage: 200,
};

/** Session / token lifetimes. */
export const TOKEN_TTL_SECONDS = 60 * 60 * 24; // 24h access token
export const SESSION_TTL_MS = 1000 * 60 * 60 * 24;
export const OTP_TTL_MS = 1000 * 60 * 10; // 10 minutes
export const RESET_TTL_MS = 1000 * 60 * 30; // 30 minutes
export const MAX_LOGIN_ATTEMPTS = 10;
export const LOCKOUT_MS = 1000 * 60 * 15; // 15 minutes
export const MAX_OTP_ATTEMPTS = 5;

/** Permissions understood by FD53's role system. */
export const KNOWN_PERMISSIONS = [
  "db:read",
  "db:write",
  "storage:read",
  "storage:write",
  "users:manage",
  "realtime:publish",
  "*",
] as const;

/** Default roles seeded into every project. */
export const DEFAULT_ROLES: Array<{
  name: string;
  description: string;
  permissions: string[];
  isDefault?: boolean;
}> = [
  {
    name: "admin",
    description: "Full control over the project's data and storage",
    permissions: ["*"],
  },
  {
    name: "editor",
    description: "Read and write data, upload and delete files",
    permissions: ["db:read", "db:write", "storage:read", "storage:write"],
  },
  {
    name: "user",
    // `db:write` allows creating/updating rows; tables with "owner" access
    // still restrict a user to their own rows.
    description: "Read and write data, manage its own files",
    permissions: ["db:read", "db:write", "storage:read", "storage:write"],
    isDefault: true,
  },
  {
    name: "viewer",
    description: "Read-only access",
    permissions: ["db:read", "storage:read"],
  },
];

/**
 * Storage buckets exposed by FD53 for app use.
 *
 * `visibility` is fixed by the bucket and enforced on every upload: files in
 * a private bucket can never be flipped to public through the REST API.
 */
export type BucketDef = {
  name: BucketName;
  visibility: "public" | "private";
  /** True when the bucket accepts image/video mime types. */
  accepts: "media" | "any";
  description: string;
};

export type BucketName = "avatars" | "post-media" | "receipts";

export const STORAGE_BUCKET_LIST: BucketDef[] = [
  {
    name: "avatars",
    visibility: "public",
    accepts: "media",
    description: "Profile pictures and header banners. Publicly readable by URL.",
  },
  {
    name: "post-media",
    visibility: "public",
    accepts: "media",
    description: "Post images and video streams. Publicly readable by URL.",
  },
  {
    name: "receipts",
    visibility: "private",
    accepts: "any",
    description:
      "Digital downloads and purchase invoices. Private: readable only by the buyer, the seller and admins.",
  },
];

export function bucketDef(name: string): BucketDef | undefined {
  return STORAGE_BUCKET_LIST.find((b) => b.name === name);
}

export function isValidBucket(name: string): name is BucketName {
  return STORAGE_BUCKET_LIST.some((b) => b.name === name);
}

/** Default bucket per file category, used when a client omits `bucket`. */
export const BUCKET_FOR_CATEGORY: Record<string, BucketName> = {
  image: "post-media",
  video: "post-media",
  audio: "post-media",
  document: "receipts",
  other: "receipts",
};

/**
 * LoopUni application-level anti-spam limits (per end user, fixed windows).
 * These sit in front of the per-API-key rate limiter so one abusive end user
 * cannot burn a shared app's whole quota.
 */
export const ANTI_SPAM_LIMITS: Record<
  string,
  { limit: number; windowMs: number }
> = {
  register: { limit: 10, windowMs: 60 * 60 * 1000 }, // per IP
  login: { limit: 20, windowMs: 15 * 60 * 1000 }, // per identifier
  post: { limit: 30, windowMs: 60 * 60 * 1000 }, // per user
  follow: { limit: 200, windowMs: 60 * 60 * 1000 }, // per user
  message: { limit: 60, windowMs: 60 * 1000 }, // per user
  checkout: { limit: 20, windowMs: 60 * 60 * 1000 }, // per user
  report: { limit: 10, windowMs: 60 * 60 * 1000 }, // per user
  product: { limit: 60, windowMs: 60 * 60 * 1000 }, // per user
};

/** Marketplace platform fee, in basis points (1000 bps = 10%). */
export const PLATFORM_FEE_BPS = 1000;

/** Guess a storage category from a mime type. */
export function fileCategory(mime: string): string {
  if (mime.startsWith("image/")) return "image";
  if (mime.startsWith("video/")) return "video";
  if (mime.startsWith("audio/")) return "audio";
  if (
    mime.startsWith("text/") ||
    mime === "application/pdf" ||
    mime.startsWith("application/vnd.") ||
    mime === "application/json" ||
    mime === "application/xml" ||
    mime.endsWith("msword") ||
    mime.endsWith("ms-excel")
  ) {
    return "document";
  }
  return "other";
}

/** Validate a table/column name (API identifiers). */
export function isValidIdentifier(name: string): boolean {
  return /^[a-z][a-z0-9_]{0,63}$/.test(name);
}

/** Validate an email shape (RFC-lite, good enough for v1). */
export function isValidEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) && email.length <= 254;
}

/** Validate E.164-ish phone numbers. */
export function isValidPhone(phone: string): boolean {
  return /^\+[1-9]\d{6,14}$/.test(phone);
}
