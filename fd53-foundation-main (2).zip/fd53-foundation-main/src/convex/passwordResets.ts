import { v } from "convex/values";
import { internalMutation, internalQuery } from "./_generated/server";

/** Store a one-shot password-reset token (hashed, never stored in plaintext). */
export const create = internalMutation({
  args: {
    projectId: v.id("projects"),
    endUserId: v.id("endUsers"),
    tokenHash: v.string(),
    expiresAt: v.number(),
  },
  handler: async (ctx, args) => {
    const id = await ctx.db.insert("passwordResets", {
      projectId: args.projectId,
      endUserId: args.endUserId,
      tokenHash: args.tokenHash,
      expiresAt: args.expiresAt,
    });
    return { status: "ok" as const, id };
  },
});

export const byToken = internalQuery({
  args: { tokenHash: v.string() },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("passwordResets")
      .withIndex("by_token", (q) => q.eq("tokenHash", args.tokenHash))
      .first();
  },
});

export const markUsed = internalMutation({
  args: { id: v.id("passwordResets") },
  handler: async (ctx, args) => {
    const reset = await ctx.db.get(args.id);
    if (!reset) return { status: "not_found" as const };
    if (reset.usedAt) return { status: "already_used" as const };
    await ctx.db.patch(args.id, { usedAt: Date.now() });
    return { status: "ok" as const };
  },
});