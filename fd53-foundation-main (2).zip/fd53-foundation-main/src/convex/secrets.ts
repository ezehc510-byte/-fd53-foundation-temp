import { v } from "convex/values";
import { internalMutation, internalQuery } from "./_generated/server";

/** Server-side secrets (JWT signing key, OTP pepper…). Never leave the backend. */
export const get = internalQuery({
  args: { key: v.string() },
  handler: async (ctx, args) => {
    const doc = await ctx.db
      .query("secrets")
      .withIndex("by_key", (q) => q.eq("key", args.key))
      .first();
    return doc?.value ?? null;
  },
});

/** Insert only if absent — returns the effective value (race-safe). */
export const ensure = internalMutation({
  args: { key: v.string(), value: v.string() },
  handler: async (ctx, args) => {
    const existing = await ctx.db
      .query("secrets")
      .withIndex("by_key", (q) => q.eq("key", args.key))
      .first();
    if (existing) return existing.value;
    await ctx.db.insert("secrets", { key: args.key, value: args.value });
    return args.value;
  },
});
