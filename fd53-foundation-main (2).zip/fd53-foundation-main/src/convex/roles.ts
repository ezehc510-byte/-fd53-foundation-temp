import { v } from "convex/values";
import { requireOwnedProject } from "./lib/authz";
import { KNOWN_PERMISSIONS } from "./lib/constants";
import { internalQuery } from "./_generated/server";
import { query } from "./_generated/server";
import { mutation } from "./_generated/server";

/** Every role for a project (REST layer, API-key auth). */
export const allForApi = internalQuery({
  args: { projectId: v.id("projects") },
  handler: async (ctx, args) =>
    await ctx.db
      .query("roles")
      .withIndex("by_project", (q) => q.eq("projectId", args.projectId))
      .collect(),
});

/** Roles + permissions for a project's end users. */
export const list = query({
  args: { projectId: v.id("projects") },
  handler: async (ctx, args) => {
    await requireOwnedProject(ctx, args.projectId);
    const roles = await ctx.db
      .query("roles")
      .withIndex("by_project", (q) => q.eq("projectId", args.projectId))
      .collect();
    return roles.sort((a, b) => Number(b.isDefault ?? 0) - Number(a.isDefault ?? 0));
  },
});

export const byName = internalQuery({
  args: { projectId: v.id("projects"), name: v.string() },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("roles")
      .withIndex("by_project_name", (q) =>
        q.eq("projectId", args.projectId).eq("name", args.name),
      )
      .first();
  },
});

function validatePermissions(permissions: string[]): string | null {
  if (permissions.length === 0) return "A role needs at least one permission.";
  if (permissions.length > 20) return "Too many permissions.";
  for (const p of permissions) {
    if (!(KNOWN_PERMISSIONS as readonly string[]).includes(p)) {
      return `Unknown permission "${p}".`;
    }
  }
  return null;
}

export const create = mutation({
  args: {
    projectId: v.id("projects"),
    name: v.string(),
    description: v.optional(v.string()),
    permissions: v.array(v.string()),
  },
  handler: async (ctx, args) => {
    await requireOwnedProject(ctx, args.projectId);
    const name = args.name.trim().toLowerCase();
    if (!/^[a-z][a-z0-9_]{1,31}$/.test(name)) {
      return {
        status: "invalid" as const,
        message: "Role names are lowercase identifiers (a–z, 0–9, _).",
      };
    }
    const permError = validatePermissions(args.permissions);
    if (permError) return { status: "invalid" as const, message: permError };

    const existing = await ctx.db
      .query("roles")
      .withIndex("by_project_name", (q) =>
        q.eq("projectId", args.projectId).eq("name", name),
      )
      .first();
    if (existing) {
      return { status: "exists" as const, message: `Role "${name}" already exists.` };
    }

    await ctx.db.insert("roles", {
      projectId: args.projectId,
      name,
      description: args.description?.trim() || undefined,
      permissions: [...new Set(args.permissions)],
    });
    return { status: "created" as const };
  },
});

export const update = mutation({
  args: {
    projectId: v.id("projects"),
    roleId: v.id("roles"),
    description: v.optional(v.string()),
    permissions: v.optional(v.array(v.string())),
  },
  handler: async (ctx, args) => {
    await requireOwnedProject(ctx, args.projectId);
    const role = await ctx.db.get(args.roleId);
    if (!role || role.projectId !== args.projectId) {
      return { status: "not_found" as const };
    }
    if (args.permissions !== undefined) {
      const permError = validatePermissions(args.permissions);
      if (permError) return { status: "invalid" as const, message: permError };
    }
    await ctx.db.patch(args.roleId, {
      description: args.description?.trim() || role.description,
      permissions:
        args.permissions !== undefined
          ? [...new Set(args.permissions)]
          : role.permissions,
    });
    return { status: "ok" as const };
  },
});

export const remove = mutation({
  args: { projectId: v.id("projects"), roleId: v.id("roles") },
  handler: async (ctx, args) => {
    await requireOwnedProject(ctx, args.projectId);
    const role = await ctx.db.get(args.roleId);
    if (!role || role.projectId !== args.projectId) {
      return { status: "not_found" as const };
    }
    if (role.isDefault) {
      return {
        status: "invalid" as const,
        message: "The default role can't be deleted.",
      };
    }
    const inUse = await ctx.db
      .query("endUsers")
      .withIndex("by_project", (q) => q.eq("projectId", args.projectId))
      .collect();
    if (inUse.some((u) => u.role === role.name)) {
      return {
        status: "in_use" as const,
        message: `Reassign the ${inUse.filter((u) => u.role === role.name).length} user(s) on "${role.name}" first.`,
      };
    }
    await ctx.db.delete(args.roleId);
    return { status: "deleted" as const };
  },
});
