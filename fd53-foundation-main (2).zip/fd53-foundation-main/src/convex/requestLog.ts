/**
 * Per-request logging.
 *
 * Every authenticated `/v1` call records one row here after it completes. The
 * Usage dashboard reads these to answer "which routes is my app hitting, how
 * slow are they, and which ones error?" — `usageDaily` gives the aggregates,
 * this gives the per-request detail behind them.
 */
import { v } from "convex/values";
import { requireOwnedProject } from "./lib/authz";
import type { Id } from "./_generated/dataModel";
import {
  internalMutation,
  internalQuery,
  query,
  type MutationCtx,
} from "./_generated/server";

/** Keep the newest N rows per project; the table is a rolling window. */
const MAX_ROWS_PER_PROJECT = 500;

/** Drop the oldest rows so the log cannot grow without bound. */
async function prune(ctx: MutationCtx, projectId: Id<"projects">): Promise<void> {
  const rows = await ctx.db
    .query("requestLogs")
    .withIndex("by_project", (q) => q.eq("projectId", projectId))
    .order("desc")
    .take(MAX_ROWS_PER_PROJECT + 1);
  // `rows` is newest-first; anything past the cap is the oldest.
  for (let i = MAX_ROWS_PER_PROJECT; i < rows.length; i++) {
    await ctx.db.delete(rows[i]._id);
  }
}

export const record = internalMutation({
  args: {
    projectId: v.id("projects"),
    apiKeyId: v.optional(v.id("apiKeys")),
    method: v.string(),
    path: v.string(),
    route: v.string(),
    category: v.union(
      v.literal("auth"),
      v.literal("database"),
      v.literal("storage"),
      v.literal("realtime"),
      v.literal("social"),
      v.literal("marketplace"),
      v.literal("system"),
    ),
    status: v.number(),
    durationMs: v.number(),
    endUserId: v.optional(v.id("endUsers")),
    requestId: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    await ctx.db.insert("requestLogs", {
      projectId: args.projectId,
      apiKeyId: args.apiKeyId,
      method: args.method,
      path: args.path.slice(0, 300),
      route: args.route,
      category: args.category,
      status: args.status,
      durationMs: args.durationMs,
      endUserId: args.endUserId,
      requestId: args.requestId,
    });
    await prune(ctx, args.projectId);
    return { status: "logged" as const };
  },
});

export const recent = query({
  args: { projectId: v.id("projects"), limit: v.optional(v.number()) },
  handler: async (ctx, args) => {
    await requireOwnedProject(ctx, args.projectId);
    const limit = Math.min(Math.max(1, args.limit ?? 50), 200);
    const rows = await ctx.db
      .query("requestLogs")
      .withIndex("by_project", (q) => q.eq("projectId", args.projectId))
      .order("desc")
      .take(limit);

    const byRoute = new Map<string, { count: number; errors: number; totalMs: number }>();
    for (const row of rows) {
      const entry = byRoute.get(row.route) ?? { count: 0, errors: 0, totalMs: 0 };
      entry.count += 1;
      entry.totalMs += row.durationMs;
      if (row.status >= 400) entry.errors += 1;
      byRoute.set(row.route, entry);
    }

    return {
      total: rows.length,
      requests: rows.map((row) => ({
        id: row._id,
        method: row.method,
        path: row.path,
        route: row.route,
        category: row.category,
        status: row.status,
        durationMs: row.durationMs,
        requestId: row.requestId ?? null,
        at: row._creationTime,
      })),
      routes: [...byRoute.entries()]
        .map(([route, stats]) => ({
          route,
          count: stats.count,
          errors: stats.errors,
          avgMs: Math.round(stats.totalMs / stats.count),
        }))
        .sort((a, b) => b.count - a.count),
    };
  },
});

export const recentForApi = internalQuery({
  args: { projectId: v.id("projects"), limit: v.optional(v.number()) },
  handler: async (ctx, args) => {
    const limit = Math.min(Math.max(1, args.limit ?? 25), 100);
    return await ctx.db
      .query("requestLogs")
      .withIndex("by_project", (q) => q.eq("projectId", args.projectId))
      .order("desc")
      .take(limit);
  },
});