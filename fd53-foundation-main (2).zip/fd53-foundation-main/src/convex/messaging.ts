/**
 * LoopUni direct/group messaging.
 *
 * Conversations are addressed by a stable client-visible `roomId` so an
 * external client (FlutterFlow, native) can poll a room without first
 * resolving a Convex id. Direct rooms use `dm:<lowerUserA>:<lowerUserB>`,
 * which is deterministic and therefore idempotent.
 */
import { v } from "convex/values";
import { requireOwnedProject } from "./lib/authz";
import type { Id } from "./_generated/dataModel";
import { internalMutation, internalQuery, query } from "./_generated/server";

const MAX_MESSAGE_TEXT = 4000;
const MAX_PARTICIPANTS = 100;

/** Deterministic room id for a 1:1 conversation, order-independent. */
export function directRoomId(a: string, b: string): string {
  return `dm:${[a, b].sort().join(":")}`;
}

/** Find or create a conversation for a set of participants. */
export const ensureConversation = internalMutation({
  args: {
    projectId: v.id("projects"),
    roomId: v.string(),
    type: v.union(v.literal("direct"), v.literal("group")),
    title: v.optional(v.string()),
    participantIds: v.array(v.id("users")),
    createdBy: v.id("users"),
  },
  handler: async (ctx, args) => {
    if (args.participantIds.length < 1) {
      return {
        status: "invalid" as const,
        message: "A conversation needs at least one participant.",
      };
    }
    if (args.participantIds.length > MAX_PARTICIPANTS) {
      return {
        status: "invalid" as const,
        message: `A conversation holds at most ${MAX_PARTICIPANTS} participants.`,
      };
    }
    if (!args.participantIds.includes(args.createdBy)) {
      return {
        status: "invalid" as const,
        message: "createdBy must be one of the participants.",
      };
    }
    if (args.roomId.length > 200) {
      return {
        status: "invalid" as const,
        message: '"roomId" must be at most 200 characters.',
      };
    }

    const existing = await ctx.db
      .query("conversations")
      .withIndex("by_project_room", (q) =>
        q.eq("projectId", args.projectId).eq("roomId", args.roomId),
      )
      .first();
    if (existing) {
      return { status: "existing" as const, conversationId: existing._id };
    }

    const conversationId = await ctx.db.insert("conversations", {
      projectId: args.projectId,
      roomId: args.roomId,
      type: args.type,
      title: args.title?.slice(0, 140),
      participantIds: args.participantIds,
    });
    return { status: "created" as const, conversationId };
  },
});

export const conversationByRoom = internalQuery({
  args: { projectId: v.id("projects"), roomId: v.string() },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("conversations")
      .withIndex("by_project_room", (q) =>
        q.eq("projectId", args.projectId).eq("roomId", args.roomId),
      )
      .first();
  },
});

export const sendMessage = internalMutation({
  args: {
    projectId: v.id("projects"),
    conversationId: v.id("conversations"),
    senderId: v.id("users"),
    text: v.optional(v.string()),
    kind: v.optional(v.union(v.literal("text"), v.literal("image"), v.literal("system"))),
    // NOTE: v.id(...) args are validated by Convex *before* the handler runs,
    // so a fabricated id throws before we can return a clean 4xx. The REST
    // layer (rest/social.ts sendMessage) validates mediaIds before calling this.
    mediaIds: v.optional(v.array(v.id("media"))),
  },
  handler: async (ctx, args) => {
    const conversation = await ctx.db.get(args.conversationId);
    if (!conversation || conversation.projectId !== args.projectId) {
      return { status: "not_found" as const, message: "No such conversation." };
    }
    if (!conversation.participantIds.includes(args.senderId)) {
      return {
        status: "forbidden" as const,
        message: "You are not in this conversation.",
      };
    }
    const text = args.text?.trim();
    if (!text && (args.mediaIds?.length ?? 0) === 0) {
      return {
        status: "invalid" as const,
        message: 'A message needs "text" or at least one media id.',
      };
    }
    if (text && text.length > MAX_MESSAGE_TEXT) {
      return {
        status: "invalid" as const,
        message: `Messages are limited to ${MAX_MESSAGE_TEXT} characters.`,
      };
    }

    const now = Date.now();
    const messageId = await ctx.db.insert("messages", {
      projectId: args.projectId,
      conversationId: args.conversationId,
      roomId: conversation.roomId,
      senderId: args.senderId,
      text,
      kind: args.kind ?? "text",
      mediaIds: args.mediaIds,
    });
    await ctx.db.patch(args.conversationId, {
      lastMessageAt: now,
      lastMessagePreview: (text ?? "Attachment").slice(0, 140),
    });

    return { status: "sent" as const, messageId, sentAt: now };
  },
});

export const listMessages = internalQuery({
  args: {
    projectId: v.id("projects"),
    conversationId: v.id("conversations"),
    viewerId: v.optional(v.id("users")),
    limit: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const conversation = await ctx.db.get(args.conversationId);
    if (!conversation || conversation.projectId !== args.projectId) return null;
    if (
      args.viewerId &&
      !conversation.participantIds.includes(args.viewerId)
    ) {
      return null;
    }
    const limit = Math.min(Math.max(1, args.limit ?? 30), 100);
    const rows = await ctx.db
      .query("messages")
      .withIndex("by_conversation", (q) =>
        q
          .eq("projectId", args.projectId)
          .eq("conversationId", args.conversationId),
      )
      .order("desc")
      .take(limit);
    return rows.reverse();
  },
});

export const conversationsForUser = internalQuery({
  args: { projectId: v.id("projects"), userId: v.id("users") },
  handler: async (ctx, args) => {
    const rows = await ctx.db
      .query("conversations")
      .withIndex("by_project", (q) => q.eq("projectId", args.projectId))
      .collect();
    return rows
      .filter((c) => c.participantIds.includes(args.userId))
      .sort((a, b) => (b.lastMessageAt ?? 0) - (a.lastMessageAt ?? 0));
  },
});

// ---------------------------------------------------------------------------
// Dashboard
// ---------------------------------------------------------------------------

export const messagingStats = query({
  args: { projectId: v.id("projects") },
  handler: async (ctx, args) => {
    await requireOwnedProject(ctx, args.projectId);
    const conversations = await ctx.db
      .query("conversations")
      .withIndex("by_project", (q) => q.eq("projectId", args.projectId))
      .collect();
    const messages = await ctx.db
      .query("messages")
      .withIndex("by_conversation", (q) => q.eq("projectId", args.projectId))
      .collect();
    return {
      conversations: conversations.length,
      messages: messages.length,
      lastMessageAt: messages.reduce(
        (max, m) => Math.max(max, m._creationTime),
        0,
      ),
    };
  },
});