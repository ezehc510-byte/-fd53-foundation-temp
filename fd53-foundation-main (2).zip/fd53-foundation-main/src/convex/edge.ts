/**
 * FD53 edge protection — pre-authentication flood control.
 *
 * This is the outermost defence in the request pipeline and, crucially, it
 * runs *before* the API key is resolved. Three reasons:
 *
 *  1. A flood from an unauthenticated client never reaches the database.
 *  2. One noisy IP cannot burn a legitimate project's request quota, because
 *     this bucket is keyed by the hashed client IP, not by the API key.
 *  3. Repeated authentication failures from one source can be banned outright
 *     (the `auth_fail` scope), which a per-key bucket could never do.
 *
 * Windows are fixed rather than sliding so a banned caller always receives a
 * concrete `Retry-After`. Stored rows are pruned aggressively: this table must
 * stay small even under sustained attack.
 */
import { v } from "convex/values";
import {
  internalMutation,
  query,
  type MutationCtx,
} from "./_generated/server";

/**
 * Edge limits. Deliberately generous for normal traffic and tight enough that
 * a single source cannot saturate a project's quota.
 *
 * `GLOBAL_LIMITS` applies to every authenticated request regardless of key;
 * the per-scope limits apply only to the listed operation.
 */
export const EDGE_LIMITS = {
  /** Requests per minute from one IP across the whole API. */
  ip: { limit: 600, windowMs: 60_000 },
  /** Requests per minute from one IP to a single route family. */
  route: { limit: 300, windowMs: 60_000 },
  /** Failed authentications before the source is banned. */
  auth_fail: { limit: 20, windowMs: 15 * 60_000 },
  /** CORS preflights are cheap but must not be free. */
  preflight: { limit: 60, windowMs: 60_000 },
} as const;

export type EdgeScope = keyof typeof EDGE_LIMITS;

export type EdgeResult = {
  allowed: boolean;
  limit: number;
  count: number;
  resetAt: number;
  retryAfterSeconds: number;
};

type HitArgs = {
  scope: string;
  limit: number;
  windowMs: number;
  /** When true a single hit over the limit bans the caller for the window. */
  banOnExceed?: boolean;
};

/**
 * Count one call against `scope`, pruning every window older than the previous
 * one. Keeping only the last two windows bounds the table at 2 rows per scope
 * no matter how long the system runs.
 */
async function doHit(
  ctx: MutationCtx,
  args: HitArgs,
): Promise<EdgeResult> {
  const now = Date.now();
  const windowStart = Math.floor(now / args.windowMs) * args.windowMs;
  const resetAt = windowStart + args.windowMs;
  const retryAfterSeconds = Math.max(1, Math.ceil((resetAt - now) / 1000));

  const rows = await ctx.db
    .query("edgeBuckets")
    .withIndex("by_scope_window", (q) =>
      q.eq("scope", args.scope).gte("windowStart", windowStart - args.windowMs),
    )
    .collect();

  for (const row of rows) {
    if (row.windowStart < windowStart - args.windowMs) {
      await ctx.db.delete(row._id);
    }
  }

  const current = rows.find((row) => row.windowStart === windowStart);
  const count = (current?.count ?? 0) + 1;

  // A ban issued earlier in this window holds until the window rolls over.
  const banned = (current?.blockedUntil ?? 0) > now;
  const overLimit = count > args.limit;
  const blocked = args.banOnExceed ? banned || overLimit : banned;

  if (current) {
    await ctx.db.patch(current._id, {
      count,
      blockedUntil: blocked ? resetAt : undefined,
    });
  } else {
    await ctx.db.insert("edgeBuckets", {
      scope: args.scope,
      windowStart,
      count,
      blockedUntil: blocked ? resetAt : undefined,
    });
  }

  return {
    allowed: !blocked,
    limit: args.limit,
    count,
    resetAt,
    retryAfterSeconds,
  };
}

/** Shared by the gateway. Bans the caller for the rest of the window. */
export const hit = internalMutation({
  args: {
    scope: v.string(),
    limit: v.number(),
    windowMs: v.number(),
    banOnExceed: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => await doHit(ctx, args),
});

/** Per-IP edge limiter with the platform default IP limit. */
export const hitIp = internalMutation({
  args: { scope: v.string() },
  handler: async (ctx, args) =>
    await doHit(ctx, {
      scope: args.scope,
      limit: EDGE_LIMITS.ip.limit,
      windowMs: EDGE_LIMITS.ip.windowMs,
    }),
});

/**
 * Authentication-failure limiter. This is the one scope that bans rather than
 * merely throttles, because a source producing invalid keys is not a customer.
 */
export const hitAuthFailure = internalMutation({
  args: { scope: v.string() },
  handler: async (ctx, args) =>
    await doHit(ctx, {
      scope: args.scope,
      limit: EDGE_LIMITS.auth_fail.limit,
      windowMs: EDGE_LIMITS.auth_fail.windowMs,
      banOnExceed: true,
    }),
});

/**
 * Dashboard view of currently banned sources.
 *
 * Scopes are hashed (see `hashIp` in the gateway), so this exposes stable
 * pseudonymous identifiers rather than raw client addresses.
 */
export const bannedSources = query({
  args: {},
  handler: async (ctx) => {
    const now = Date.now();
    // Scans a bounded, self-pruning set (max 2 rows per active scope), so a
    // plain collect is cheap here and avoids an unbounded range index scan.
    const rows = await ctx.db.query("edgeBuckets").collect();
    return rows
      .filter((row) => (row.blockedUntil ?? 0) > now)
      .map((row) => ({
        scope: row.scope,
        count: row.count,
        blockedUntil: row.blockedUntil ?? null,
      }))
      .sort((a, b) => b.count - a.count);
  },
});