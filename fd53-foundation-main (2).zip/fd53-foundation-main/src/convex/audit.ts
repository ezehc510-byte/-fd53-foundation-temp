/**
 * FD53 security audit trail.
 *
 * Records security-relevant events — key lifecycle, authentication failures,
 * IP blocks, WAF trips, configuration changes — into an append-only
 * `auditLogs` table. Deliberately *not* pruned: this is the evidence trail a
 * developer needs when asking "who called this endpoint at 03:00 with a key we
 * revoked?".
 *
 * Two rules govern everything here:
 *  1. Raw client IPs are never stored. The gateway hashes them first.
 *  2. An audit failure must never break the request that triggered it, so
 *     every write path is wrapped by the caller in a try/catch.
 */
import { v } from "convex/values";
import type { Id } from "./_generated/dataModel";
import {
  internalMutation,
  query,
  type MutationCtx,
} from "./_generated/server";

export const AUDIT_EVENTS = [
  // API key lifecycle
  "key.created",
  "key.revoked",
  "key.updated",
  "key.expired",
  // Authentication
  "auth.failed",
  "auth.blocked",
  "auth.token_invalid",
  // Network / edge
  "ip.blocked",
  "rate_limited",
  "waf.blocked",
  "cors.blocked",
  // Authorization
  "scope.denied",
  "table.forbidden",
  "storage.forbidden",
  // Data
  "storage.quota_exceeded",
  "row.limit_exceeded",
  // Configuration
  "project.updated",
  "role.updated",
  "secret.read",
] as const;

export type AuditEvent = (typeof AUDIT_EVENTS)[number];
export type AuditOutcome = "success" | "failure" | "blocked";

/**
 * Record one audit event.
 *
 * Cap the `detail` field so a hostile caller cannot inflate the table by
 * echoing a megabyte back at us inside an error message.
 */
export const record = internalMutation({
  args: {
    event: v.string(),
    outcome: v.union(
      v.literal("success"),
      v.literal("failure"),
      v.literal("blocked"),
    ),
    projectId: v.optional(v.id("projects")),
    apiKeyId: v.optional(v.id("apiKeys")),
    method: v.optional(v.string()),
    path: v.optional(v.string()),
    ipHash: v.optional(v.string()),
    userAgent: v.optional(v.string()),
    requestId: v.optional(v.string()),
    detail: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const detail = args.detail?.slice(0, 500);
    return await ctx.db.insert("auditLogs", { ...args, detail });
  },
});

/** Non-throwing write used by the gateway's hot path and by mutations. */
export async function tryRecord(
  ctx: MutationCtx,
  args: {
    event: AuditEvent;
    outcome: AuditOutcome;
    projectId?: Id<"projects">;
    apiKeyId?: Id<"apiKeys">;
    method?: string;
    path?: string;
    ipHash?: string;
    userAgent?: string;
    requestId?: string;
    detail?: string;
  },
): Promise<void> {
  try {
    await ctx.db.insert("auditLogs", {
      event: args.event,
      outcome: args.outcome,
      projectId: args.projectId,
      apiKeyId: args.apiKeyId,
      method: args.method,
      path: args.path,
      ipHash: args.ipHash,
      userAgent: args.userAgent,
      requestId: args.requestId,
      detail: args.detail?.slice(0, 500),
    });
  } catch {
    // The audit trail must never turn a good response into a 500.
  }
}

/**
 * Recent audit entries for a project, newest first. Backs the dashboard's
 * Security tab.
 */
export const recentForProject = query({
  args: {
    projectId: v.optional(v.id("projects")),
    limit: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const limit = Math.min(200, Math.max(1, args.limit ?? 100));
    const rows = args.projectId
      ? await ctx.db
          .query("auditLogs")
          .withIndex("by_project", (q) => q.eq("projectId", args.projectId))
          .order("desc")
          .take(limit)
      : await ctx.db.query("auditLogs").order("desc").take(limit);
    return rows.map((row) => ({
      id: row._id,
      event: row.event,
      outcome: row.outcome,
      projectId: row.projectId ?? null,
      apiKeyId: row.apiKeyId ?? null,
      method: row.method ?? null,
      path: row.path ?? null,
      ipHash: row.ipHash ?? null,
      requestId: row.requestId ?? null,
      detail: row.detail ?? null,
      at: row._creationTime,
    }));
  },
});

/** Aggregate counts per event, for the security dashboard's summary tiles. */
export const summary = query({
  args: { projectId: v.optional(v.id("projects")) },
  handler: async (ctx, args) => {
    const rows = args.projectId
      ? await ctx.db
          .query("auditLogs")
          .withIndex("by_project", (q) => q.eq("projectId", args.projectId))
          .collect()
      : await ctx.db.query("auditLogs").collect();
    const byEvent: Record<string, number> = {};
    const byOutcome: Record<string, number> = {};
    for (const row of rows) {
      byEvent[row.event] = (byEvent[row.event] ?? 0) + 1;
      byOutcome[row.outcome] = (byOutcome[row.outcome] ?? 0) + 1;
    }
    return {
      total: rows.length,
      byEvent,
      byOutcome,
      since: rows.length
        ? rows.reduce(
            (min, row) => Math.min(min, row._creationTime),
            Number.POSITIVE_INFINITY,
          )
        : null,
    };
  },
});