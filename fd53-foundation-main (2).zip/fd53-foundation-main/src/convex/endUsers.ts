import { v } from "convex/values";
import { requireOwnedProject } from "./lib/authz";
import { LOCKOUT_MS, MAX_LOGIN_ATTEMPTS } from "./lib/constants";
import type { Doc, Id } from "./_generated/dataModel";
import {
  internalMutation,
  internalQuery,
  mutation,
  query,
} from "./_generated/server";

/** Public shape of an end user — never includes password material. */
export function publicUser(user: Doc<"endUsers">) {
  return {
    id: user._id,
    email: user.email ?? null,
    phone: user.phone ?? null,
    name: user.name ?? null,
    role: user.role,
    status: user.status,
    data: user.data ?? null,
    createdAt: user._creationTime,
    lastLoginAt: user.lastLoginAt ?? null,
  };
}

// ---------------------------------------------------------------------------
// Internal functions — REST auth endpoints
// ---------------------------------------------------------------------------

export const byId = internalQuery({
  args: { projectId: v.id("projects"), id: v.id("endUsers") },
  handler: async (ctx, args) => {
    const user = await ctx.db.get(args.id);
    if (!user || user.projectId !== args.projectId) return null;
    return user;
  },
});

export const byEmail = internalQuery({
  args: { projectId: v.id("projects"), email: v.string() },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("endUsers")
      .withIndex("by_project_email", (q) =>
        q.eq("projectId", args.projectId).eq("email", args.email),
      )
      .first();
  },
});

export const byPhone = internalQuery({
  args: { projectId: v.id("projects"), phone: v.string() },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("endUsers")
      .withIndex("by_project_phone", (q) =>
        q.eq("projectId", args.projectId).eq("phone", args.phone),
      )
      .first();
  },
});

export const create = internalMutation({
  args: {
    projectId: v.id("projects"),
    email: v.optional(v.string()),
    phone: v.optional(v.string()),
    name: v.optional(v.string()),
    passwordHash: v.optional(v.string()),
    salt: v.optional(v.string()),
    role: v.string(),
    data: v.optional(v.any()),
  },
  handler: async (ctx, args) => {
    if (args.email) {
      const existing = await ctx.db
        .query("endUsers")
        .withIndex("by_project_email", (q) =>
          q.eq("projectId", args.projectId).eq("email", args.email!),
        )
        .first();
      if (existing) return { status: "email_taken" as const };
    }
    if (args.phone) {
      const existing = await ctx.db
        .query("endUsers")
        .withIndex("by_project_phone", (q) =>
          q.eq("projectId", args.projectId).eq("phone", args.phone!),
        )
        .first();
      if (existing) return { status: "phone_taken" as const };
    }

    const id = await ctx.db.insert("endUsers", {
      projectId: args.projectId,
      email: args.email,
      phone: args.phone,
      name: args.name,
      passwordHash: args.passwordHash,
      salt: args.salt,
      role: args.role,
      status: "active",
      failedAttempts: 0,
      tokenVersion: 1,
      data: args.data,
    });
    return { status: "created" as const, id };
  },
});

/** Phone OTP sign-in: create the user on first successful verification. */
export const ensureByPhone = internalMutation({
  args: { projectId: v.id("projects"), phone: v.string(), role: v.string() },
  handler: async (ctx, args) => {
    const existing = await ctx.db
      .query("endUsers")
      .withIndex("by_project_phone", (q) =>
        q.eq("projectId", args.projectId).eq("phone", args.phone),
      )
      .first();
    if (existing) return { status: "ok" as const, id: existing._id };
    const id = await ctx.db.insert("endUsers", {
      projectId: args.projectId,
      phone: args.phone,
      role: args.role,
      status: "active",
      failedAttempts: 0,
      tokenVersion: 1,
    });
    return { status: "created" as const, id };
  },
});

export const loginSucceeded = internalMutation({
  args: { projectId: v.id("projects"), id: v.id("endUsers") },
  handler: async (ctx, args) => {
    const user = await ctx.db.get(args.id);
    if (!user || user.projectId !== args.projectId) {
      return { status: "not_found" as const };
    }
    await ctx.db.patch(args.id, {
      lastLoginAt: Date.now(),
      failedAttempts: 0,
      lockedUntil: undefined,
    });
    return { status: "ok" as const };
  },
});

/** Increments the failed-attempt counter and locks the account on abuse. */
export const loginFailed = internalMutation({
  args: { projectId: v.id("projects"), id: v.id("endUsers") },
  handler: async (ctx, args) => {
    const user = await ctx.db.get(args.id);
    if (!user || user.projectId !== args.projectId) {
      return { status: "not_found" as const, failedAttempts: 0, lockedUntil: null };
    }
    const failedAttempts = user.failedAttempts + 1;
    const shouldLock = failedAttempts >= MAX_LOGIN_ATTEMPTS;
    const lockedUntil = shouldLock ? Date.now() + LOCKOUT_MS : undefined;
    await ctx.db.patch(args.id, {
      failedAttempts: shouldLock ? 0 : failedAttempts,
      lockedUntil: lockedUntil ?? undefined,
    });
    return {
      status: "ok" as const,
      failedAttempts: shouldLock ? MAX_LOGIN_ATTEMPTS : failedAttempts,
      lockedUntil: lockedUntil ?? null,
      remaining: Math.max(0, MAX_LOGIN_ATTEMPTS - failedAttempts),
    };
  },
});

export const setPassword = internalMutation({
  args: {
    projectId: v.id("projects"),
    id: v.id("endUsers"),
    salt: v.string(),
    passwordHash: v.string(),
    /** Password recovery also invalidates every issued token. */
    invalidateTokens: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    const user = await ctx.db.get(args.id);
    if (!user || user.projectId !== args.projectId) {
      return { status: "not_found" as const };
    }
    await ctx.db.patch(args.id, {
      salt: args.salt,
      passwordHash: args.passwordHash,
      failedAttempts: 0,
      lockedUntil: undefined,
      tokenVersion: args.invalidateTokens ? user.tokenVersion + 1 : user.tokenVersion,
    });
    return { status: "ok" as const };
  },
});

// ---------------------------------------------------------------------------
// Dashboard functions (owner checked)
// ---------------------------------------------------------------------------

/** End users of a project — sanitised, newest first. */
export const list = query({
  args: {
    projectId: v.id("projects"),
    search: v.optional(v.string()),
    limit: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    await requireOwnedProject(ctx, args.projectId);
    let users = await ctx.db
      .query("endUsers")
      .withIndex("by_project", (q) => q.eq("projectId", args.projectId))
      .collect();

    const search = args.search?.trim().toLowerCase();
    if (search) {
      users = users.filter((u) =>
        [u.email, u.phone, u.name, u.role]
          .filter((v): v is string => typeof v === "string")
          .some((v) => v.toLowerCase().includes(search)),
      );
    }

    users.sort((a, b) => b._creationTime - a._creationTime);
    const limit = Math.min(Math.max(1, args.limit ?? 100), 200);
    return {
      total: users.length,
      users: users.slice(0, limit).map((u) => ({
        ...publicUser(u),
        hasPassword: Boolean(u.passwordHash),
        failedAttempts: u.failedAttempts,
        lockedUntil: u.lockedUntil ?? null,
      })),
    };
  },
});

export const setRole = mutation({
  args: {
    projectId: v.id("projects"),
    userId: v.id("endUsers"),
    role: v.string(),
  },
  handler: async (ctx, args) => {
    await requireOwnedProject(ctx, args.projectId);
    const role = await ctx.db
      .query("roles")
      .withIndex("by_project_name", (q) =>
        q.eq("projectId", args.projectId).eq("name", args.role),
      )
      .first();
    if (!role) {
      return { status: "invalid" as const, message: `Unknown role "${args.role}".` };
    }
    const user = await ctx.db.get(args.userId);
    if (!user || user.projectId !== args.projectId) {
      return { status: "not_found" as const };
    }
    await ctx.db.patch(args.userId, { role: role.name });
    return { status: "ok" as const };
  },
});

export const setStatus = mutation({
  args: {
    projectId: v.id("projects"),
    userId: v.id("endUsers"),
    status: v.union(v.literal("active"), v.literal("banned")),
  },
  handler: async (ctx, args) => {
    await requireOwnedProject(ctx, args.projectId);
    const user = await ctx.db.get(args.userId);
    if (!user || user.projectId !== args.projectId) {
      return { status: "not_found" as const };
    }
    await ctx.db.patch(args.userId, {
      status: args.status,
      tokenVersion: args.status === "banned" ? user.tokenVersion + 1 : user.tokenVersion,
    });
    if (args.status === "banned") {
      const sessions = await ctx.db
        .query("sessions")
        .withIndex("by_user", (q) =>
          q.eq("projectId", args.projectId).eq("endUserId", args.userId),
        )
        .collect();
      for (const session of sessions) await ctx.db.delete(session._id);
    }
    return { status: "ok" as const };
  },
});

export const remove = mutation({
  args: { projectId: v.id("projects"), userId: v.id("endUsers") },
  handler: async (ctx, args) => {
    await requireOwnedProject(ctx, args.projectId);
    const user = await ctx.db.get(args.userId);
    if (!user || user.projectId !== args.projectId) {
      return { status: "not_found" as const };
    }
    const sessions = await ctx.db
      .query("sessions")
      .withIndex("by_user", (q) =>
        q.eq("projectId", args.projectId).eq("endUserId", args.userId),
      )
      .collect();
    for (const session of sessions) await ctx.db.delete(session._id);

    const resets = await ctx.db
      .query("passwordResets")
      .withIndex("by_project", (q) => q.eq("projectId", args.projectId))
      .collect();
    for (const reset of resets) {
      if (reset.endUserId === args.userId) await ctx.db.delete(reset._id);
    }

    await ctx.db.delete(args.userId);
    return { status: "deleted" as const };
  },
});

/** Active session count per end user (for the dashboard). */
export const sessionCounts = query({
  args: { projectId: v.id("projects") },
  handler: async (ctx, args) => {
    await requireOwnedProject(ctx, args.projectId);
    const sessions = await ctx.db
      .query("sessions")
      .withIndex("by_sid", (q) => q.eq("projectId", args.projectId))
      .collect();
    const now = Date.now();
    const counts: Record<string, number> = {};
    for (const session of sessions) {
      if (session.revokedAt || session.expiresAt < now) continue;
      counts[session.endUserId] = (counts[session.endUserId] ?? 0) + 1;
    }
    return counts;
  },
});

export type EndUserRow = Doc<"endUsers"> & { _id: Id<"endUsers"> };