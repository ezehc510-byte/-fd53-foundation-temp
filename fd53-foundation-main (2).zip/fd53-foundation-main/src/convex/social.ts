/**
 * LoopUni social graph: posts, media and follows.
 *
 * Posts own their text and counters; attachments live in `media` so a post can
 * carry up to ten images/video without a wide row. Follow edges are stored
 * once (directed) and mirrored as denormalised counters on `profiles` because
 * a profile card reads them on every screen.
 */
import { v } from "convex/values";
import { requireOwnedProject } from "./lib/authz";
import type { Doc, Id, TableNames } from "./_generated/dataModel";
import {
  internalMutation,
  internalQuery,
  query,
  type MutationCtx,
} from "./_generated/server";

const MAX_POST_TEXT = 2200;
const MAX_MEDIA_PER_POST = 10;
const MAX_HASHTAGS = 30;

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/** Reduce a width/height pair to a compact ratio string, e.g. 1080x1920 → "9:16". */
export function aspectRatioFor(
  width: number | undefined,
  height: number | undefined,
): string | undefined {
  if (!width || !height || width <= 0 || height <= 0) return undefined;
  const gcd = (a: number, b: number): number => (b === 0 ? a : gcd(b, a % b));
  const divisor = gcd(Math.round(width), Math.round(height));
  return `${Math.round(width) / divisor}:${Math.round(height) / divisor}`;
}

function extractHashtags(text: string): string[] {
  const found = text.match(/#[\p{L}\p{N}_]{1,30}/gu) ?? [];
  const unique: string[] = [];
  for (const tag of found) {
    const lower = tag.toLowerCase();
    if (!unique.includes(lower)) unique.push(lower);
    if (unique.length >= MAX_HASHTAGS) break;
  }
  return unique;
}

/** `ctx.db.get` throws when given a malformed id; treat that as "not found". */
async function safeGet<T extends TableNames>(
  ctx: { db: { get: (id: never) => Promise<unknown> } },
  _table: T,
  id: string,
): Promise<Doc<T> | null> {
  try {
    return (await ctx.db.get(id as never)) as Doc<T> | null;
  } catch {
    return null;
  }
}

async function bumpProfileCounter(
  ctx: MutationCtx,
  projectId: Id<"projects">,
  userId: Id<"users">,
  field: "followerCount" | "followingCount" | "postCount",
  delta: number,
): Promise<void> {
  const profile = await ctx.db
    .query("profiles")
    .withIndex("by_user", (q) => q.eq("userId", userId))
    .filter((q) => q.eq(q.field("projectId"), projectId))
    .unique();
  if (!profile) return;
  const current = profile[field];
  await ctx.db.patch(profile._id, {
    [field]: Math.max(0, current + delta),
  });
}

// ---------------------------------------------------------------------------
// Posts + media
// ---------------------------------------------------------------------------

type MediaArg = {
  fileId?: Id<"files">;
  url?: string;
  kind: "image" | "video" | "audio";
  mimeType: string;
  width?: number;
  height?: number;
  aspectRatio?: string;
  durationMs?: number;
  sizeBytes?: number;
};

export const createPost = internalMutation({
  args: {
    projectId: v.id("projects"),
    authorId: v.id("users"),
    text: v.optional(v.string()),
    media: v.optional(v.array(v.any())),
    visibility: v.optional(
      v.union(v.literal("public"), v.literal("followers"), v.literal("private")),
    ),
  },
  handler: async (ctx, args) => {
    const text = args.text?.trim();
    const media = (args.media ?? []) as MediaArg[];
    if (!text && media.length === 0) {
      return {
        status: "invalid" as const,
        message: 'A post needs "text" or at least one media attachment.',
      };
    }
    if (text && text.length > MAX_POST_TEXT) {
      return {
        status: "invalid" as const,
        message: `Posts are limited to ${MAX_POST_TEXT} characters.`,
      };
    }
    if (media.length > MAX_MEDIA_PER_POST) {
      return {
        status: "invalid" as const,
        message: `A post can carry at most ${MAX_MEDIA_PER_POST} attachments.`,
      };
    }
    for (const item of media) {
      if (item.kind !== "image" && item.kind !== "video" && item.kind !== "audio") {
        return {
          status: "invalid" as const,
          message: 'Each attachment needs "kind": image | video | audio.',
        };
      }
      if (!item.fileId && !item.url) {
        return {
          status: "invalid" as const,
          message: 'Each attachment needs a "fileId" (from /v1/storage/upload) or a "url".',
        };
      }
      // Convex validates v.id(...) before the body runs, so a malformed fileId
      // would throw out of the mutation and surface as a 500. Reject it here.
      if (item.fileId && !/^[A-Za-z0-9_-]{16,64}$/.test(item.fileId)) {
        return {
          status: "invalid" as const,
          message: 'Each attachment "fileId" must be an id returned by /v1/storage/upload.',
        };
      }
      // A syntactically valid id still has to exist in this project, otherwise
      // the post silently references media nobody can download.
      if (item.fileId) {
        const file = await safeGet(ctx, "files", item.fileId);
        if (!file || file.projectId !== args.projectId) {
          return {
            status: "invalid" as const,
            message: 'Each attachment "fileId" must reference a file in this project.',
          };
        }
      }
    }

    const kind: "text" | "photo" | "video" =
      media.length === 0
        ? "text"
        : media.some((m) => m.kind === "video")
          ? "video"
          : "photo";

    const cover = media[0];
    const postId = await ctx.db.insert("posts", {
      projectId: args.projectId,
      authorId: args.authorId,
      text,
      kind,
      aspectRatio:
        cover?.aspectRatio ?? aspectRatioFor(cover?.width, cover?.height),
      mediaCount: media.length,
      likeCount: 0,
      commentCount: 0,
      shareCount: 0,
      visibility: args.visibility ?? "public",
      hashtags: text ? extractHashtags(text) : undefined,
    });

    const ids: Id<"media">[] = [];
    for (let i = 0; i < media.length; i++) {
      const item = media[i];
      const id = await ctx.db.insert("media", {
        projectId: args.projectId,
        postId,
        ownerId: args.authorId,
        bucket: "post-media",
        fileId: item.fileId,
        url: item.url,
        kind: item.kind,
        mimeType: item.mimeType || "application/octet-stream",
        width: item.width,
        height: item.height,
        aspectRatio: item.aspectRatio ?? aspectRatioFor(item.width, item.height),
        durationMs: item.durationMs,
        sizeBytes: item.sizeBytes,
        position: i,
      });
      ids.push(id);
    }

    await bumpProfileCounter(ctx, args.projectId, args.authorId, "postCount", 1);
    return { status: "created" as const, postId, mediaIds: ids };
  },
});

export const postsByAuthor = internalQuery({
  args: {
    projectId: v.id("projects"),
    authorId: v.id("users"),
    limit: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const limit = Math.min(Math.max(1, args.limit ?? 20), 50);
    return await ctx.db
      .query("posts")
      .withIndex("by_project_author", (q) =>
        q.eq("projectId", args.projectId).eq("authorId", args.authorId),
      )
      .order("desc")
      .take(limit);
  },
});

export const postById = internalQuery({
  args: { projectId: v.id("projects"), postId: v.id("posts") },
  handler: async (ctx, args) => {
    const post = await ctx.db.get(args.postId);
    if (!post || post.projectId !== args.projectId) return null;
    return post;
  },
});

export const mediaForPost = internalQuery({
  args: { postId: v.id("posts") },
  handler: async (ctx, args) => {
    const rows = await ctx.db
      .query("media")
      .withIndex("by_post", (q) => q.eq("postId", args.postId))
      .collect();
    return rows.sort((a, b) => a.position - b.position);
  },
});

export const mediaForPosts = internalQuery({
  args: { postIds: v.array(v.id("posts")) },
  handler: async (ctx, args) => {
    if (args.postIds.length === 0) return [];
    const out: Doc<"media">[] = [];
    for (const postId of args.postIds) {
      const rows = await ctx.db
        .query("media")
        .withIndex("by_post", (q) => q.eq("postId", postId))
        .collect();
      out.push(...rows);
    }
    return out.sort((a, b) => a.position - b.position);
  },
});

/** Recent public posts from anyone — the discovery feed. */
export const recentPosts = internalQuery({
  args: { projectId: v.id("projects"), limit: v.optional(v.number()) },
  handler: async (ctx, args) => {
    const limit = Math.min(Math.max(1, args.limit ?? 20), 50);
    return await ctx.db
      .query("posts")
      .withIndex("by_project", (q) => q.eq("projectId", args.projectId))
      .order("desc")
      .take(limit);
  },
});

export const followingIds = internalQuery({
  args: { projectId: v.id("projects"), userId: v.id("users") },
  handler: async (ctx, args) => {
    const rows = await ctx.db
      .query("follows")
      .withIndex("by_follower", (q) =>
        q.eq("projectId", args.projectId).eq("followerId", args.userId),
      )
      .collect();
    return rows
      .filter((row) => row.status === "active")
      .map((row) => row.followingId);
  },
});

/** Following + self, used to scope the home feed. */
export const feedAuthorIds = internalQuery({
  args: { projectId: v.id("projects"), userId: v.id("users") },
  handler: async (ctx, args) => {
    const rows = await ctx.db
      .query("follows")
      .withIndex("by_follower", (q) =>
        q.eq("projectId", args.projectId).eq("followerId", args.userId),
      )
      .collect();
    const ids = rows
      .filter((row) => row.status === "active")
      .map((row) => row.followingId);
    ids.push(args.userId);
    return ids;
  },
});

// ---------------------------------------------------------------------------
// Follows
// ---------------------------------------------------------------------------

export const follow = internalMutation({
  args: {
    projectId: v.id("projects"),
    followerId: v.id("users"),
    followingId: v.id("users"),
  },
  handler: async (ctx, args) => {
    if (args.followerId === args.followingId) {
      return { status: "self_follow" as const, message: "You cannot follow yourself." };
    }
    const target = await ctx.db
      .query("profiles")
      .withIndex("by_user", (q) => q.eq("userId", args.followingId))
      .filter((q) => q.eq(q.field("projectId"), args.projectId))
      .unique();
    if (!target) {
      return { status: "not_found" as const, message: "That user has no profile." };
    }
    const existing = await ctx.db
      .query("follows")
      .withIndex("by_follower", (q) =>
        q
          .eq("projectId", args.projectId)
          .eq("followerId", args.followerId),
      )
      .filter((q) => q.eq(q.field("followingId"), args.followingId))
      .unique();
    if (existing) {
      return { status: "already_following" as const, followId: existing._id };
    }
    const followId = await ctx.db.insert("follows", {
      projectId: args.projectId,
      followerId: args.followerId,
      followingId: args.followingId,
      status: "active",
    });
    await bumpProfileCounter(ctx, args.projectId, args.followingId, "followerCount", 1);
    await bumpProfileCounter(ctx, args.projectId, args.followerId, "followingCount", 1);
    return { status: "followed" as const, followId };
  },
});

export const unfollow = internalMutation({
  args: {
    projectId: v.id("projects"),
    followerId: v.id("users"),
    followingId: v.id("users"),
  },
  handler: async (ctx, args) => {
    const existing = await ctx.db
      .query("follows")
      .withIndex("by_follower", (q) =>
        q
          .eq("projectId", args.projectId)
          .eq("followerId", args.followerId),
      )
      .filter((q) => q.eq(q.field("followingId"), args.followingId))
      .unique();
    if (!existing) {
      return { status: "not_following" as const };
    }
    await ctx.db.delete(existing._id);
    await bumpProfileCounter(ctx, args.projectId, args.followingId, "followerCount", -1);
    await bumpProfileCounter(ctx, args.projectId, args.followerId, "followingCount", -1);
    return { status: "unfollowed" as const };
  },
});

export const isFollowing = internalQuery({
  args: {
    projectId: v.id("projects"),
    followerId: v.id("users"),
    followingId: v.id("users"),
  },
  handler: async (ctx, args) => {
    const row = await ctx.db
      .query("follows")
      .withIndex("by_follower", (q) =>
        q.eq("projectId", args.projectId).eq("followerId", args.followerId),
      )
      .filter((q) => q.eq(q.field("followingId"), args.followingId))
      .unique();
    return row !== null;
  },
});

// ---------------------------------------------------------------------------
// Dashboard
// ---------------------------------------------------------------------------

export const socialStats = query({
  args: { projectId: v.id("projects") },
  handler: async (ctx, args) => {
    await requireOwnedProject(ctx, args.projectId);
    const posts = await ctx.db
      .query("posts")
      .withIndex("by_project", (q) => q.eq("projectId", args.projectId))
      .collect();
    const follows = await ctx.db
      .query("follows")
      .withIndex("by_following", (q) => q.eq("projectId", args.projectId))
      .collect();
    return {
      posts: posts.length,
      media: await ctx.db
        .query("media")
        .withIndex("by_project", (q) => q.eq("projectId", args.projectId))
        .collect()
        .then((rows) => rows.length),
      follows: follows.length,
      latestPostAt: posts.reduce(
        (max, post) => Math.max(max, post._creationTime),
        0,
      ),
    };
  },
});