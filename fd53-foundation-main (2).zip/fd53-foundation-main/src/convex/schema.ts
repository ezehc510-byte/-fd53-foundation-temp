import { authTables } from "@convex-dev/auth/server";
import { defineSchema, defineTable } from "convex/server";
import { Infer, v } from "convex/values";

// default user roles. can add / remove based on the project as needed
export const ROLES = {
  ADMIN: "admin",
  USER: "user",
  MEMBER: "member",
} as const;

export const roleValidator = v.union(
  v.literal(ROLES.ADMIN),
  v.literal(ROLES.USER),
  v.literal(ROLES.MEMBER),
);
export type Role = Infer<typeof roleValidator>;

// ---------------------------------------------------------------------------
// FD53 — backend-as-a-service domain validators
// ---------------------------------------------------------------------------

/** Column types supported by FD53 tables. */
export const FIELD_TYPES = [
  "string",
  "number",
  "boolean",
  "datetime",
  "json",
  "reference",
] as const;
export const fieldTypeValidator = v.union(
  v.literal("string"),
  v.literal("number"),
  v.literal("boolean"),
  v.literal("datetime"),
  v.literal("json"),
  v.literal("reference"),
);
export type FieldType = Infer<typeof fieldTypeValidator>;

/** A column definition on an FD53 table. */
export const fieldDefValidator = v.object({
  name: v.string(),
  type: fieldTypeValidator,
  required: v.optional(v.boolean()),
  unique: v.optional(v.boolean()),
  /** For `reference` columns: the FD53 table this column points at. */
  refTable: v.optional(v.string()),
  description: v.optional(v.string()),
});
export type FieldDef = Infer<typeof fieldDefValidator>;

/** Row-level access policy for an FD53 table. */
export const ACCESS_LEVELS = ["public", "authenticated", "owner"] as const;
export const accessValidator = v.union(
  v.literal("public"),
  v.literal("authenticated"),
  v.literal("owner"),
);
export type AccessLevel = Infer<typeof accessValidator>;

/** Categories used for usage accounting / rate-limit reporting. */
export const USAGE_CATEGORIES = [
  "auth",
  "database",
  "storage",
  "realtime",
  "social",
  "marketplace",
  "system",
] as const;
export const usageCategoryValidator = v.union(
  v.literal("auth"),
  v.literal("database"),
  v.literal("storage"),
  v.literal("realtime"),
  v.literal("social"),
  v.literal("marketplace"),
  v.literal("system"),
);

/**
 * Storage buckets exposed by FD53 for app use.
 * `visibility` is fixed per bucket and enforced on upload — a caller cannot
 * flip a private bucket's files to public through the REST API.
 */
export const STORAGE_BUCKETS = ["avatars", "post-media", "receipts"] as const;
export const bucketValidator = v.union(
  v.literal("avatars"),
  v.literal("post-media"),
  v.literal("receipts"),
);
export type StorageBucket = (typeof STORAGE_BUCKETS)[number];

const schema = defineSchema(
  {
    // default auth tables using convex auth.
    ...authTables, // do not remove or modify

    // the users table is the default users table that is brought in by the authTables
    users: defineTable({
      name: v.optional(v.string()), // name of the user. do not remove
      image: v.optional(v.string()), // image of the user. do not remove
      email: v.optional(v.string()), // email of the user. do not remove
      emailVerificationTime: v.optional(v.number()), // email verification time. do not remove
      isAnonymous: v.optional(v.boolean()), // is the user anonymous. do not remove

      role: v.optional(roleValidator), // role of the user. do not remove

      // --- LoopUni identity fields (optional: console users have none) ------
      /** Unique @-handle, e.g. "ada_lovelace". */
      username: v.optional(v.string()),
      /** Lowercased `username`, used for case-insensitive lookups + uniqueness. */
      usernameLower: v.optional(v.string()),
      /** Set once the user is a marketplace creator. */
      isCreator: v.optional(v.boolean()),
      /** Bumped to invalidate every outstanding session for this identity. */
      tokenVersion: v.optional(v.number()),
      /** Moderation. */
      suspendedAt: v.optional(v.number()),
      suspendReason: v.optional(v.string()),
    })
      .index("email", ["email"]) // index for the email. do not remove or modify
      .index("by_username", ["usernameLower"]),

    // -------------------------------------------------------------------------
    // LoopUni — social graph, feed, messaging and marketplace
    // -------------------------------------------------------------------------

    /**
     * Public profile for a LoopUni user, keyed by the `users` identity.
     * The `users` row owns credentials; this row owns everything public.
     */
    profiles: defineTable({
      projectId: v.id("projects"),
      userId: v.id("users"),
      /** FD53 end-user account backing this identity (its token subject). */
      endUserId: v.optional(v.id("endUsers")),
      handle: v.string(),
      handleLower: v.string(),
      displayName: v.optional(v.string()),
      bio: v.optional(v.string()),
      avatarUrl: v.optional(v.string()),
      bannerUrl: v.optional(v.string()),
      location: v.optional(v.string()),
      website: v.optional(v.string()),
      /** Denormalised counters — read far more often than written. */
      followerCount: v.number(),
      followingCount: v.number(),
      postCount: v.number(),
      isCreator: v.optional(v.boolean()),
      isVerified: v.optional(v.boolean()),
    })
      .index("by_project_handle", ["projectId", "handleLower"])
      .index("by_user", ["userId"])
      .index("by_end_user", ["projectId", "endUserId"]),

    /** A feed post (text, photo or video). */
    posts: defineTable({
      projectId: v.id("projects"),
      authorId: v.id("users"),
      text: v.optional(v.string()),
      /** text | photo | video — mirrors the attached media kind. */
      kind: v.union(v.literal("text"), v.literal("photo"), v.literal("video")),
      /** width/height of the primary media, used for layout without a download. */
      aspectRatio: v.optional(v.string()), // e.g. "9:16"
      mediaCount: v.number(),
      /** Denormalised counters. */
      likeCount: v.number(),
      commentCount: v.number(),
      shareCount: v.number(),
      visibility: v.union(
        v.literal("public"),
        v.literal("followers"),
        v.literal("private"),
      ),
      hashtags: v.optional(v.array(v.string())),
    })
      .index("by_project", ["projectId"])
      .index("by_project_author", ["projectId", "authorId"]),

    /** A media attachment on a post (or a standalone asset). */
    media: defineTable({
      projectId: v.id("projects"),
      postId: v.optional(v.id("posts")),
      ownerId: v.id("users"),
      bucket: bucketValidator,
      /** FD53 storage object backing this media. */
      fileId: v.optional(v.id("files")),
      url: v.optional(v.string()),
      kind: v.union(v.literal("image"), v.literal("video"), v.literal("audio")),
      mimeType: v.string(),
      /** Dimensions / duration so clients can lay out before downloading. */
      width: v.optional(v.number()),
      height: v.optional(v.number()),
      aspectRatio: v.optional(v.string()),
      durationMs: v.optional(v.number()),
      sizeBytes: v.optional(v.number()),
      /** Sort key within a post: 0 is the cover frame. */
      position: v.number(),
    })
      .index("by_post", ["postId"])
      .index("by_project", ["projectId"]),

    /** Directed social graph edge: followerId follows followingId. */
    follows: defineTable({
      projectId: v.id("projects"),
      followerId: v.id("users"),
      followingId: v.id("users"),
      /** Private accounts need approval. */
      status: v.union(v.literal("active"), v.literal("pending")),
    })
      .index("by_follower", ["projectId", "followerId"])
      .index("by_following", ["projectId", "followingId"]),

    /** A chat room: direct (1:1) or group. */
    conversations: defineTable({
      projectId: v.id("projects"),
      /** Stable client-visible room id, e.g. "dm:<a>:<b>". Unique per project. */
      roomId: v.string(),
      type: v.union(v.literal("direct"), v.literal("group")),
      title: v.optional(v.string()),
      participantIds: v.array(v.id("users")),
      lastMessageAt: v.optional(v.number()),
      lastMessagePreview: v.optional(v.string()),
    })
      .index("by_project_room", ["projectId", "roomId"])
      .index("by_project", ["projectId"]),

    /** One message inside a conversation. */
    messages: defineTable({
      projectId: v.id("projects"),
      conversationId: v.id("conversations"),
      roomId: v.string(),
      senderId: v.id("users"),
      text: v.optional(v.string()),
      kind: v.union(v.literal("text"), v.literal("image"), v.literal("system")),
      mediaIds: v.optional(v.array(v.id("media"))),
      readAt: v.optional(v.number()),
    })
      .index("by_conversation", ["projectId", "conversationId"]),

    /** A marketplace listing. */
    products: defineTable({
      projectId: v.id("projects"),
      sellerId: v.id("users"),
      title: v.string(),
      description: v.optional(v.string()),
      /** Minor units (cents) to avoid float money. */
      priceCents: v.number(),
      currency: v.string(),
      category: v.optional(v.string()),
      /** digital | physical */
      kind: v.union(v.literal("digital"), v.literal("physical")),
      /** Draft listings are hidden from GET /v1/marketplace/products. */
      status: v.union(
        v.literal("active"),
        v.literal("draft"),
        v.literal("sold_out"),
        v.literal("removed"),
      ),
      /** Public preview images, stored in the post-media bucket. */
      mediaIds: v.optional(v.array(v.id("media"))),
      /** Private downloadable asset, stored in the receipts bucket. */
      assetFileId: v.optional(v.id("files")),
      inventory: v.optional(v.number()),
      salesCount: v.number(),
    })
      .index("by_project", ["projectId"])
      .index("by_seller", ["projectId", "sellerId"]),

    /** A completed purchase. */
    orders: defineTable({
      projectId: v.id("projects"),
      buyerId: v.id("users"),
      sellerId: v.id("users"),
      productId: v.id("products"),
      quantity: v.number(),
      amountCents: v.number(),
      platformFeeCents: v.number(),
      currency: v.string(),
      status: v.union(
        v.literal("pending"),
        v.literal("paid"),
        v.literal("failed"),
        v.literal("refunded"),
      ),
      /** Private purchase invoice, stored in the receipts bucket. */
      receiptFileId: v.optional(v.id("files")),
      /** Gateway reference — the tokenised id only, never card data. */
      paymentRef: v.optional(v.string()),
      purchasedAt: v.optional(v.number()),
    })
      .index("by_project_buyer", ["projectId", "buyerId"])
      .index("by_project_seller", ["projectId", "sellerId"]),

    /** Ledger row per sale; one per order, plus manual adjustments. */
    creatorEarnings: defineTable({
      projectId: v.id("projects"),
      creatorId: v.id("users"),
      orderId: v.optional(v.id("orders")),
      productId: v.optional(v.id("products")),
      grossCents: v.number(),
      platformFeeCents: v.number(),
      netCents: v.number(),
      currency: v.string(),
      status: v.union(
        v.literal("pending"),
        v.literal("available"),
        v.literal("paid"),
      ),
      /** Balance available to withdraw right now, in minor units. */
      availableAt: v.optional(v.number()),
    })
      .index("by_creator", ["projectId", "creatorId"]),

    /**
     * Application-level rate limits (anti-spam), separate from the
     * per-API-key `rateBuckets`. Keyed by an arbitrary caller identity such
     * as `post:<userId>` or `checkout:<userId>`.
     */
    rateLimits: defineTable({
      projectId: v.id("projects"),
      /** Caller identity, e.g. "post:<id>" or "ip:1.2.3.4". */
      key: v.string(),
      /** Floor of the window start, in epoch milliseconds. */
      windowStart: v.number(),
      count: v.number(),
      /** Set when the caller exceeded the limit and is currently blocked. */
      blockedUntil: v.optional(v.number()),
    })
      .index("by_key_window", ["projectId", "key", "windowStart"])
      .index("by_key", ["projectId", "key"])
      .index("by_project", ["projectId"]),

    /** Moderation flags raised by users or by moderation tooling. */
    reports: defineTable({
      projectId: v.id("projects"),
      reporterId: v.optional(v.id("users")),
      /** The reported thing's type + id; polymorphic by design. */
      targetType: v.union(
        v.literal("user"),
        v.literal("post"),
        v.literal("comment"),
        v.literal("message"),
        v.literal("product"),
      ),
      targetId: v.string(),
      reason: v.string(),
      details: v.optional(v.string()),
      status: v.union(
        v.literal("open"),
        v.literal("reviewing"),
        v.literal("resolved"),
        v.literal("dismissed"),
      ),
      resolvedAt: v.optional(v.number()),
      resolvedBy: v.optional(v.id("users")),
    })
      .index("by_project", ["projectId"])
      .index("by_target", ["projectId", "targetType", "targetId"])
      .index("by_status", ["projectId", "status"]),

    /**
     * Per-request log row. Feeds the Usage dashboard's request table so
     * developers can see exactly which routes their app is hitting.
     */
    requestLogs: defineTable({
      projectId: v.id("projects"),
      apiKeyId: v.optional(v.id("apiKeys")),
      method: v.string(),
      path: v.string(),
      /** Matched route pattern, e.g. "/v1/posts/create". */
      route: v.string(),
      category: usageCategoryValidator,
      status: v.number(),
      durationMs: v.number(),
      /** End user id when the request carried a bearer token. */
      endUserId: v.optional(v.id("endUsers")),
      /** Gateway correlation id, also returned as `X-FD53-Request-Id`. */
      requestId: v.optional(v.string()),
    })
      .index("by_project", ["projectId"]),

    // -----------------------------------------------------------------------
    // FD53 platform tables
    // -----------------------------------------------------------------------

    // A project = one backend app served by FD53 (e.g. "LoopUni", "my-flutter-app").
    projects: defineTable({
      ownerId: v.id("users"),
      name: v.string(),
      slug: v.string(),
      description: v.optional(v.string()),
      status: v.union(v.literal("active"), v.literal("suspended")),
      plan: v.string(),
      // quota (v1 free plan)
      requestsPerMinute: v.number(),
      storageLimitBytes: v.number(),
      // running storage usage, maintained on upload/delete
      storageBytes: v.number(),
    })
      .index("by_owner", ["ownerId"])
      .index("by_slug", ["slug"]),

    // Server-side API keys used by apps (FlutterFlow etc.) to call /v1.
    apiKeys: defineTable({
      projectId: v.id("projects"),
      name: v.string(),
      // display prefix, e.g. "fd53_live_9f2c1a7e" — shown in the dashboard
      keyPrefix: v.string(),
      // sha256 of the full key; the plaintext key is only shown once at creation
      keyHash: v.string(),
      scopes: v.array(v.string()),
      rateLimit: v.number(), // requests per minute for this key
      /**
       * Key environment, encoded in the key string itself
       * (`fd53_live_…` / `fd53_test_…`). Optional for keys minted before v1.1.
       */
      environment: v.optional(v.union(v.literal("live"), v.literal("test"))),
      /** Epoch ms after which the key is rejected even if not revoked. */
      expiresAt: v.optional(v.number()),
      /** Exact IPs / CIDR blocks permitted to use this key. Empty = any IP. */
      allowedIps: v.optional(v.array(v.string())),
      /** Exact IPs / CIDR blocks explicitly blocked. Checked before the allowlist. */
      blockedIps: v.optional(v.array(v.string())),
      /** Origins permitted by CORS for this key. Empty = the platform default. */
      allowedOrigins: v.optional(v.array(v.string())),
      lastUsedAt: v.optional(v.number()),
      revokedAt: v.optional(v.number()),
    })
      .index("by_hash", ["keyHash"])
      .index("by_project", ["projectId"]),

    // Schema definitions (tables/columns) for a project's data.
    tables: defineTable({
      projectId: v.id("projects"),
      name: v.string(),
      description: v.optional(v.string()),
      access: accessValidator,
      fields: v.array(fieldDefValidator),
      // maintained by row insert/delete — avoids scanning for counts
      rowCount: v.number(),
    })
      .index("by_project", ["projectId"])
      .index("by_project_name", ["projectId", "name"]),

    // Generic document store backing every FD53 table (schema-on-write).
    rows: defineTable({
      projectId: v.id("projects"),
      tableId: v.id("tables"),
      tableName: v.string(),
      data: v.record(v.string(), v.any()),
      // end user that created the row (for "owner" access tables)
      ownerId: v.optional(v.id("endUsers")),
    })
      .index("by_table", ["projectId", "tableId"])
      .index("by_table_name", ["projectId", "tableName"]),

    // Materialised unique keys so `unique: true` columns are enforced in O(1).
    uniqueValues: defineTable({
      projectId: v.id("projects"),
      tableId: v.id("tables"),
      field: v.string(),
      value: v.string(),
      rowId: v.id("rows"),
    }).index("by_key", ["projectId", "tableId", "field", "value"]),

    // End users of a project's app (students, customers, …) — FD53 Auth.
    endUsers: defineTable({
      projectId: v.id("projects"),
      email: v.optional(v.string()),
      phone: v.optional(v.string()),
      name: v.optional(v.string()),
      // pbkdf2 output + salt, hex encoded (never returned by any API)
      passwordHash: v.optional(v.string()),
      salt: v.optional(v.string()),
      role: v.string(), // role name from the project's `roles` table
      status: v.union(v.literal("active"), v.literal("banned")),
      // abuse protection
      failedAttempts: v.number(),
      lockedUntil: v.optional(v.number()),
      // bump to invalidate every outstanding token for this user
      tokenVersion: v.number(),
      lastLoginAt: v.optional(v.number()),
      // free-form profile data supplied at registration
      data: v.optional(v.any()),
    })
      .index("by_project", ["projectId"])
      .index("by_project_email", ["projectId", "email"])
      .index("by_project_phone", ["projectId", "phone"]),

    // Stateful sessions behind the stateless JWT — enables revocation.
    sessions: defineTable({
      projectId: v.id("projects"),
      endUserId: v.id("endUsers"),
      sid: v.string(),
      createdAt: v.number(),
      expiresAt: v.number(),
      revokedAt: v.optional(v.number()),
      userAgent: v.optional(v.string()),
    })
      .index("by_sid", ["projectId", "sid"])
      .index("by_user", ["projectId", "endUserId"]),

    // Roles + permissions for a project's end users.
    roles: defineTable({
      projectId: v.id("projects"),
      name: v.string(),
      description: v.optional(v.string()),
      permissions: v.array(v.string()),
      isDefault: v.optional(v.boolean()),
    })
      .index("by_project", ["projectId"])
      .index("by_project_name", ["projectId", "name"]),

    // Storage objects (profile pictures, images, videos, audio, documents).
    files: defineTable({
      projectId: v.id("projects"),
      name: v.string(),
      path: v.string(),
      mimeType: v.string(),
      size: v.number(),
      storageId: v.id("_storage"),
      visibility: v.union(v.literal("public"), v.literal("private")),
      ownerId: v.optional(v.id("endUsers")),
      category: v.string(), // image | video | audio | document | other
      /** Which logical bucket this file belongs to (avatars/post-media/receipts). */
      bucket: v.optional(bucketValidator),
    })
      .index("by_project", ["projectId"])
      .index("by_project_path", ["projectId", "path"])
      .index("by_project_bucket", ["projectId", "bucket"]),

    // Phone OTP challenges for FD53 Auth.
    phoneOtps: defineTable({
      projectId: v.id("projects"),
      phone: v.string(),
      codeHash: v.string(),
      expiresAt: v.number(),
      attempts: v.number(),
      consumedAt: v.optional(v.number()),
    })
      .index("by_phone", ["projectId", "phone"]),

    // One-shot password reset tokens (delivery via provider or console).
    passwordResets: defineTable({
      projectId: v.id("projects"),
      endUserId: v.id("endUsers"),
      tokenHash: v.string(),
      expiresAt: v.number(),
      usedAt: v.optional(v.number()),
    })
      .index("by_token", ["tokenHash"])
      .index("by_project", ["projectId"]),

    // Sliding-window rate limiter buckets (one doc per key per minute).
    rateBuckets: defineTable({
      keyId: v.id("apiKeys"),
      bucket: v.number(), // floor(epochMinutes)
      count: v.number(),
    }).index("by_key_bucket", ["keyId", "bucket"]),

    // Daily usage counters per project, split by category.
    usageDaily: defineTable({
      projectId: v.id("projects"),
      day: v.string(), // YYYY-MM-DD (UTC)
      category: usageCategoryValidator,
      count: v.number(),
      errorCount: v.number(),
    })
      .index("by_project_day", ["projectId", "day"])
      .index("by_project_day_cat", ["projectId", "day", "category"]),

    // Realtime event log — powers chat, notifications and live events.
    events: defineTable({
      projectId: v.id("projects"),
      channel: v.string(),
      type: v.string(),
      payload: v.optional(v.any()),
      sender: v.optional(v.string()),
    }).index("by_channel", ["projectId", "channel"]),

    /**
     * Pre-authentication flood buckets, keyed by a *hashed* client IP.
     * Written before any API key is resolved so a flood from an unauthenticated
     * client is rejected before it can reach the database or a handler.
     * Deliberately separate from `rateBuckets` (per API key) and `rateLimits`
     * (per end user).
     */
    edgeBuckets: defineTable({
      /** Caller identity, e.g. "ip:<sha256>" or "path:<route>" or "auth_fail". */
      scope: v.string(),
      /** Floor of the window start, in epoch milliseconds. */
      windowStart: v.number(),
      count: v.number(),
      /** Set while the caller is serving a ban for this window. */
      blockedUntil: v.optional(v.number()),
    }).index("by_scope_window", ["scope", "windowStart"]),

    /**
     * Immutable audit trail for security-relevant events: key creation and
     * revocation, authentication failures, IP blocks, WAF trips and admin
     * configuration changes. Never pruned automatically — this is evidence.
     */
    auditLogs: defineTable({
      projectId: v.optional(v.id("projects")),
      apiKeyId: v.optional(v.id("apiKeys")),
      /** Machine-readable event name, e.g. "key.created", "waf.blocked". */
      event: v.string(),
      outcome: v.union(
        v.literal("success"),
        v.literal("failure"),
        v.literal("blocked"),
      ),
      method: v.optional(v.string()),
      path: v.optional(v.string()),
      /** Hashed client IP — raw IPs are never stored in the audit trail. */
      ipHash: v.optional(v.string()),
      userAgent: v.optional(v.string()),
      /** Correlates a request across gateway logs and audit rows. */
      requestId: v.optional(v.string()),
      detail: v.optional(v.string()),
    })
      .index("by_project", ["projectId"])
      .index("by_event", ["event"]),

    // Server-side secrets (e.g. the FD53 JWT signing key), never exposed.
    secrets: defineTable({
      key: v.string(),
      value: v.string(),
    }).index("by_key", ["key"]),
  },
  {
    schemaValidation: false,
  },
);

export default schema;
