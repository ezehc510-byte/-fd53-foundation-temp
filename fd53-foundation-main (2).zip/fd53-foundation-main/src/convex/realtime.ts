import { v } from "convex/values";
import { requireOwnedProject } from "./lib/authz";
import type { Doc, Id } from "./_generated/dataModel";
import {
  internalMutation,
  internalQuery,
  mutation,
  query,
  type MutationCtx,
} from "./_generated/server";

const MAX_PAYLOAD_BYTES = 8 * 1024;
const CHANNEL_PATTERN = /^[A-Za-z0-9._:-]{1,64}$/;

type PublishResult =
  | { status: "published"; event: Doc<"events"> }
  | { status: "invalid"; message: string };

/** Shared publish path for the REST API and the dashboard. */
export async function doPublish(
  ctx: MutationCtx,
  args: {
    projectId: Id<"projects">;
    channel: string;
    type: string;
    payload?: unknown;
    sender?: string;
  },
): Promise<PublishResult> {
  const channel = args.channel.trim();
  if (!CHANNEL_PATTERN.test(channel)) {
    return {
      status: "invalid",
      message:
        "Channel names may use letters, digits, '.', '_', ':' and '-' (max 64 chars).",
    };
  }
  const type = args.type.trim().slice(0, 64);
  if (!type) {
    return { status: "invalid", message: "Event type is required." };
  }
  if (args.payload !== undefined) {
    const encoded = JSON.stringify(args.payload);
    if (encoded === undefined || encoded.length > MAX_PAYLOAD_BYTES) {
      return {
        status: "invalid",
        message: `Event payload must be valid JSON under ${MAX_PAYLOAD_BYTES} bytes.`,
      };
    }
  }

  const id = await ctx.db.insert("events", {
    projectId: args.projectId,
    channel,
    type,
    payload: args.payload,
    sender: args.sender?.slice(0, 120),
  });
  const event = await ctx.db.get(id);
  return { status: "published", event: event! };
}

/** REST realtime publish. */
export const publish = internalMutation({
  args: {
    projectId: v.id("projects"),
    channel: v.string(),
    type: v.string(),
    payload: v.optional(v.any()),
    sender: v.optional(v.string()),
  },
  handler: async (ctx, args) => await doPublish(ctx, args),
});

/** Dashboard "send test event" button. */
export const publishFromDashboard = mutation({
  args: {
    projectId: v.id("projects"),
    channel: v.string(),
    type: v.string(),
    payload: v.optional(v.any()),
  },
  handler: async (ctx, args) => {
    await requireOwnedProject(ctx, args.projectId);
    return await doPublish(ctx, {
      projectId: args.projectId,
      channel: args.channel,
      type: args.type,
      payload: args.payload,
      sender: "console",
    });
  },
});

/** Channels + counters for the REST layer. */
export const channelsForApi = internalQuery({
  args: { projectId: v.id("projects") },
  handler: async (ctx, args) => {
    const events = await ctx.db
      .query("events")
      .withIndex("by_channel", (q) => q.eq("projectId", args.projectId))
      .order("desc")
      .take(500);

    const channels: Array<{ channel: string; events: number }> = [];
    for (const event of events) {
      const found = channels.find((c) => c.channel === event.channel);
      if (found) found.events += 1;
      else channels.push({ channel: event.channel, events: 1 });
    }
    return channels.sort((a, b) => b.events - a.events);
  },
});

/** Recent events on a channel (REST layer). */
export const eventsForApi = internalQuery({
  args: {
    projectId: v.id("projects"),
    channel: v.string(),
    limit: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const limit = Math.min(Math.max(1, args.limit ?? 50), 200);
    return await ctx.db
      .query("events")
      .withIndex("by_channel", (q) =>
        q.eq("projectId", args.projectId).eq("channel", args.channel),
      )
      .order("desc")
      .take(limit);
  },
});

export const listEvents = query({
  args: {
    projectId: v.id("projects"),
    channel: v.optional(v.string()),
    limit: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    await requireOwnedProject(ctx, args.projectId);
    const limit = Math.min(Math.max(1, args.limit ?? 50), 200);

    let events;
    if (args.channel) {
      events = await ctx.db
        .query("events")
        .withIndex("by_channel", (q) =>
          q.eq("projectId", args.projectId).eq("channel", args.channel!),
        )
        .order("desc")
        .take(limit);
    } else {
      events = await ctx.db
        .query("events")
        .withIndex("by_channel", (q) => q.eq("projectId", args.projectId))
        .order("desc")
        .take(limit);
    }
    return events;
  },
});

export const listChannels = query({
  args: { projectId: v.id("projects") },
  handler: async (ctx, args) => {
    await requireOwnedProject(ctx, args.projectId);
    const events = await ctx.db
      .query("events")
      .withIndex("by_channel", (q) => q.eq("projectId", args.projectId))
      .order("desc")
      .take(500);

    const channels: Array<{
      channel: string;
      events: number;
      lastEventAt: number;
      lastType: string | null;
    }> = [];
    for (const event of events) {
      const found = channels.find((c) => c.channel === event.channel);
      if (found) {
        found.events += 1;
        found.lastType = event.type;
      } else {
        channels.push({
          channel: event.channel,
          events: 1,
          lastEventAt: event._creationTime,
          lastType: event.type,
        });
      }
    }
    return channels.sort((a, b) => b.lastEventAt - a.lastEventAt);
  },
});