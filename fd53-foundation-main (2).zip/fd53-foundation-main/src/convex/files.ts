import { v } from "convex/values";
import { requireOwnedProject } from "./lib/authz";
import {
  BUCKET_FOR_CATEGORY,
  bucketDef,
  fileCategory,
  isValidBucket,
  STORAGE_BUCKET_LIST,
  type BucketName,
} from "./lib/constants";
import type { Doc, Id } from "./_generated/dataModel";
import {
  internalMutation,
  internalQuery,
  mutation,
  query,
  type MutationCtx,
  type QueryCtx,
} from "./_generated/server";

type CreateFileArgs = {
  projectId: Id<"projects">;
  name: string;
  path: string;
  mimeType: string;
  size: number;
  storageId: Id<"_storage">;
  visibility: "public" | "private";
  ownerId?: Id<"endUsers">;
  /** Logical bucket; defaults from the file category when omitted. */
  bucket?: string;
};

/** Type guard used before writing the validated bucket into the row. */
function toBucket(name: string): BucketName {
  return isValidBucket(name) ? name : "receipts";
}

type FileResult =
  | { status: "created"; file: Doc<"files">; url: string | null }
  | { status: "quota"; message: string; limit: number; used: number }
  | { status: "invalid"; message: string };

/** Pick a free path by appending -1, -2 … to the filename. */
async function reservePath(
  ctx: QueryCtx | MutationCtx,
  projectId: Id<"projects">,
  desiredPath: string,
): Promise<string> {
  let candidate = desiredPath;
  let n = 0;
  while (
    await ctx.db
      .query("files")
      .withIndex("by_project_path", (q) =>
        q.eq("projectId", projectId).eq("path", candidate),
      )
      .first()
  ) {
    n += 1;
    const dot = desiredPath.lastIndexOf(".");
    const slash = desiredPath.lastIndexOf("/");
    const extIndex = dot > slash ? dot : desiredPath.length;
    candidate = `${desiredPath.slice(0, extIndex)}-${n}${desiredPath.slice(extIndex)}`;
    if (n > 200) break;
  }
  return candidate;
}

/** Shared file creation with quota enforcement. */
export async function doCreateFile(
  ctx: MutationCtx,
  args: CreateFileArgs,
): Promise<FileResult> {
  if (!Number.isFinite(args.size) || args.size < 0) {
    return { status: "invalid", message: "Invalid file size." };
  }
  const project = await ctx.db.get(args.projectId);
  if (!project) return { status: "invalid", message: "Project not found." };

  const used = project.storageBytes + args.size;
  if (used > project.storageLimitBytes) {
    return {
      status: "quota",
      message: "Storage quota exceeded for this project.",
      used: project.storageBytes,
      limit: project.storageLimitBytes,
    };
  }

  const path = await reservePath(ctx, args.projectId, args.path);
  const category = fileCategory(args.mimeType || "");
  // Buckets own visibility: a private bucket can never be written as public.
  const requestedBucket = args.bucket ?? BUCKET_FOR_CATEGORY[category] ?? "receipts";
  if (!isValidBucket(requestedBucket)) {
    return { status: "invalid", message: `Unknown bucket "${requestedBucket}".` };
  }
  const bucketVisibility = bucketDef(requestedBucket)!.visibility;
  const fileId = await ctx.db.insert("files", {
    projectId: args.projectId,
    name: args.name,
    path,
    mimeType: args.mimeType || "application/octet-stream",
    size: args.size,
    storageId: args.storageId,
    visibility: bucketVisibility,
    ownerId: args.ownerId,
    category,
    bucket: toBucket(requestedBucket),
  });
  await ctx.db.patch(args.projectId, { storageBytes: used });

  const file = await ctx.db.get(fileId);
  const url = await ctx.storage.getUrl(args.storageId);
  return { status: "created", file: file!, url };
}

/** Shared delete: removes the blob, the record and frees the quota. */
export async function doDeleteFile(
  ctx: MutationCtx,
  args: { projectId: Id<"projects">; fileId: Id<"files"> },
): Promise<{ status: "deleted" } | { status: "not_found"; message: string }> {
  const file = await ctx.db.get(args.fileId);
  if (!file || file.projectId !== args.projectId) {
    return { status: "not_found", message: "File not found." };
  }
  try {
    await ctx.storage.delete(file.storageId);
  } catch {
    // blob may already be deleted
  }
  await ctx.db.delete(args.fileId);

  const project = await ctx.db.get(args.projectId);
  if (project) {
    await ctx.db.patch(args.projectId, {
      storageBytes: Math.max(0, project.storageBytes - file.size),
    });
  }
  return { status: "deleted" };
}

async function withUrl(
  ctx: QueryCtx,
  files: Doc<"files">[],
): Promise<Array<Doc<"files"> & { url: string | null }>> {
  return await Promise.all(
    files.map(async (file) => {
      const url = await ctx.storage.getUrl(file.storageId);
      return { ...file, url };
    }),
  );
}

// ---------------------------------------------------------------------------
// Dashboard functions (owner checked)
// ---------------------------------------------------------------------------

export const list = query({
  args: { projectId: v.id("projects"), limit: v.optional(v.number()) },
  handler: async (ctx, args) => {
    const project = await requireOwnedProject(ctx, args.projectId);
    const files = await ctx.db
      .query("files")
      .withIndex("by_project", (q) => q.eq("projectId", args.projectId))
      .collect();
    files.sort((a, b) => b._creationTime - a._creationTime);
    const limit = Math.min(Math.max(1, args.limit ?? 200), 500);
    return {
      total: files.length,
      files: await withUrl(ctx, files.slice(0, limit)),
      storageBytes: project.storageBytes,
      storageLimitBytes: project.storageLimitBytes,
    };
  },
});

/** Step 1 of the dashboard upload: a short-lived Convex upload URL. */
export const generateUploadUrl = mutation({
  args: { projectId: v.id("projects") },
  handler: async (ctx, args) => {
    await requireOwnedProject(ctx, args.projectId);
    return await ctx.storage.generateUploadUrl();
  },
});

/** Step 2 of the dashboard upload: register the uploaded blob. */
export const createRecord = mutation({
  args: {
    projectId: v.id("projects"),
    name: v.string(),
    path: v.optional(v.string()),
    mimeType: v.optional(v.string()),
    size: v.number(),
    storageId: v.id("_storage"),
    visibility: v.optional(v.union(v.literal("public"), v.literal("private"))),
  },
  handler: async (ctx, args) => {
    await requireOwnedProject(ctx, args.projectId);
    const name = args.name.slice(0, 200);
    return await doCreateFile(ctx, {
      projectId: args.projectId,
      name,
      path: args.path?.trim() || name,
      mimeType: args.mimeType ?? "application/octet-stream",
      size: args.size,
      storageId: args.storageId,
      visibility: args.visibility ?? "public",
    });
  },
});

export const setVisibility = mutation({
  args: {
    projectId: v.id("projects"),
    fileId: v.id("files"),
    visibility: v.union(v.literal("public"), v.literal("private")),
  },
  handler: async (ctx, args) => {
    await requireOwnedProject(ctx, args.projectId);
    const file = await ctx.db.get(args.fileId);
    if (!file || file.projectId !== args.projectId) {
      return { status: "not_found" as const };
    }
    await ctx.db.patch(args.fileId, { visibility: args.visibility });
    return { status: "ok" as const };
  },
});

export const remove = mutation({
  args: { projectId: v.id("projects"), fileId: v.id("files") },
  handler: async (ctx, args) => {
    await requireOwnedProject(ctx, args.projectId);
    return await doDeleteFile(ctx, {
      projectId: args.projectId,
      fileId: args.fileId,
    });
  },
});

// ---------------------------------------------------------------------------
// Internal functions — REST storage endpoints
// ---------------------------------------------------------------------------

export const createFromApi = internalMutation({
  args: {
    projectId: v.id("projects"),
    name: v.string(),
    path: v.string(),
    mimeType: v.string(),
    size: v.number(),
    storageId: v.id("_storage"),
    visibility: v.optional(v.union(v.literal("public"), v.literal("private"))),
    ownerId: v.optional(v.id("endUsers")),
    bucket: v.optional(v.string()),
  },
  handler: async (ctx, args) =>
    await doCreateFile(ctx, {
      projectId: args.projectId,
      name: args.name,
      path: args.path,
      mimeType: args.mimeType,
      size: args.size,
      storageId: args.storageId,
      // Ignored when a bucket is set: the bucket decides visibility.
      visibility: args.visibility ?? "private",
      ownerId: args.ownerId,
      bucket: args.bucket,
    }),
});

export const removeFromApi = internalMutation({
  args: { projectId: v.id("projects"), fileId: v.id("files") },
  handler: async (ctx, args) =>
    await doDeleteFile(ctx, {
      projectId: args.projectId,
      fileId: args.fileId,
    }),
});

export const byId = internalQuery({
  args: { projectId: v.id("projects"), fileId: v.id("files") },
  handler: async (ctx, args) => {
    const file = await ctx.db.get(args.fileId);
    if (!file || file.projectId !== args.projectId) return null;
    const url = await ctx.storage.getUrl(file.storageId);
    return { ...file, url };
  },
});

export const listForApi = internalQuery({
  args: {
    projectId: v.id("projects"),
    prefix: v.optional(v.string()),
    limit: v.optional(v.number()),
    ownerId: v.optional(v.id("endUsers")),
    bucket: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const files = await ctx.db
      .query("files")
      .withIndex("by_project", (q) => q.eq("projectId", args.projectId))
      .collect();

    let filtered = files;
    if (args.prefix) {
      filtered = filtered.filter((f) => f.path.startsWith(args.prefix!));
    }
    if (args.ownerId) {
      filtered = filtered.filter((f) => f.ownerId === args.ownerId);
    }
    if (args.bucket) {
      filtered = filtered.filter((f) => f.bucket === args.bucket);
    }
    filtered.sort((a, b) => b._creationTime - a._creationTime);
    const limit = Math.min(Math.max(1, args.limit ?? 50), 200);
    return {
      total: filtered.length,
      files: await withUrl(ctx, filtered.slice(0, limit)),
    };
  },
});

/** Per-bucket file counts and bytes, for the storage overview. */
export const bucketStats = internalQuery({
  args: { projectId: v.id("projects") },
  handler: async (ctx, args) => {
    const files = await ctx.db
      .query("files")
      .withIndex("by_project", (q) => q.eq("projectId", args.projectId))
      .collect();
    return STORAGE_BUCKET_LIST.map((bucket) => {
      const owned = files.filter((f) => f.bucket === bucket.name);
      return {
        ...bucket,
        files: owned.length,
        bytes: owned.reduce((sum, f) => sum + f.size, 0),
      };
    });
  },
});