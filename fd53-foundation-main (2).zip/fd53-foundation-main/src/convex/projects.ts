import { getAuthUserId } from "@convex-dev/auth/server";
import { v } from "convex/values";
import { requireOwnedProject } from "./lib/authz";
import { DEFAULT_ROLES, FREE_PLAN } from "./lib/constants";
import type { Id } from "./_generated/dataModel";
import { internalMutation, internalQuery, mutation, query } from "./_generated/server";

function slugify(name: string): string {
  const base = name
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 40);
  return base || "project";
}

async function ownedUserId(ctx: Parameters<typeof requireOwnedProject>[0]) {
  const userId = await getAuthUserId(ctx);
  if (userId === null) throw new Error("Not signed in.");
  return userId;
}

/** All projects owned by the signed-in developer. */
export const list = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (userId === null) return [];
    return await ctx.db
      .query("projects")
      .withIndex("by_owner", (q) => q.eq("ownerId", userId))
      .collect();
  },
});

/** Project lookup used by the REST layer (API-key auth). */
export const byId = internalQuery({
  args: { id: v.id("projects") },
  handler: async (ctx, args) => await ctx.db.get(args.id),
});

/** Throws unless the signed-in developer owns the project. */
export const requireOwner = internalQuery({
  args: { projectId: v.id("projects") },
  handler: async (ctx, args) => {
    return await requireOwnedProject(ctx, args.projectId);
  },
});

export const create = mutation({
  args: {
    name: v.string(),
    description: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await ownedUserId(ctx);
    const name = args.name.trim();
    if (name.length < 2 || name.length > 60) {
      return { status: "invalid" as const, message: "Name must be 2–60 characters." };
    }

    const base = slugify(name);
    let slug = base;
    let n = 1;
    while (
      await ctx.db
        .query("projects")
        .withIndex("by_slug", (q) => q.eq("slug", slug))
        .first()
    ) {
      n += 1;
      slug = `${base}-${n}`;
    }

    const projectId = await ctx.db.insert("projects", {
      ownerId: userId,
      name,
      slug,
      description: args.description?.trim() || undefined,
      status: "active",
      plan: FREE_PLAN.id,
      requestsPerMinute: FREE_PLAN.requestsPerMinute,
      storageLimitBytes: FREE_PLAN.storageLimitBytes,
      storageBytes: 0,
    });

    // Default roles + permissions for this project's end users.
    for (const role of DEFAULT_ROLES) {
      await ctx.db.insert("roles", {
        projectId,
        name: role.name,
        description: role.description,
        permissions: role.permissions,
        isDefault: role.isDefault,
      });
    }

    return { status: "created" as const, projectId, slug };
  },
});

export const update = mutation({
  args: {
    projectId: v.id("projects"),
    name: v.optional(v.string()),
    description: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    await requireOwnedProject(ctx, args.projectId);
    const patch: {
      name?: string;
      description?: string | undefined;
    } = {};
    if (args.name !== undefined) {
      const name = args.name.trim();
      if (name.length < 2 || name.length > 60) {
        return { status: "invalid" as const, message: "Name must be 2–60 characters." };
      }
      patch.name = name;
    }
    if (args.description !== undefined) {
      patch.description = args.description.trim() || undefined;
    }
    if (Object.keys(patch).length > 0) {
      await ctx.db.patch(args.projectId, patch);
    }
    return { status: "ok" as const };
  },
});

/**
 * Delete a project and cascade into every FD53 table it owns.
 * v1: intended for personal-scale data (see the roadmap in Docs).
 */
export const remove = mutation({
  args: { projectId: v.id("projects") },
  handler: async (ctx, args) => {
    const project = await requireOwnedProject(ctx, args.projectId);
    const projectId: Id<"projects"> = args.projectId;

    const keys = await ctx.db
      .query("apiKeys")
      .withIndex("by_project", (q) => q.eq("projectId", projectId))
      .collect();
    for (const key of keys) {
      const buckets = await ctx.db
        .query("rateBuckets")
        .withIndex("by_key_bucket", (q) => q.eq("keyId", key._id))
        .collect();
      for (const bucket of buckets) await ctx.db.delete(bucket._id);
      await ctx.db.delete(key._id);
    }

    const rows = await ctx.db
      .query("rows")
      .withIndex("by_table", (q) => q.eq("projectId", projectId))
      .collect();
    for (const row of rows) await ctx.db.delete(row._id);

    const uniques = await ctx.db
      .query("uniqueValues")
      .withIndex("by_key", (q) => q.eq("projectId", projectId))
      .collect();
    for (const u of uniques) await ctx.db.delete(u._id);

    const tables = await ctx.db
      .query("tables")
      .withIndex("by_project", (q) => q.eq("projectId", projectId))
      .collect();
    for (const t of tables) await ctx.db.delete(t._id);

    const endUsers = await ctx.db
      .query("endUsers")
      .withIndex("by_project", (q) => q.eq("projectId", projectId))
      .collect();
    for (const user of endUsers) {
      const sessions = await ctx.db
        .query("sessions")
        .withIndex("by_user", (q) =>
          q.eq("projectId", projectId).eq("endUserId", user._id),
        )
        .collect();
      for (const session of sessions) await ctx.db.delete(session._id);
      await ctx.db.delete(user._id);
    }

    const resets = await ctx.db
      .query("passwordResets")
      .withIndex("by_project", (q) => q.eq("projectId", projectId))
      .collect();
    for (const reset of resets) await ctx.db.delete(reset._id);

    const otps = await ctx.db
      .query("phoneOtps")
      .withIndex("by_phone", (q) => q.eq("projectId", projectId))
      .collect();
    for (const otp of otps) await ctx.db.delete(otp._id);

    const roles = await ctx.db
      .query("roles")
      .withIndex("by_project", (q) => q.eq("projectId", projectId))
      .collect();
    for (const role of roles) await ctx.db.delete(role._id);

    const files = await ctx.db
      .query("files")
      .withIndex("by_project", (q) => q.eq("projectId", projectId))
      .collect();
    for (const file of files) {
      try {
        await ctx.storage.delete(file.storageId);
      } catch {
        // blob may already be gone
      }
      await ctx.db.delete(file._id);
    }

    const usage = await ctx.db
      .query("usageDaily")
      .withIndex("by_project_day", (q) => q.eq("projectId", projectId))
      .collect();
    for (const u of usage) await ctx.db.delete(u._id);

    const events = await ctx.db
      .query("events")
      .withIndex("by_channel", (q) => q.eq("projectId", projectId))
      .collect();
    for (const event of events) await ctx.db.delete(event._id);

    await ctx.db.delete(projectId);
    return { status: "deleted" as const, name: project.name };
  },
});

/** Compact stats used by the dashboard overview. */
export const stats = query({
  args: { projectId: v.id("projects") },
  handler: async (ctx, args) => {
    await requireOwnedProject(ctx, args.projectId);
    const tables = await ctx.db
      .query("tables")
      .withIndex("by_project", (q) => q.eq("projectId", args.projectId))
      .collect();
    const files = await ctx.db
      .query("files")
      .withIndex("by_project", (q) => q.eq("projectId", args.projectId))
      .collect();
    const endUsers = await ctx.db
      .query("endUsers")
      .withIndex("by_project", (q) => q.eq("projectId", args.projectId))
      .collect();
    const keys = await ctx.db
      .query("apiKeys")
      .withIndex("by_project", (q) => q.eq("projectId", args.projectId))
      .collect();
    const project = await ctx.db.get(args.projectId);

    return {
      tables: tables.length,
      rows: tables.reduce((sum, t) => sum + t.rowCount, 0),
      files: files.length,
      endUsers: endUsers.length,
      activeKeys: keys.filter((k) => !k.revokedAt).length,
      storageBytes: project?.storageBytes ?? 0,
      storageLimitBytes: project?.storageLimitBytes ?? 0,
    };
  },
});
