import { v } from "convex/values";
import { requireOwnedProject } from "./lib/authz";
import { internalMutation, internalQuery, mutation, query } from "./_generated/server";

/** Create a session for an end user (called from the REST auth handlers). */
export const create = internalMutation({
  args: {
    projectId: v.id("projects"),
    endUserId: v.id("endUsers"),
    sid: v.string(),
    expiresAt: v.number(),
    userAgent: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    return await ctx.db.insert("sessions", {
      projectId: args.projectId,
      endUserId: args.endUserId,
      sid: args.sid,
      createdAt: Date.now(),
      expiresAt: args.expiresAt,
      userAgent: args.userAgent?.slice(0, 200),
    });
  },
});

/** Session lookup used during token verification. */
export const bySid = internalQuery({
  args: { projectId: v.id("projects"), sid: v.string() },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("sessions")
      .withIndex("by_sid", (q) =>
        q.eq("projectId", args.projectId).eq("sid", args.sid),
      )
      .first();
  },
});

export const revokeBySid = internalMutation({
  args: { projectId: v.id("projects"), sid: v.string() },
  handler: async (ctx, args) => {
    const session = await ctx.db
      .query("sessions")
      .withIndex("by_sid", (q) =>
        q.eq("projectId", args.projectId).eq("sid", args.sid),
      )
      .first();
    if (!session || session.revokedAt) return { status: "not_found" as const };
    await ctx.db.patch(session._id, { revokedAt: Date.now() });
    return { status: "revoked" as const };
  },
});

export const revokeAllForUser = internalMutation({
  args: { projectId: v.id("projects"), endUserId: v.id("endUsers") },
  handler: async (ctx, args) => {
    const sessions = await ctx.db
      .query("sessions")
      .withIndex("by_user", (q) =>
        q.eq("projectId", args.projectId).eq("endUserId", args.endUserId),
      )
      .collect();
    const now = Date.now();
    for (const session of sessions) {
      if (session.revokedAt) continue;
      await ctx.db.patch(session._id, { revokedAt: now });
    }
    return { status: "revoked" as const, count: sessions.length };
  },
});

// ---------------------------------------------------------------------------
// Dashboard functions (owner checked)
// ---------------------------------------------------------------------------

export const listForUser = query({
  args: { projectId: v.id("projects"), endUserId: v.id("endUsers") },
  handler: async (ctx, args) => {
    await requireOwnedProject(ctx, args.projectId);
    const sessions = await ctx.db
      .query("sessions")
      .withIndex("by_user", (q) =>
        q.eq("projectId", args.projectId).eq("endUserId", args.endUserId),
      )
      .collect();
    const now = Date.now();
    return sessions
      .sort((a, b) => b._creationTime - a._creationTime)
      .map((s) => ({
        id: s._id,
        createdAt: s._creationTime,
        expiresAt: s.expiresAt,
        revokedAt: s.revokedAt ?? null,
        active: !s.revokedAt && s.expiresAt > now,
        userAgent: s.userAgent ?? null,
      }));
  },
});

export const revoke = mutation({
  args: { projectId: v.id("projects"), sessionId: v.id("sessions") },
  handler: async (ctx, args) => {
    await requireOwnedProject(ctx, args.projectId);
    const session = await ctx.db.get(args.sessionId);
    if (!session || session.projectId !== args.projectId) {
      return { status: "not_found" as const };
    }
    await ctx.db.patch(args.sessionId, {
      revokedAt: session.revokedAt ?? Date.now(),
    });
    return { status: "revoked" as const };
  },
});