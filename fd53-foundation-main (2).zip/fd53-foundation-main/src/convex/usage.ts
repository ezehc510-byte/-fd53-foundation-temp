import { v } from "convex/values";
import { requireOwnedProject } from "./lib/authz";
import type { Id } from "./_generated/dataModel";
import {
  internalMutation,
  internalQuery,
  query,
  type QueryCtx,
} from "./_generated/server";

function utcDay(ts: number): string {
  return new Date(ts).toISOString().slice(0, 10);
}

/**
 * Rate limiting + usage accounting, run once per authenticated REST call.
 * Returns whether the request must be rejected with 429.
 */
export const consumeQuota = internalMutation({
  args: {
    keyId: v.id("apiKeys"),
    projectId: v.id("projects"),
    category: v.union(
      v.literal("auth"),
      v.literal("database"),
      v.literal("storage"),
      v.literal("realtime"),
      v.literal("social"),
      v.literal("marketplace"),
      v.literal("system"),
    ),
    limit: v.number(),
  },
  handler: async (ctx, args) => {
    const now = Date.now();
    const bucket = Math.floor(now / 60000);
    const resetAt = (bucket + 1) * 60000;

    // Drop stale buckets for this key (keep the previous minute for context).
    const stale = await ctx.db
      .query("rateBuckets")
      .withIndex("by_key_bucket", (q) =>
        q.eq("keyId", args.keyId).lt("bucket", bucket - 1),
      )
      .take(20);
    for (const old of stale) await ctx.db.delete(old._id);

    const existing = await ctx.db
      .query("rateBuckets")
      .withIndex("by_key_bucket", (q) =>
        q.eq("keyId", args.keyId).eq("bucket", bucket),
      )
      .first();

    const used = existing?.count ?? 0;
    if (used >= args.limit) {
      return {
        limited: true as const,
        remaining: 0,
        limit: args.limit,
        resetAt,
        retryAfterSeconds: (resetAt - now) / 1000,
      };
    }

    if (existing) await ctx.db.patch(existing._id, { count: used + 1 });
    else
      await ctx.db.insert("rateBuckets", {
        keyId: args.keyId,
        bucket,
        count: 1,
      });

    await ctx.db.patch(args.keyId, { lastUsedAt: now });

    const day = utcDay(now);
    const counter = await ctx.db
      .query("usageDaily")
      .withIndex("by_project_day_cat", (q) =>
        q
          .eq("projectId", args.projectId)
          .eq("day", day)
          .eq("category", args.category),
      )
      .first();
    if (counter) await ctx.db.patch(counter._id, { count: counter.count + 1 });
    else
      await ctx.db.insert("usageDaily", {
        projectId: args.projectId,
        day,
        category: args.category,
        count: 1,
        errorCount: 0,
      });

    return {
      limited: false as const,
      remaining: Math.max(0, args.limit - used - 1),
      limit: args.limit,
      resetAt,
      retryAfterSeconds: 0,
    };
  },
});

/** Count a failed request against the day's error counter. */
export const recordError = internalMutation({
  args: {
    projectId: v.id("projects"),
    category: v.union(
      v.literal("auth"),
      v.literal("database"),
      v.literal("storage"),
      v.literal("realtime"),
      v.literal("social"),
      v.literal("marketplace"),
      v.literal("system"),
    ),
  },
  handler: async (ctx, args) => {
    const day = utcDay(Date.now());
    const counter = await ctx.db
      .query("usageDaily")
      .withIndex("by_project_day_cat", (q) =>
        q
          .eq("projectId", args.projectId)
          .eq("day", day)
          .eq("category", args.category),
      )
      .first();
    if (counter) {
      await ctx.db.patch(counter._id, { errorCount: counter.errorCount + 1 });
    } else {
      await ctx.db.insert("usageDaily", {
        projectId: args.projectId,
        day,
        category: args.category,
        count: 0,
        errorCount: 1,
      });
    }
    return { status: "ok" as const };
  },
});

// ---------------------------------------------------------------------------
// Summaries
// ---------------------------------------------------------------------------

async function computeSummary(
  ctx: QueryCtx,
  projectId: Id<"projects">,
  days: number,
) {
  const today = Date.now();
  const dayList: string[] = [];
  for (let i = days - 1; i >= 0; i--) {
    dayList.push(utcDay(today - i * 24 * 60 * 60 * 1000));
  }

  const counters = await ctx.db
    .query("usageDaily")
    .withIndex("by_project_day", (q) =>
      q.eq("projectId", projectId).gte("day", dayList[0] ?? utcDay(today)),
    )
    .collect();

  const daily = dayList.map((day) => {
    const rows = counters.filter((c) => c.day === day);
    const byCategory: Record<string, number> = {};
    let requests = 0;
    let errors = 0;
    for (const row of rows) {
      byCategory[row.category] = (byCategory[row.category] ?? 0) + row.count;
      requests += row.count;
      errors += row.errorCount;
    }
    return { day, requests, errors, byCategory };
  });

  const categoryTotals: Record<string, number> = {};
  for (const row of counters) {
    categoryTotals[row.category] = (categoryTotals[row.category] ?? 0) + row.count;
  }

  return {
    daily,
    categoryTotals,
    totals: {
      requests: daily.reduce((sum, d) => sum + d.requests, 0),
      errors: daily.reduce((sum, d) => sum + d.errors, 0),
    },
  };
}

export const summary = query({
  args: { projectId: v.id("projects"), days: v.optional(v.number()) },
  handler: async (ctx, args) => {
    await requireOwnedProject(ctx, args.projectId);
    return await computeSummary(ctx, args.projectId, Math.min(Math.max(1, args.days ?? 14), 90));
  },
});

export const summaryForApi = internalQuery({
  args: { projectId: v.id("projects"), days: v.optional(v.number()) },
  handler: async (ctx, args) =>
    await computeSummary(ctx, args.projectId, Math.min(Math.max(1, args.days ?? 14), 90)),
});