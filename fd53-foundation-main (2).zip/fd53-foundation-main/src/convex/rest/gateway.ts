/**
 * FD53 API Gateway — the single entry point for every `/v1` request.
 *
 * This is the platform's outermost security boundary. Nothing reaches a
 * handler without passing through these stages, in this order:
 *
 *   1. Correlation      assign/propagate `X-FD53-Request-Id`
 *   2. Fingerprint      extract client IP (hash it) + user agent
 *   3. WAF              reject traversal / injection / oversized requests
 *   4. Origin           resolve CORS against the caller's key allowlist
 *   5. Edge throttle    per-IP flood limit — BEFORE any database read
 *   6. API key          format → lookup → revoked → expired → env → IP → scope
 *   7. Project          suspended-project check
 *   8. Quota            per-key rate limit + daily usage accounting
 *   9. Dispatch         invoke the route handler
 *  10. Decorate         security headers, `Server-Timing`, audit + request log
 *
 * Design rules:
 *  - Stages 1–5 run before authentication on purpose. A flood from an
 *    anonymous client must never reach the database or a handler.
 *  - Every failure is audited with a machine-readable event name.
 *  - Nothing in this file throws: it converts exceptions to HTTP responses so
 *    internal details never leak to a client.
 */
import type { ActionCtx } from "../_generated/server";
import { internal } from "../_generated/api";
import { FD53_VERSION, FREE_PLAN } from "../lib/constants";
import { sha256Hex, randomHex, decodeTokenSubject } from "../lib/crypto";
import {
  evaluateIpPolicy,
  extractClientIp,
  inspectRequest,
  parseApiKey,
  resolveAllowedOrigin,
} from "../lib/net";
import {
  HttpError,
  corsHeaders,
  enforceQuota,
  fail,
  presentedKey,
  recordError,
  type Principal,
  type UsageCategory,
} from "../lib/rest";
import type { RequestContext, RestContext, RestRoute } from "./types";

// ---------------------------------------------------------------------------
// Headers and helpers
// ---------------------------------------------------------------------------

/** Public documentation for the current API version, surfaced in headers. */
export const API_DOCS_URL = "https://docs.fd53.dev/v1";

/** Accepted `X-FD53-Version` values. */
export const SUPPORTED_API_VERSIONS = ["2024-01-01", "2024-06-01"] as const;

/**
 * Security headers applied to every response.
 *
 * `Cache-Control: no-store` matters here: an API response can contain
 * end-user records, and a shared proxy cache must never retain it.
 */
function securityHeaders(
  requestId: string,
  apiVersion: string,
): Record<string, string> {
  return {
    "X-FD53-Request-Id": requestId,
    "X-FD53-Version": FD53_VERSION,
    "X-FD53-Api-Version": apiVersion,
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "Referrer-Policy": "no-referrer",
    "Strict-Transport-Security": "max-age=31536000; includeSubDomains",
    "Cache-Control": "no-store",
    "Content-Security-Policy": "default-src 'none'",
  };
}

/** Resolve the requested API version from a header or query param. */
function resolveApiVersion(request: Request, url: URL): string {
  return (
    request.headers.get("x-fd53-api-version") ??
    url.searchParams.get("apiVersion") ??
    SUPPORTED_API_VERSIONS[SUPPORTED_API_VERSIONS.length - 1]
  );
}

/** Best-effort audit write — never allowed to affect the response. */
async function audit(
  ctx: ActionCtx,
  rc: RequestContext,
  event: string,
  outcome: "success" | "failure" | "blocked",
  detail?: string,
  principal?: Principal,
): Promise<void> {
  try {
    await ctx.runMutation(internal.audit.record, {
      event,
      outcome,
      projectId: principal?.project._id,
      apiKeyId: principal?.key._id,
      method: rc.method,
      path: rc.path,
      ipHash: rc.ipHash,
      userAgent: rc.userAgent,
      requestId: rc.requestId,
      detail: detail?.slice(0, 500),
    });
  } catch {
    // Audit logging must never break the request path.
  }
}

/**
 * Hash a client IP for logs and audit rows.
 *
 * Raw IPs are never persisted: an audit trail full of customer IP addresses is
 * a privacy liability, and a stable pseudonymous id is all the abuse
 * investigation actually needs.
 */
async function hashIp(ip: string | undefined): Promise<string | undefined> {
  if (!ip) return undefined;
  return (await sha256Hex(`fd53-ip:${ip}`)).slice(0, 32);
}

// ---------------------------------------------------------------------------
// Stage 3/4: WAF + origin
// ---------------------------------------------------------------------------

/** Build the CORS header set for this request, honouring the key allowlist. */
function buildCorsHeaders(
  request: Request,
  keyOrigins: string[] | undefined,
): Record<string, string> {
  const origin = request.headers.get("origin") ?? undefined;
  const { allowOrigin } = resolveAllowedOrigin(origin, keyOrigins, "*");
  return {
    ...corsHeaders(),
    ...(allowOrigin ? { "Access-Control-Allow-Origin": allowOrigin } : {}),
    // Tells caches the response varies per origin, so one project's CORS
    // decision can never be served to another project.
    Vary: "Origin",
  };
}

/**
 * Resolve CORS headers before the key is known (preflight / rejected calls).
 * Without a validated key we cannot honour a per-key allowlist, so we fall
 * back to the platform default and let the real decision happen later.
 */
function defaultCorsHeaders(request: Request): Record<string, string> {
  return buildCorsHeaders(request, undefined);
}

// ---------------------------------------------------------------------------
// Stage 5: edge throttle
// ---------------------------------------------------------------------------

/**
 * Per-IP flood limit, applied before authentication.
 *
 * This is what makes FD53 resistant to a volumetric flood: the request is
 * rejected on a single counter read and never touches `apiKeys`, never burns
 * the caller's project quota, and never reaches a handler.
 */
async function enforceEdgeLimit(
  ctx: ActionCtx,
  rc: RequestContext,
): Promise<void> {
  if (!rc.ipHash) return;
  const result = await ctx.runMutation(internal.edge.hitIp, {
    scope: `ip:${rc.ipHash}`,
  });
  if (result.allowed) return;
  throw new HttpError(
    429,
    "rate_limited",
    "Too many requests from this network. Slow down and retry shortly.",
    {
      "Retry-After": String(result.retryAfterSeconds),
      "X-RateLimit-Limit": String(result.limit),
      "X-RateLimit-Remaining": "0",
      "X-RateLimit-Reset": String(result.resetAt),
    },
  );
}

/**
 * Count a failed authentication and ban the source when it is clearly abusive.
 *
 * Keyed by IP, not by key: a spray of fabricated keys must not be able to
 * exhaust any real project's quota, and it must be stoppable.
 */
async function recordAuthFailure(
  ctx: ActionCtx,
  rc: RequestContext,
  detail: string,
): Promise<boolean> {
  if (!rc.ipHash) return false;
  try {
    const result = await ctx.runMutation(internal.edge.hitAuthFailure, {
      scope: `auth_fail:${rc.ipHash}`,
    });
    await audit(ctx, rc, "auth.failed", "failure", detail);
    return !result.allowed;
  } catch {
    return false;
  }
}

// ---------------------------------------------------------------------------
// Stage 6: API key validation (the X-API-Key middleware)
// ---------------------------------------------------------------------------

export type KeyFailure = {
  status: number;
  code: string;
  message: string;
  /** Extra headers, e.g. `WWW-Authenticate` or `Retry-After`. */
  headers?: Record<string, string>;
};

/**
 * Validate the credential presented in `X-API-Key`.
 *
 * Checks run cheapest-first so a scanner spraying garbage costs one string
 * comparison, not a database read:
 *
 *   1. present?          → 401 `missing_api_key`
 *   2. well-formed?      → 401 `invalid_api_key`   (no DB hit)
 *   3. known hash?       → 401 `invalid_api_key`
 *   4. revoked?          → 401 `key_revoked`
 *   5. past expiry?      → 401 `key_expired`
 *   6. environment match?→ 401 `key_environment_mismatch`
 *   7. project exists?   → 401 `invalid_api_key`
 *   8. project active?   → 403 `project_suspended`
 *   9. IP policy?        → 403 `ip_not_allowed`
 *  10. scope?            → 403 `insufficient_scope`
 *
 * Every failure returns a distinct code so a developer can tell a typo from a
 * revoked key from an IP restriction without opening the logs.
 */
export async function authenticateApiKey(
  ctx: ActionCtx,
  request: Request,
  scope: string,
  rc: RequestContext,
): Promise<{ ok: true; principal: Principal } | { ok: false; failure: KeyFailure }> {
  const raw = presentedKey(request);
  if (!raw) {
    return {
      ok: false,
      failure: {
        status: 401,
        code: "missing_api_key",
        message:
          'Provide your FD53 API key via the "X-API-Key" header (or "Authorization: Bearer fd53_live_…").',
        headers: { "WWW-Authenticate": 'ApiKey realm="FD53"' },
      },
    };
  }

  // (2) Shape check before any I/O.
  const parsed = parseApiKey(raw);
  if (!parsed) {
    const banned = await recordAuthFailure(ctx, rc, "malformed_api_key");
    return {
      ok: false,
      failure: banned
        ? {
            status: 429,
            code: "ip_blocked",
            message:
              "Too many failed authentications from this network. Try again later.",
            headers: { "Retry-After": "900" },
          }
        : {
            status: 401,
            code: "invalid_api_key",
            message:
              "That API key is malformed. Keys look like fd53_live_<40 hex characters>.",
          },
    };
  }

  // (3) Constant-time-by-hash lookup: we store sha256(key), never the key.
  const key = await ctx.runQuery(internal.apiKeys.byHash, {
    hash: await sha256Hex(raw.trim()),
  });

  if (!key) {
    const banned = await recordAuthFailure(ctx, rc, "unknown_api_key");
    return {
      ok: false,
      failure: banned
        ? {
            status: 429,
            code: "ip_blocked",
            message:
              "Too many failed authentications from this network. Try again later.",
            headers: { "Retry-After": "900" },
          }
        : {
            status: 401,
            code: "invalid_api_key",
            message: "This API key is not recognised.",
          },
    };
  }

  // (4)
  if (key.revokedAt) {
    return {
      ok: false,
      failure: {
        status: 401,
        code: "key_revoked",
        message:
          "This API key was revoked. Create a new key in the FD53 dashboard.",
      },
    };
  }

  // (5)
  if (key.expiresAt !== undefined && key.expiresAt <= Date.now()) {
    await audit(ctx, rc, "key.expired", "blocked", key._id, undefined);
    return {
      ok: false,
      failure: {
        status: 401,
        code: "key_expired",
        message: "This API key has expired. Rotate it in the FD53 dashboard.",
      },
    };
  }

  // (6) A key minted as `test` must never be usable where `live` is implied.
  //    This blocks promoting a sandbox key into production by accident.
  if (key.environment && key.environment !== parsed.environment) {
    await audit(
      ctx,
      rc,
      "auth.failed",
      "failure",
      `environment_mismatch:${key.environment}`,
    );
    return {
      ok: false,
      failure: {
        status: 401,
        code: "key_environment_mismatch",
        message: "The API key environment does not match the requested environment.",
      },
    };
  }

  // (7)
  const project = await ctx.runQuery(internal.projects.byId, { id: key.projectId });
  if (!project) {
    return {
      ok: false,
      failure: {
        status: 401,
        code: "invalid_api_key",
        message: "The project for this key no longer exists.",
      },
    };
  }

  // (8)
  if (project.status !== "active") {
    return {
      ok: false,
      failure: {
        status: 403,
        code: "project_suspended",
        message:
          "This project is suspended. Check billing status in the FD53 dashboard.",
      },
    };
  }

  // (9)
  const ipPolicy = evaluateIpPolicy(rc.ip, key.allowedIps, key.blockedIps);
  if (!ipPolicy.allowed) {
    await audit(ctx, rc, "ip.blocked", "blocked", ipPolicy.reason);
    return {
      ok: false,
      failure: {
        status: 403,
        code: "ip_not_allowed",
        message: ipPolicy.reason ?? "This API key cannot be used from your network.",
      },
    };
  }

  // (10) An empty scope list means "all scopes".
  if (
    scope &&
    key.scopes.length > 0 &&
    !key.scopes.includes("*") &&
    !key.scopes.includes(scope)
  ) {
    await audit(ctx, rc, "scope.denied", "blocked", `scope:${scope}`);
    return {
      ok: false,
      failure: {
        status: 403,
        code: "insufficient_scope",
        message: `This API key is not allowed to use the "${scope}" scope.`,
      },
    };
  }

  const principal: Principal = { project, key };
  rc.principal = principal;
  return { ok: true, principal };
}

// ---------------------------------------------------------------------------
// The pipeline
// ---------------------------------------------------------------------------

/** CORS preflight response. */
export function preflight(request: Request): Response {
  const requestId = request.headers.get("x-fd53-request-id") ?? randomHex(8);
  const apiVersion = request.headers.get("x-fd53-api-version") ?? "";
  return new Response(null, {
    status: 204,
    headers: {
      ...defaultCorsHeaders(request),
      ...securityHeaders(requestId, apiVersion || SUPPORTED_API_VERSIONS[SUPPORTED_API_VERSIONS.length - 1]),
      "Access-Control-Max-Age": "86400",
    },
  });
}

export type GatewayArgs = {
  ctx: ActionCtx;
  request: Request;
  method: string;
  /** Called once the request has passed every gate. */
  dispatch: (rest: RestContext) => Promise<Response> | Response;
  /** Route metadata used for logging and quota accounting. */
  route: { label: string; scope: string; category: UsageCategory };
};

/**
 * Run the full gateway pipeline and return the final HTTP response.
 *
 * Never throws: every failure becomes a structured JSON error with the
 * gateway's security headers attached.
 */
export async function runGateway(args: GatewayArgs): Promise<Response> {
  const { ctx, request, method, dispatch, route } = args;
  const url = new URL(request.url);
  const apiVersion = resolveApiVersion(request, url);

  // Stage 1 — correlation. Honour an inbound id so a trace survives across
  // services, but bound it so a client cannot inject megabytes into our logs.
  const inboundId = request.headers.get("x-fd53-request-id");
  const requestId =
    inboundId && /^[A-Za-z0-9_-]{8,64}$/.test(inboundId)
      ? inboundId
      : randomHex(12);

  // Stage 2 — fingerprint.
  const ip = extractClientIp(request.headers);
  const rc: RequestContext = {
    requestId,
    ip,
    ipHash: await hashIp(ip),
    userAgent: request.headers.get("user-agent")?.slice(0, 200) ?? undefined,
    routeLabel: route.label,
    method,
    path: url.pathname,
    startedAt: Date.now(),
  };

  const finish = (
    response: Response,
    extraHeaders: Record<string, string> = {},
  ): Response => {
    const headers = new Headers(response.headers);
    for (const [name, value] of Object.entries({
      ...securityHeaders(requestId, apiVersion),
      ...extraHeaders,
    })) {
      headers.set(name, value);
    }
    headers.set("Server-Timing", `app;dur=${Date.now() - rc.startedAt}`);
    return new Response(response.body, {
      status: response.status,
      statusText: response.statusText,
      headers,
    });
  };

  // Stage 3 — WAF.
  const verdict = inspectRequest(request);
  if (verdict.action === "block") {
    await audit(ctx, rc, "waf.blocked", "blocked", verdict.detail);
    return finish(
      fail(403, "blocked_by_waf", verdict.detail, defaultCorsHeaders(request)),
      { "X-FD53-Rule": verdict.rule },
    );
  }

  // Stage 4/5 — origin + edge throttle, both before any credential work.
  const blocked = async (error: HttpError): Promise<Response> => {
    await audit(ctx, rc, "rate_limited", "blocked", error.code);
    return finish(
      fail(error.status, error.code, error.message, {
        ...defaultCorsHeaders(request),
        ...error.headers,
      }),
    );
  };

  try {
    await enforceEdgeLimit(ctx, rc);
  } catch (error) {
    if (error instanceof HttpError) return await blocked(error);
    throw error;
  }

  // Stage 6–8 — credential, project and quota checks.
  let principal: Principal | null = null;
  if (route.scope) {
    const result = await authenticateApiKey(ctx, request, route.scope, rc);
    if (!result.ok) {
      await audit(ctx, rc, "auth.failed", "failure", result.failure.code);
      return finish(
        fail(result.failure.status, result.failure.code, result.failure.message, {
          ...defaultCorsHeaders(request),
          ...(result.failure.headers ?? {}),
        }),
      );
    }
    principal = result.principal;
  }

  // The key's origin allowlist is only trustworthy now that it is validated.
  const cors = principal
    ? buildCorsHeaders(request, principal.key.allowedOrigins)
    : defaultCorsHeaders(request);

  const requestOrigin = request.headers.get("origin");
  if (
    principal?.key.allowedOrigins &&
    principal.key.allowedOrigins.length > 0 &&
    requestOrigin &&
    !cors["Access-Control-Allow-Origin"]
  ) {
    await audit(ctx, rc, "cors.blocked", "blocked", requestOrigin);
    return finish(
      fail(
        403,
        "origin_not_allowed",
        "This API key is not permitted to be called from this origin.",
        cors,
      ),
    );
  }

  // Key usage bookkeeping — never allowed to fail a request.
  if (principal) {
    try {
      await ctx.runMutation(internal.apiKeys.touch, { id: principal.key._id });
    } catch {
      // best effort
    }
  }

  if (principal) {
    try {
      await enforceQuota(ctx, principal, route.category);
    } catch (error) {
      if (error instanceof HttpError) {
        return finish(
          fail(error.status, error.code, error.message, {
            ...cors,
            ...error.headers,
          }),
        );
      }
      throw error;
    }
  }

  // Stage 9 — dispatch.
  let response: Response;
  try {
    response = await dispatch({
      principal: principal as Principal,
      request,
      params: {},
      query: url.searchParams,
    });
  } catch (error) {
    await recordError(ctx, principal, route.category);
    if (error instanceof HttpError) {
      response = fail(error.status, error.code, error.message, {
        ...cors,
        ...error.headers,
      });
    } else {
      // Log internally, return nothing sensitive externally.
      console.error(
        `FD53 ${rc.requestId} ${method} ${rc.path} failed`,
        error,
      );
      await audit(
        ctx,
        rc,
        "auth.failed",
        "failure",
        `handler_error:${error instanceof Error ? error.name : "unknown"}`,
        principal ?? undefined,
      );
      response = fail(
        500,
        "internal_error",
        "FD53 could not complete this request. Quote the request id when reporting it.",
      );
    }
  }

  if (response.status >= 400) {
    await recordError(ctx, principal, route.category);
  }

  // Stage 10 — request log + response decoration.
  if (principal) {
    try {
      const auth = request.headers.get("authorization");
      const subject = auth ? decodeTokenSubject(auth) : undefined;
      await ctx.runMutation(internal.requestLog.record, {
        projectId: principal.project._id,
        apiKeyId: principal.key._id,
        method,
        path: rc.path,
        route: route.label,
        category: route.category,
        status: response.status,
        durationMs: Date.now() - rc.startedAt,
        requestId,
        endUserId: subject as never,
      });
    } catch {
      // logging must never break the request
    }
  }

  return finish(response, {
    "X-RateLimit-Limit": String(
      principal ? Math.min(principal.key.rateLimit, principal.project.requestsPerMinute) : FREE_PLAN.requestsPerMinute,
    ),
    "X-FD53-Docs": API_DOCS_URL,
  });
}