/**
 * FD53 Realtime REST API.
 *
 * Events are published over REST and delivered live to the dashboard through
 * Convex reactive queries. Clients (FlutterFlow/native) can poll
 * `GET /v1/realtime/channels/:channel/events` or subscribe directly with the
 * Convex client — see the Docs page.
 */
import type { ActionCtx } from "../_generated/server";
import { internal } from "../_generated/api";
import { HttpError, hasPermission, maybeEndUser, ok, readJson, str } from "../lib/rest";
import type { RestContext } from "./types";

export async function publish(ctx: ActionCtx, c: RestContext): Promise<Response> {
  const projectId = c.principal.project._id;
  const body = await readJson(c.request);
  const channel = str(body, "channel", { required: true })!;
  const type = str(body, "type", { required: true })!;
  const sender = str(body, "sender", { max: 120 });

  // When an end-user token is present it must carry realtime:publish.
  const endUser = await maybeEndUser(ctx, c.request, projectId);
  if (endUser && !hasPermission(endUser, "realtime:publish")) {
    throw new HttpError(
      403,
      "forbidden",
      'Your role needs the "realtime:publish" permission.',
    );
  }

  const result = await ctx.runMutation(internal.realtime.publish, {
    projectId,
    channel,
    type,
    payload: body.payload,
    sender: sender ?? endUser?.user._id,
  });

  if (result.status !== "published") {
    throw new HttpError(400, "invalid_event", result.message);
  }
  return ok({
    event: {
      id: result.event._id,
      channel: result.event.channel,
      type: result.event.type,
      payload: result.event.payload ?? null,
      createdAt: result.event._creationTime,
    },
  });
}

export async function listChannels(ctx: ActionCtx, c: RestContext): Promise<Response> {
  const channels = await ctx.runQuery(internal.realtime.channelsForApi, {
    projectId: c.principal.project._id,
  });
  return ok({ channels });
}

export async function listEvents(ctx: ActionCtx, c: RestContext): Promise<Response> {
  const events = await ctx.runQuery(internal.realtime.eventsForApi, {
    projectId: c.principal.project._id,
    channel: c.params.channel,
    limit: c.query.get("limit") ? Number(c.query.get("limit")) : undefined,
  });
  return ok({
    channel: c.params.channel,
    events: events.map((event) => ({
      id: event._id,
      type: event.type,
      payload: event.payload ?? null,
      sender: event.sender ?? null,
      createdAt: event._creationTime,
    })),
  });
}