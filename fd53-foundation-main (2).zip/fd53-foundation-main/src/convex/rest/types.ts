/**
 * Shared REST types.
 */
import type { ActionCtx } from "../_generated/server";
import type { Principal } from "../lib/rest";

/** Everything a REST handler needs about the current request. */
export type RestContext = {
  principal: Principal;
  request: Request;
  /** Path parameters captured from the route pattern (`:table` → `{table}`). */
  params: Record<string, string>;
  /** Parsed query string. */
  query: URLSearchParams;
};

export type RestHandler = (
  ctx: ActionCtx,
  c: RestContext,
) => Promise<Response> | Response;

/**
 * One entry in the route table. `segments` uses `:name` to mark a captured
 * parameter; `scope` is the API-key scope required, or "" for a public route.
 */
export type RestRoute = {
  method: string;
  segments: string[];
  scope: string;
  category: string;
  handler: RestHandler;
  /** Human summary used by the OpenAPI generator and the docs page. */
  summary?: string;
  /** Longer description used by the OpenAPI generator. */
  description?: string;
  /** OpenAPI tags. Defaults to the route's category. */
  tags?: string[];
};

/** Per-request metadata the gateway attaches and propagates. */
export type RequestContext = {
  /** Correlation id, echoed as `X-FD53-Request-Id`. */
  requestId: string;
  /** Client IP, or undefined when no proxy header carried one. */
  ip?: string;
  /** SHA-256 of the client IP. Raw IPs are never stored or logged. */
  ipHash?: string;
  userAgent?: string;
  /** Present once the API key has been resolved. */
  principal?: Principal;
  /** Route label used in logs, e.g. "/v1/db/:table". */
  routeLabel: string;
  method: string;
  path: string;
  startedAt: number;
};