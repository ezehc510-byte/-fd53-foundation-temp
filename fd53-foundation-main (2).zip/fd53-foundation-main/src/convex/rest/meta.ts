/** Platform metadata + usage reporting endpoints. */
import type { ActionCtx } from "../_generated/server";
import { internal } from "../_generated/api";
import {
  FD53_NAME,
  FD53_VERSION,
  FREE_PLAN,
  STORAGE_BUCKET_LIST,
} from "../lib/constants";
import { ok, json } from "../lib/rest";
import { openapiDocument } from "./openapi";
import type { RestContext } from "./types";

/** GET /v1/openapi.json — the machine-readable API spec (no API key needed). */
export function openapi(_ctx: ActionCtx, c: RestContext) {
  const origin = new URL(c.request.url).origin;
  return json(openapiDocument(`${origin}/v1`), 200, {
    "Cache-Control": "public, max-age=300",
  });
}

/** GET /v1/health — no API key required. */
export function health(request: Request) {
  return ok({
    name: FD53_NAME,
    version: FD53_VERSION,
    status: "operational",
    serverTime: new Date().toISOString(),
    baseUrl: `${new URL(request.url).origin}/v1`,
  });
}

/** GET /v1 — service + endpoint index. */
export function root(request: Request) {
  const origin = new URL(request.url).origin;
  return ok({
    name: FD53_NAME,
    version: FD53_VERSION,
    description:
      "FD53 — your backend-as-a-service: auth, database, storage, realtime and an API platform, with the LoopUni social + marketplace schema included.",
    docs: `${origin}/dashboard/docs`,
    openapi: `${origin}/v1/openapi.json`,
    endpoints: {
      auth: [
        "POST /v1/auth/register",
        "POST /v1/auth/login",
        "POST /v1/auth/otp/request",
        "POST /v1/auth/otp/verify",
        "GET  /v1/auth/me",
        "POST /v1/auth/logout",
        "POST /v1/auth/token/verify",
        "POST /v1/auth/password",
        "POST /v1/auth/password/reset",
        "POST /v1/auth/password/reset/confirm",
        "GET  /v1/auth/roles",
      ],
      database: [
        "GET    /v1/db/tables",
        "POST   /v1/db/tables",
        "GET    /v1/db/tables/:table",
        "PATCH  /v1/db/tables/:table",
        "DELETE /v1/db/tables/:table",
        "GET    /v1/db/:table",
        "POST   /v1/db/:table",
        "GET    /v1/db/:table/:rowId",
        "PATCH  /v1/db/:table/:rowId",
        "DELETE /v1/db/:table/:rowId",
      ],
      storage: [
        "GET    /v1/storage/buckets",
        "POST   /v1/storage/upload",
        "GET    /v1/storage/files",
        "GET    /v1/storage/files/:fileId",
        "DELETE /v1/storage/files/:fileId",
      ],
      realtime: [
        "POST /v1/realtime/publish",
        "GET  /v1/realtime/channels",
        "GET  /v1/realtime/channels/:channel/events",
      ],
      social: [
        "GET  /v1/users/profile/:username",
        "POST /v1/users/:id/follow",
        "POST /v1/users/:id/unfollow",
        "POST /v1/posts/create",
        "GET  /v1/posts/:id",
        "GET  /v1/feed/home",
        "POST /v1/messages/send",
        "GET  /v1/messages/:roomId",
        "POST /v1/reports/create",
      ],
      marketplace: [
        "POST /v1/marketplace/products",
        "GET  /v1/marketplace/products",
        "GET  /v1/marketplace/products/:id",
        "POST /v1/marketplace/orders/checkout",
        "GET  /v1/marketplace/orders",
        "GET  /v1/marketplace/earnings",
      ],
      storageBuckets: STORAGE_BUCKET_LIST.map((bucket) => ({
        name: bucket.name,
        visibility: bucket.visibility,
        description: bucket.description,
      })),
      system: ["GET /v1/health", "GET /v1/usage", "GET /v1/openapi.json"],
    },
  });
}

/** GET /v1/usage — usage + limits for the calling key's project. */
export async function usage(ctx: ActionCtx, c: RestContext) {
  const days = c.query.get("days") ? Number(c.query.get("days")) : 14;
  const summary = await ctx.runQuery(internal.usage.summaryForApi, {
    projectId: c.principal.project._id,
    days: Number.isFinite(days) ? days : 14,
  });
  return ok({
    project: {
      name: c.principal.project.name,
      slug: c.principal.project.slug,
      plan: c.principal.project.plan,
    },
    limits: {
      requestsPerMinute: c.principal.project.requestsPerMinute,
      keyRateLimit: c.principal.key.rateLimit,
      storageLimitBytes: c.principal.project.storageLimitBytes,
      storageUsedBytes: c.principal.project.storageBytes,
      maxUploadBytes: FREE_PLAN.maxUploadBytes,
      maxRowsPerPage: FREE_PLAN.maxRowsPerPage,
    },
    totals: summary.totals,
    categoryTotals: summary.categoryTotals,
    daily: summary.daily,
  });
}