/**
 * LoopUni marketplace REST API.
 *
 * Creating a listing and checking out both act on a signed-in end user, so
 * they require a bearer token and run the per-user anti-spam limiter. Money
 * is always in minor units (cents) and the platform fee is computed
 * server-side — the client never sends an amount for the seller to receive.
 */
import type { ActionCtx } from "../_generated/server";
import type { Id } from "../_generated/dataModel";
import { internal } from "../_generated/api";
import {
  HttpError,
  enforceAntiSpam,
  json,
  ok,
  readJson,
  runOrNotFound,
  str,
} from "../lib/rest";
import { assertId, requireActor } from "./actor";
import type { RestContext } from "./types";

function shapeProduct(product: {
  _id: Id<"products">;
  sellerId: Id<"users">;
  title: string;
  description?: string;
  priceCents: number;
  currency: string;
  category?: string;
  kind: string;
  status: string;
  mediaIds?: Id<"media">[];
  inventory?: number;
  salesCount: number;
  _creationTime: number;
}) {
  return {
    id: product._id,
    sellerId: product.sellerId,
    title: product.title,
    description: product.description ?? null,
    priceCents: product.priceCents,
    currency: product.currency,
    category: product.category ?? null,
    kind: product.kind,
    status: product.status,
    mediaIds: product.mediaIds ?? [],
    inventory: product.inventory ?? null,
    salesCount: product.salesCount,
    // Digital assets are only downloadable after a paid order.
    hasAsset: Boolean(product.kind === "digital"),
    createdAt: product._creationTime,
  };
}

function shapeOrder(order: {
  _id: Id<"orders">;
  productId: Id<"products">;
  buyerId: Id<"users">;
  sellerId: Id<"users">;
  quantity: number;
  amountCents: number;
  platformFeeCents: number;
  currency: string;
  status: string;
  receiptFileId?: Id<"files">;
  paymentRef?: string;
  purchasedAt?: number;
  _creationTime: number;
}) {
  return {
    id: order._id,
    productId: order.productId,
    buyerId: order.buyerId,
    sellerId: order.sellerId,
    quantity: order.quantity,
    amountCents: order.amountCents,
    platformFeeCents: order.platformFeeCents,
    currency: order.currency,
    status: order.status,
    receiptFileId: order.receiptFileId ?? null,
    paymentRef: order.paymentRef ?? null,
    purchasedAt: order.purchasedAt ?? order._creationTime,
  };
}

function intParam(
  body: Record<string, unknown>,
  field: string,
  fallback: number,
): number {
  const value = body[field];
  if (value === undefined || value === null || value === "") return fallback;
  const parsed = typeof value === "number" ? value : Number(value);
  if (!Number.isFinite(parsed) || !Number.isInteger(parsed)) {
    throw new HttpError(400, "invalid_field", `"${field}" must be an integer.`);
  }
  return parsed;
}

function numberParam(value: string | null, fallback: number, max: number): number {
  if (value === null || value === "") return fallback;
  const parsed = Number(value);
  if (!Number.isFinite(parsed) || parsed < 1) {
    throw new HttpError(400, "invalid_pagination", "limit must be a number ≥ 1.");
  }
  return Math.min(Math.floor(parsed), max);
}

// ---------------------------------------------------------------------------
// POST /v1/marketplace/products
// ---------------------------------------------------------------------------

export async function createProduct(ctx: ActionCtx, c: RestContext): Promise<Response> {
  const projectId = c.principal.project._id;
  const actor = await requireActor(ctx, c);
  const body = await readJson(c.request);

  const title = str(body, "title", { required: true, max: 140 })!.trim();
  const priceCents = intParam(body, "priceCents", -1);
  if (priceCents < 0) {
    throw new HttpError(
      400,
      "missing_field",
      '"priceCents" is required (integer ≥ 0, e.g. 499 for $4.99).',
    );
  }
  const kind = body.kind === "physical" ? "physical" : "digital";
  const status = body.status === "draft" ? "draft" : "active";
  const mediaIds = Array.isArray(body.mediaIds) ? (body.mediaIds as string[]) : [];
  const assetFileId = str(body, "assetFileId", { max: 64 });
  // Validate id shape before it crosses into a mutation: Convex checks
  // v.id(...) arguments before the function body runs, so a bad id would
  // otherwise throw out of the call and surface as a 500.
  for (const id of mediaIds) assertId(id, "mediaIds");
  if (assetFileId) assertId(assetFileId, "assetFileId");

  await enforceAntiSpam(ctx, projectId, "product", actor.userId);
  const result = await runOrNotFound(
    () =>
      ctx.runMutation(internal.marketplace.createProduct, {
        projectId,
        sellerId: actor.userId,
        title,
        description: str(body, "description", { max: 4000 }),
        priceCents,
        currency: str(body, "currency", { max: 8 }) ?? "usd",
        category: str(body, "category", { max: 40 }),
        kind,
        status,
        mediaIds: mediaIds as Id<"media">[],
        assetFileId: assetFileId as Id<"files"> | undefined,
        inventory:
          body.inventory === undefined ? undefined : intParam(body, "inventory", 0),
      }),
    400,
    "invalid_product",
    "One of mediaIds / assetFileId is not a valid id.",
  );

  if (result.status === "invalid") {
    throw new HttpError(400, "invalid_product", result.message);
  }

  const product = await ctx.runQuery(internal.marketplace.productById, {
    projectId,
    productId: result.productId,
  });
  if (!product) throw new HttpError(500, "internal_error", "Product was not saved.");

  return json(
    {
      ok: true,
      data: {
        product: shapeProduct(product),
        seller: {
          userId: actor.userId,
          handle: actor.profile.handle,
          isCreator: true,
        },
      },
    },
    201,
  );
}

// ---------------------------------------------------------------------------
// GET /v1/marketplace/products
// ---------------------------------------------------------------------------

export async function listProducts(ctx: ActionCtx, c: RestContext): Promise<Response> {
  const projectId = c.principal.project._id;
  const limit = numberParam(c.query.get("limit"), 20, 50);
  const seller = c.query.get("seller");

  let sellerId: Id<"users"> | undefined;
  if (seller) {
    const handle = seller.replace(/^@/, "").toLowerCase();
    const profile = await ctx.runQuery(internal.identity.profileByHandle, {
      projectId,
      handleLower: handle,
    });
    if (!profile) {
      throw new HttpError(404, "user_not_found", `No seller for "@${seller}".`);
    }
    sellerId = profile.userId;
  }

  const products = await ctx.runQuery(internal.marketplace.listProducts, {
    projectId,
    sellerId,
    category: c.query.get("category") ?? undefined,
    limit,
  });
  const profiles = await ctx.runQuery(internal.identity.profilesForUsers, {
    projectId,
    userIds: products.map((p) => p.sellerId),
  });
  const byUser = new Map(profiles.map((p) => [p.userId as string, p]));

  return ok({
    count: products.length,
    products: products.map((p) => ({
      ...shapeProduct(p),
      seller: byUser.has(p.sellerId as string)
        ? { handle: byUser.get(p.sellerId as string)!.handle }
        : null,
    })),
  });
}

// ---------------------------------------------------------------------------
// GET /v1/marketplace/products/:id
// ---------------------------------------------------------------------------

export async function getProduct(ctx: ActionCtx, c: RestContext): Promise<Response> {
  const projectId = c.principal.project._id;
  assertId(c.params.id, "id");
  const product = await runOrNotFound(
    () =>
      ctx.runQuery(internal.marketplace.productById, {
        projectId,
        productId: c.params.id as Id<"products">,
      }),
    404,
    "product_not_found",
    "No product with that id.",
  );
  if (!product) throw new HttpError(404, "product_not_found", "No product with that id.");
  if (product.status === "draft" || product.status === "removed") {
    throw new HttpError(404, "product_not_found", "That listing is not available.");
  }
  return ok({ product: shapeProduct(product) });
}

// ---------------------------------------------------------------------------
// POST /v1/marketplace/orders/checkout
// ---------------------------------------------------------------------------

export async function checkout(ctx: ActionCtx, c: RestContext): Promise<Response> {
  const projectId = c.principal.project._id;
  const actor = await requireActor(ctx, c);
  const body = await readJson(c.request);

  const productId = str(body, "productId", { required: true, max: 64 })!;
  assertId(productId, "productId");
  const quantity = intParam(body, "quantity", 1);

  await enforceAntiSpam(ctx, projectId, "checkout", actor.userId);
  const result = await runOrNotFound(
    () =>
      ctx.runMutation(internal.marketplace.checkout, {
        projectId,
        buyerId: actor.userId,
        productId: productId as Id<"products">,
        quantity,
        paymentRef: str(body, "paymentRef", { max: 120 }),
      }),
    404,
    "product_not_found",
    "No product with that id.",
  );

  if (result.status === "not_found") {
    throw new HttpError(404, "product_not_found", result.message);
  }
  if (result.status === "invalid") {
    throw new HttpError(400, "invalid_checkout", result.message);
  }
  if (result.status === "out_of_stock") {
    throw new HttpError(409, "out_of_stock", result.message);
  }
  if (result.status === "unavailable") {
    throw new HttpError(409, "product_unavailable", result.message);
  }

  const order = await ctx.runQuery(internal.marketplace.orderById, {
    projectId,
    orderId: result.orderId,
  });
  const product = await runOrNotFound(
    () =>
      ctx.runQuery(internal.marketplace.productById, {
        projectId,
        productId: productId as Id<"products">,
      }),
    404,
    "product_not_found",
    "No product with that id.",
  );

  return json(
    {
      ok: true,
      data: {
        order: order ? shapeOrder(order) : null,
        receipt: {
          status: "generated",
          bucket: "receipts",
          visibility: "private",
          note: "Purchase invoices are stored in the private `receipts` bucket. Attach one with a webhook or server action after your payment provider confirms.",
        },
        download: product
          ? {
              available: Boolean(product.assetFileId),
              bucket: "receipts",
              note: "Digital assets are private; fetch them server-side with a privileged API key and hand the client a short-lived URL.",
            }
          : null,
      },
    },
    201,
  );
}

// ---------------------------------------------------------------------------
// GET /v1/marketplace/orders  |  GET /v1/marketplace/earnings
// ---------------------------------------------------------------------------

export async function listOrders(ctx: ActionCtx, c: RestContext): Promise<Response> {
  const projectId = c.principal.project._id;
  const actor = await requireActor(ctx, c);
  const limit = numberParam(c.query.get("limit"), 20, 100);

  const orders = await ctx.runQuery(internal.marketplace.ordersForBuyer, {
    projectId,
    buyerId: actor.userId,
    limit,
  });
  return ok({
    buyerId: actor.userId,
    count: orders.length,
    orders: orders.map(shapeOrder),
  });
}

export async function earnings(ctx: ActionCtx, c: RestContext): Promise<Response> {
  const projectId = c.principal.project._id;
  const actor = await requireActor(ctx, c);
  const summary = await ctx.runQuery(internal.marketplace.earningsForCreator, {
    projectId,
    creatorId: actor.userId,
  });
  return ok({ creatorId: actor.userId, handle: actor.profile.handle, ...summary });
}