/**
 * Resolves the acting LoopUni user for a REST call.
 *
 * An FD53 end-user token identifies an `endUsers` row; the social graph is
 * keyed on the global `users` identity it owns. `requireActor` bridges the
 * two, creating the identity + profile on first use so accounts registered
 * before a profile existed still work.
 */
import type { ActionCtx } from "../_generated/server";
import type { Doc, Id } from "../_generated/dataModel";
import { internal } from "../_generated/api";
import { HttpError, authenticateEndUser, type EndUserContext } from "../lib/rest";
import type { RestContext } from "./types";

export type Actor = {
  endUser: EndUserContext;
  userId: Id<"users">;
  profile: Doc<"profiles">;
};

/** Token → LoopUni identity. Throws 401 when no valid token is present. */
export async function requireActor(
  ctx: ActionCtx,
  c: RestContext,
): Promise<Actor> {
  const projectId = c.principal.project._id;
  const endUser = await authenticateEndUser(ctx, c.request, projectId);
  return await resolveActor(ctx, projectId, endUser);
}

async function resolveActor(
  ctx: ActionCtx,
  projectId: Id<"projects">,
  endUser: EndUserContext,
): Promise<Actor> {
  let profile = await ctx.runQuery(internal.identity.profileByEndUser, {
    projectId,
    endUserId: endUser.user._id,
  });

  if (!profile) {
    const created = await ctx.runMutation(internal.identity.createIdentity, {
      projectId,
      endUserId: endUser.user._id,
      email: endUser.user.email,
      name: endUser.user.name ?? undefined,
    });
    if (created.status === "no_handle_available") {
      throw new HttpError(
        409,
        "handle_unavailable",
        "Could not allocate a unique handle for this account. Try again.",
      );
    }
    profile = await ctx.runQuery(internal.identity.profileByEndUser, {
      projectId,
      endUserId: endUser.user._id,
    });
  }

  if (!profile) {
    throw new HttpError(
      500,
      "profile_unavailable",
      "Could not load the profile for this account.",
    );
  }
  return { endUser, userId: profile.userId, profile };
}

/** Optional variant for endpoints that work signed-out but scope per user. */
export async function optionalActor(
  ctx: ActionCtx,
  c: RestContext,
): Promise<Actor | null> {
  if (!c.request.headers.get("authorization")) return null;
  try {
    return await requireActor(ctx, c);
  } catch (error) {
    // A bad token is an error when the caller clearly meant to authenticate.
    if (error instanceof HttpError && error.status === 401) throw error;
    return null;
  }
}

/** An FD53 id is an opaque base64url-ish string; reject obvious junk early. */
export function assertId(value: string, what: string): void {
  if (!/^[A-Za-z0-9_-]{16,64}$/.test(value)) {
    throw new HttpError(400, "invalid_id", `"${what}" is not a valid FD53 id.`);
  }
}