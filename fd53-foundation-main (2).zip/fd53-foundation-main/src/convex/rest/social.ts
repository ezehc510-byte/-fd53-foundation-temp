/**
 * LoopUni social REST API: profiles, the follow graph, posts, the home feed,
 * direct/group messages and moderation reports.
 *
 * Every handler is protected by the API key + rate limiter in the router;
 * handlers that act on a user additionally require an end-user token and run
 * the per-user anti-spam limiter.
 */
import type { ActionCtx } from "../_generated/server";
import type { Id } from "../_generated/dataModel";
import { internal } from "../_generated/api";
import {
  HttpError,
  enforceAntiSpam,
  json,
  ok,
  readJson,
  runOrNotFound,
  str,
} from "../lib/rest";
import { assertId, optionalActor, requireActor } from "./actor";
import type { RestContext } from "./types";

/**
 * Validate a client-supplied list of ids before they cross into a mutation.
 * Convex validates `v.id(...)` arguments before the function body runs, so a
 * malformed element would otherwise surface as a 500.
 */
function idList(values: string[], field: string): Id<never>[] {
  for (const value of values) assertId(value, field);
  return values as unknown as Id<never>[];
}

const MAX_TEXT = 2200;
const MAX_LIMIT = 50;

// ---------------------------------------------------------------------------
// Shapes
// ---------------------------------------------------------------------------

function shapePost(
  post: {
    _id: Id<"posts">;
    authorId: Id<"users">;
    text?: string;
    kind: string;
    aspectRatio?: string;
    mediaCount: number;
    likeCount: number;
    commentCount: number;
    shareCount: number;
    visibility: string;
    hashtags?: string[];
    _creationTime: number;
  },
  author: {
    handle: string;
    displayName?: string;
    avatarUrl?: string;
  } | null,
  media: Array<{
    _id: Id<"media">;
    url?: string;
    kind: string;
    aspectRatio?: string;
    width?: number;
    height?: number;
    durationMs?: number;
  }>,
) {
  return {
    id: post._id,
    text: post.text ?? null,
    kind: post.kind,
    aspectRatio: post.aspectRatio ?? null,
    mediaCount: post.mediaCount,
    likeCount: post.likeCount,
    commentCount: post.commentCount,
    shareCount: post.shareCount,
    visibility: post.visibility,
    hashtags: post.hashtags ?? [],
    author: author
      ? {
          userId: post.authorId,
          handle: author.handle,
          displayName: author.displayName ?? null,
          avatarUrl: author.avatarUrl ?? null,
        }
      : { userId: post.authorId, handle: "unknown", displayName: null, avatarUrl: null },
    media: media.map((m) => ({
      id: m._id,
      url: m.url ?? null,
      kind: m.kind,
      aspectRatio: m.aspectRatio ?? null,
      width: m.width ?? null,
      height: m.height ?? null,
      durationMs: m.durationMs ?? null,
    })),
    createdAt: post._creationTime,
  };
}

function numberParam(value: string | null, fallback: number, max: number): number {
  if (value === null || value === "") return fallback;
  const parsed = Number(value);
  if (!Number.isFinite(parsed) || parsed < 1) {
    throw new HttpError(400, "invalid_pagination", "limit must be a number ≥ 1.");
  }
  return Math.min(Math.floor(parsed), max);
}

// ---------------------------------------------------------------------------
// GET /v1/users/profile/:username
// ---------------------------------------------------------------------------

export async function getProfile(ctx: ActionCtx, c: RestContext): Promise<Response> {
  const projectId = c.principal.project._id;
  const requested = c.params.username.trim().replace(/^@/, "");
  if (!requested) {
    throw new HttpError(400, "invalid_handle", "A username is required.");
  }
  const handleLower = requested.toLowerCase();

  const profile = await ctx.runQuery(internal.identity.profileByHandle, {
    projectId,
    handleLower,
  });
  if (!profile) {
    throw new HttpError(404, "profile_not_found", `No profile for @${requested}.`);
  }

  const actor = await optionalActor(ctx, c);
  const isFollowing = actor
    ? await ctx.runQuery(internal.social.isFollowing, {
        projectId,
        followerId: actor.userId,
        followingId: profile.userId,
      })
    : false;

  const posts = await ctx.runQuery(internal.social.postsByAuthor, {
    projectId,
    authorId: profile.userId,
    limit: 20,
  });

  return ok({
    profile: {
      id: profile._id,
      userId: profile.userId,
      handle: profile.handle,
      displayName: profile.displayName ?? null,
      bio: profile.bio ?? null,
      avatarUrl: profile.avatarUrl ?? null,
      bannerUrl: profile.bannerUrl ?? null,
      location: profile.location ?? null,
      website: profile.website ?? null,
      followerCount: profile.followerCount,
      followingCount: profile.followingCount,
      postCount: profile.postCount,
      isCreator: profile.isCreator ?? false,
      isVerified: profile.isVerified ?? false,
      isFollowing,
      createdAt: profile._creationTime,
    },
    posts: posts.map((p) =>
      shapePost(p, profile, []),
    ),
  });
}

// ---------------------------------------------------------------------------
// POST /v1/users/:id/follow  |  POST /v1/users/:id/unfollow
// ---------------------------------------------------------------------------

/**
 * Accept either a `users` id or an @handle in the `:id` position.
 *
 * An id-shaped string is verified against the `users` table before it is
 * handed to a mutation: Convex validates `v.id(...)` arguments *before* the
 * function body runs, so passing an id that does not exist would otherwise
 * surface as a 500 instead of a clean 404.
 */
async function resolveTarget(
  ctx: ActionCtx,
  projectId: Id<"projects">,
  raw: string,
): Promise<Id<"users">> {
  if (/^[A-Za-z0-9_-]{16,64}$/.test(raw)) {
    const user = await runOrNotFound(
      () => ctx.runQuery(internal.identity.byId, { userId: raw as Id<"users"> }),
      404,
      "user_not_found",
      "No user with that id.",
    );
    if (!user) {
      throw new HttpError(404, "user_not_found", "No user with that id.");
    }
    return user._id;
  }
  const handle = raw.trim().replace(/^@/, "").toLowerCase();
  const profile = await ctx.runQuery(internal.identity.profileByHandle, {
    projectId,
    handleLower: handle,
  });
  if (!profile) {
    throw new HttpError(404, "user_not_found", `No user for "@${handle}".`);
  }
  return profile.userId;
}

export async function followUser(ctx: ActionCtx, c: RestContext): Promise<Response> {
  const projectId = c.principal.project._id;
  const actor = await requireActor(ctx, c);
  const targetId = await resolveTarget(ctx, projectId, c.params.id);

  await enforceAntiSpam(ctx, projectId, "follow", actor.userId);
  const result = await runOrNotFound(
    () =>
      ctx.runMutation(internal.social.follow, {
        projectId,
        followerId: actor.userId,
        followingId: targetId,
      }),
    404,
    "user_not_found",
    "No user with that id.",
  );

  if (result.status === "self_follow") {
    throw new HttpError(400, "self_follow", result.message);
  }
  if (result.status === "not_found") {
    throw new HttpError(404, "user_not_found", result.message);
  }

  const profile = await ctx.runQuery(internal.identity.profileByUser, {
    projectId,
    userId: targetId,
  });

  return json(
    {
      ok: true,
      data: {
        following: true,
        created: result.status === "followed",
        followerId: actor.userId,
        followingId: targetId,
        followerCount: profile?.followerCount ?? null,
        followingCount: profile?.followingCount ?? null,
      },
    },
    result.status === "followed" ? 201 : 200,
  );
}

export async function unfollowUser(ctx: ActionCtx, c: RestContext): Promise<Response> {
  const projectId = c.principal.project._id;
  const actor = await requireActor(ctx, c);
  const targetId = await resolveTarget(ctx, projectId, c.params.id);

  const result = await runOrNotFound(
    () =>
      ctx.runMutation(internal.social.unfollow, {
        projectId,
        followerId: actor.userId,
        followingId: targetId,
      }),
    404,
    "user_not_found",
    "No user with that id.",
  );

  const profile = await ctx.runQuery(internal.identity.profileByUser, {
    projectId,
    userId: targetId,
  });

  return ok({
    following: false,
    followerId: actor.userId,
    followingId: targetId,
    followerCount: profile?.followerCount ?? null,
    followingCount: profile?.followingCount ?? null,
  });
}

// ---------------------------------------------------------------------------
// POST /v1/posts/create
// ---------------------------------------------------------------------------

export async function createPost(ctx: ActionCtx, c: RestContext): Promise<Response> {
  const projectId = c.principal.project._id;
  const actor = await requireActor(ctx, c);
  const body = await readJson(c.request);

  const text = str(body, "text", { max: MAX_TEXT })?.trim();
  const visibility = body.visibility;
  if (
    visibility !== undefined &&
    visibility !== "public" &&
    visibility !== "followers" &&
    visibility !== "private"
  ) {
    throw new HttpError(
      400,
      "invalid_field",
      '"visibility" must be "public", "followers" or "private".',
    );
  }

  // Attachments: either `media: [...]` objects or bare `mediaIds`/`fileIds`.
  let media: Array<Record<string, unknown>> = [];
  if (Array.isArray(body.media)) {
    media = body.media as Array<Record<string, unknown>>;
  } else if (Array.isArray(body.mediaIds)) {
    media = (body.mediaIds as unknown[]).map((id) => ({ fileId: id }));
  }

  await enforceAntiSpam(ctx, projectId, "post", actor.userId);
  const result = await ctx.runMutation(internal.social.createPost, {
    projectId,
    authorId: actor.userId,
    text,
    media,
    visibility,
  });

  if (result.status === "invalid") {
    throw new HttpError(400, "invalid_post", result.message);
  }

  const post = await ctx.runQuery(internal.social.postById, {
    projectId,
    postId: result.postId,
  });
  if (!post) throw new HttpError(500, "internal_error", "Post was not saved.");

  const attachments = await ctx.runQuery(internal.social.mediaForPost, {
    postId: post._id,
  });

  return json(
    {
      ok: true,
      data: { post: shapePost(post, actor.profile, attachments) },
    },
    201,
  );
}

// ---------------------------------------------------------------------------
// GET /v1/posts/:id
// ---------------------------------------------------------------------------

export async function getPost(ctx: ActionCtx, c: RestContext): Promise<Response> {
  const projectId = c.principal.project._id;
  assertId(c.params.id, "id");
  const post = await runOrNotFound(
    () =>
      ctx.runQuery(internal.social.postById, {
        projectId,
        postId: c.params.id as Id<"posts">,
      }),
    404,
    "post_not_found",
    "No post with that id.",
  );
  if (!post) throw new HttpError(404, "post_not_found", "No post with that id.");

  if (post.visibility === "private") {
    const actor = await requireActor(ctx, c);
    if (actor.userId !== post.authorId) {
      throw new HttpError(403, "forbidden", "That post is private.");
    }
  }

  const author = await ctx.runQuery(internal.identity.profileByUser, {
    projectId,
    userId: post.authorId,
  });
  const attachments = await ctx.runQuery(internal.social.mediaForPost, {
    postId: post._id,
  });
  return ok({ post: shapePost(post, author, attachments) });
}

// ---------------------------------------------------------------------------
// GET /v1/feed/home
// ---------------------------------------------------------------------------

export async function homeFeed(ctx: ActionCtx, c: RestContext): Promise<Response> {
  const projectId = c.principal.project._id;
  const limit = numberParam(c.query.get("limit"), 20, MAX_LIMIT);
  const actor = await optionalActor(ctx, c);

  let posts;
  let scope: "following" | "discovery";

  if (actor) {
    const authorIds = await ctx.runQuery(internal.social.feedAuthorIds, {
      projectId,
      userId: actor.userId,
    });
    const candidates = await ctx.runQuery(internal.social.recentPosts, {
      projectId,
      limit: 100,
    });
    posts = candidates.filter((p) => authorIds.includes(p.authorId));
    // Someone who follows nobody still needs an empty-state-free feed.
    if (posts.length === 0) {
      posts = await ctx.runQuery(internal.social.recentPosts, { projectId, limit });
      scope = "discovery";
    } else {
      scope = "following";
    }
  } else {
    posts = await ctx.runQuery(internal.social.recentPosts, { projectId, limit });
    scope = "discovery";
  }

  const visible = posts.filter((p) => p.visibility !== "private").slice(0, limit);
  const attachments = await ctx.runQuery(internal.social.mediaForPosts, {
    postIds: visible.map((p) => p._id),
  });

  const profiles = await ctx.runQuery(internal.identity.profilesForUsers, {
    projectId,
    userIds: visible.map((p) => p.authorId),
  });
  const byUser = new Map(profiles.map((p) => [p.userId as string, p]));

  return ok({
    scope,
    viewer: actor
      ? { userId: actor.userId, handle: actor.profile.handle }
      : null,
    count: visible.length,
    posts: visible.map((p) =>
      shapePost(
        p,
        byUser.get(p.authorId as string) ?? null,
        attachments.filter((m) => m.postId === p._id),
      ),
    ),
  });
}

// ---------------------------------------------------------------------------
// Messaging: POST /v1/messages/send  |  GET /v1/messages/:roomId
// ---------------------------------------------------------------------------

export async function sendMessage(ctx: ActionCtx, c: RestContext): Promise<Response> {
  const projectId = c.principal.project._id;
  const actor = await requireActor(ctx, c);
  const body = await readJson(c.request);

  // Either `to` (opens/uses the 1:1 room) or an explicit `roomId`.
  const roomId = str(body, "roomId", { max: 200 })?.trim();
  const text = str(body, "text", { max: 4000 })?.trim();
  const toHandle = str(body, "to", { max: 40 })?.trim().replace(/^@/, "").toLowerCase();
  const mediaIds = Array.isArray(body.mediaIds) ? (body.mediaIds as string[]) : [];

  if (!toHandle && !roomId) {
    throw new HttpError(
      400,
      "missing_field",
      'Provide "to" (a @handle to start a direct chat) or "roomId" to reply in an existing room.',
    );
  }

  let conversationId: Id<"conversations"> | null = null;
  let resolvedRoomId = roomId ?? "";

  if (toHandle) {
    const target = await ctx.runQuery(internal.identity.profileByHandle, {
      projectId,
      handleLower: toHandle,
    });
    if (!target) {
      throw new HttpError(404, "user_not_found", `No user for "@${toHandle}".`);
    }
    // Deterministic 1:1 room id, so re-sending never forks the thread.
    const dmRoom = `dm:${[actor.userId, target.userId].sort().join(":")}`;
    resolvedRoomId = dmRoom;
    const ensured = await ctx.runMutation(internal.messaging.ensureConversation, {
      projectId,
      roomId: dmRoom,
      type: "direct",
      participantIds: [actor.userId, target.userId],
      createdBy: actor.userId,
    });
    if (ensured.status === "invalid") {
      throw new HttpError(400, "invalid_conversation", ensured.message);
    }
    conversationId = ensured.conversationId;
  } else {
    const conversation = await ctx.runQuery(internal.messaging.conversationByRoom, {
      projectId,
      roomId: resolvedRoomId,
    });
    if (!conversation) {
      throw new HttpError(
        404,
        "conversation_not_found",
        `No room "${resolvedRoomId}".`,
      );
    }
    conversationId = conversation._id;
  }

  await enforceAntiSpam(ctx, projectId, "message", actor.userId);
  const result = await runOrNotFound(
    () =>
      ctx.runMutation(internal.messaging.sendMessage, {
        projectId,
        conversationId,
        senderId: actor.userId,
        text,
        mediaIds: idList(mediaIds, "mediaIds") as Id<"media">[],
      }),
    400,
    "invalid_media",
    'Each "mediaIds" entry must be an id returned by /v1/posts/create.',
  );

  if (result.status === "forbidden") {
    throw new HttpError(403, "forbidden", result.message);
  }
  if (result.status === "not_found") {
    throw new HttpError(404, "conversation_not_found", result.message);
  }
  if (result.status === "invalid") {
    throw new HttpError(400, "invalid_message", result.message);
  }

  return json(
    {
      ok: true,
      data: {
        message: {
          id: result.messageId,
          roomId: resolvedRoomId,
          senderId: actor.userId,
          text: text ?? null,
          sentAt: result.sentAt,
        },
      },
    },
    201,
  );
}

export async function listMessages(ctx: ActionCtx, c: RestContext): Promise<Response> {
  const projectId = c.principal.project._id;
  const actor = await optionalActor(ctx, c);
  const limit = numberParam(c.query.get("limit"), 30, 100);

  const conversation = await ctx.runQuery(internal.messaging.conversationByRoom, {
    projectId,
    roomId: c.params.roomId,
  });
  if (!conversation) {
    throw new HttpError(404, "conversation_not_found", `No room "${c.params.roomId}".`);
  }
  if (
    actor &&
    !conversation.participantIds.includes(actor.userId)
  ) {
    throw new HttpError(403, "forbidden", "You are not in this conversation.");
  }

  const messages = await ctx.runQuery(internal.messaging.listMessages, {
    projectId,
    conversationId: conversation._id,
    viewerId: actor?.userId,
    limit,
  });

  return ok({
    roomId: conversation.roomId,
    type: conversation.type,
    title: conversation.title ?? null,
    participants: conversation.participantIds,
    count: messages?.length ?? 0,
    messages: (messages ?? []).map((m) => ({
      id: m._id,
      senderId: m.senderId,
      text: m.text ?? null,
      kind: m.kind,
      mediaIds: m.mediaIds ?? [],
      readAt: m.readAt ?? null,
      createdAt: m._creationTime,
    })),
  });
}

// ---------------------------------------------------------------------------
// POST /v1/reports/create
// ---------------------------------------------------------------------------

export async function createReport(ctx: ActionCtx, c: RestContext): Promise<Response> {
  const projectId = c.principal.project._id;
  const body = await readJson(c.request);
  const actor = await optionalActor(ctx, c);

  const targetType = str(body, "targetType", { required: true })!;
  const targetId = str(body, "targetId", { required: true, max: 64 })!;
  const reason = str(body, "reason", { required: true, max: 200 })!;
  const details = str(body, "details", { max: 2000 });

  if (actor) {
    await enforceAntiSpam(ctx, projectId, "report", actor.userId);
  }

  const result = await ctx.runMutation(internal.reports.create, {
    projectId,
    reporterId: actor?.userId,
    targetType,
    targetId,
    reason,
    details,
  });

  if (result.status === "invalid") {
    throw new HttpError(400, "invalid_report", result.message);
  }
  return json(
    {
      ok: true,
      data: {
        reportId: result.reportId,
        status: "open",
        duplicate: result.status === "duplicate",
      },
    },
    result.status === "created" ? 201 : 200,
  );
}