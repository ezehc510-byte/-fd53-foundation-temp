/**
 * FD53 Auth — end-user endpoints.
 *
 * Registration/login (email + password, phone + OTP), token verification,
 * logout, password management and role listing.
 */
import type { ActionCtx } from "../_generated/server";
import type { Id } from "../_generated/dataModel";
import { internal } from "../_generated/api";
import {
  OTP_TTL_MS,
  RESET_TTL_MS,
  TOKEN_TTL_SECONDS,
  isValidEmail,
  isValidPhone,
} from "../lib/constants";
import {
  hmacHex,
  pbkdf2Hash,
  pbkdf2Verify,
  randomBytes,
  randomHex,
  sha256Hex,
  timingSafeEqual,
} from "../lib/crypto";
import {
  HttpError,
  authenticateEndUser,
  clientIp,
  enforceAntiSpam,
  getOrCreateSecret,
  issueSession,
  json,
  ok,
  readJson,
  str,
} from "../lib/rest";
import { publicUser } from "../endUsers";
import { publicProfile } from "../identity";
import type { RestContext } from "./types";

async function defaultRoleName(
  ctx: ActionCtx,
  projectId: Id<"projects">,
): Promise<string> {
  const roles = await ctx.runQuery(internal.roles.allForApi, { projectId });
  return roles.find((r) => r.isDefault)?.name ?? "user";
}

/** Six digit numeric code from the CSPRNG. */
function numericCode(length: number): string {
  const bytes = randomBytes(4);
  const value =
    ((bytes[0] << 24) >>> 0) + (bytes[1] << 16) + (bytes[2] << 8) + bytes[3];
  return String(value % 10 ** length).padStart(length, "0");
}

function requirePassword(body: Record<string, unknown>): string {
  const password = str(body, "password", { required: true })!;
  if (password.length < 8) {
    throw new HttpError(
      400,
      "weak_password",
      "Passwords must be at least 8 characters.",
    );
  }
  if (password.length > 256) {
    throw new HttpError(400, "weak_password", "Passwords must be under 256 characters.");
  }
  return password;
}

// ---------------------------------------------------------------------------
// POST /v1/auth/register
// ---------------------------------------------------------------------------

export async function register(ctx: ActionCtx, c: RestContext): Promise<Response> {
  const body = await readJson(c.request);
  const email = str(body, "email", { max: 254 })?.trim().toLowerCase();
  const phone = str(body, "phone", { max: 20 })?.trim();
  const name = str(body, "name", { max: 120 })?.trim();
  // Optional LoopUni @handle; one is derived from the name/email if omitted.
  const username = str(body, "username", { max: 30 })?.trim();
  const rawData = body.data;
  const data =
    rawData && typeof rawData === "object" && !Array.isArray(rawData)
      ? rawData
      : undefined;

  if (!email && !phone) {
    throw new HttpError(
      400,
      "missing_identifier",
      'Provide an "email" or a "phone" (E.164, e.g. +15551234567).',
    );
  }
  if (email && !isValidEmail(email)) {
    throw new HttpError(400, "invalid_email", "That email address isn't valid.");
  }
  if (phone && !isValidPhone(phone)) {
    throw new HttpError(
      400,
      "invalid_phone",
      'Phone numbers must be E.164 format, e.g. "+15551234567".',
    );
  }

  const hasPassword = body.password !== undefined && body.password !== "";
  if (email && !hasPassword) {
    throw new HttpError(
      400,
      "missing_password",
      'Email registration needs a "password" (8+ characters).',
    );
  }
  if (username !== undefined && !/^[a-zA-Z0-9_]{3,30}$/.test(username)) {
    throw new HttpError(
      400,
      "invalid_username",
      '"username" must be 3–30 characters of letters, digits or underscore.',
    );
  }

  const projectId = c.principal.project._id;
  // Anti-spam: cap how many accounts one IP can mint per hour.
  await enforceAntiSpam(ctx, projectId, "register", clientIp(c.request) ?? "unknown");

  let salt: string | undefined;
  let passwordHash: string | undefined;
  if (hasPassword) {
    const password = requirePassword(body);
    salt = randomHex(16);
    passwordHash = await pbkdf2Hash(password, salt);
  }
  const result = await ctx.runMutation(internal.endUsers.create, {
    projectId,
    email: email ?? undefined,
    phone: phone ?? undefined,
    name: name ?? undefined,
    salt,
    passwordHash,
    role: await defaultRoleName(ctx, projectId),
    data,
  });

  if (result.status === "email_taken") {
    throw new HttpError(409, "email_taken", "That email is already registered.");
  }
  if (result.status === "phone_taken") {
    throw new HttpError(409, "phone_taken", "That phone number is already registered.");
  }

  const user = await ctx.runQuery(internal.endUsers.byId, {
    projectId,
    id: result.id,
  });
  if (!user) throw new HttpError(500, "internal_error", "Could not create the user.");

  // Mint the LoopUni identity (users + profiles rows) for this account.
  const identity = await ctx.runMutation(internal.identity.createIdentity, {
    projectId,
    endUserId: user._id,
    email: user.email,
    name: user.name ?? undefined,
    username,
  });
  if (identity.status === "no_handle_available") {
    throw new HttpError(409, "handle_unavailable", identity.message);
  }
  const profile = await ctx.runQuery(internal.identity.profileByUser, {
    projectId,
    userId: identity.userId,
  });

  const issued = await issueSession(ctx, user, c.request.headers.get("user-agent"));
  return json(
    {
      ok: true,
      data: {
        user: publicUser(user),
        profile: profile ? publicProfile(profile) : null,
        token: issued.token,
        expiresIn: TOKEN_TTL_SECONDS,
        sessionId: issued.sid,
      },
    },
    201,
  );
}

// ---------------------------------------------------------------------------
// POST /v1/auth/login
// ---------------------------------------------------------------------------

export async function login(ctx: ActionCtx, c: RestContext): Promise<Response> {
  const body = await readJson(c.request);
  const email = str(body, "email", { max: 254 })?.trim().toLowerCase();
  const phone = str(body, "phone", { max: 20 })?.trim();
  const password = str(body, "password", { required: true })!;

  if (!email && !phone) {
    throw new HttpError(400, "missing_identifier", 'Provide an "email" or a "phone".');
  }

  const projectId = c.principal.project._id;
  // Anti-spam: cap password-spraying attempts per identifier.
  await enforceAntiSpam(ctx, projectId, "login", email ?? phone!);

  const user = email
    ? await ctx.runQuery(internal.endUsers.byEmail, { projectId, email })
    : await ctx.runQuery(internal.endUsers.byPhone, { projectId, phone: phone! });

  if (!user) {
    // Equalise timing so unknown accounts look like wrong passwords.
    await pbkdf2Hash(password, randomHex(16));
    throw new HttpError(
      401,
      "invalid_credentials",
      "Email/phone or password is incorrect.",
    );
  }
  if (user.status === "banned") {
    throw new HttpError(403, "account_banned", "This account has been disabled.");
  }
  if (user.lockedUntil && user.lockedUntil > Date.now()) {
    const retryAfter = Math.ceil((user.lockedUntil - Date.now()) / 1000);
    throw new HttpError(
      429,
      "account_locked",
      `Too many failed attempts. Try again in ${Math.ceil(retryAfter / 60)} minute(s).`,
      { "Retry-After": String(retryAfter) },
    );
  }
  if (!user.salt || !user.passwordHash) {
    throw new HttpError(
      400,
      "no_password_set",
      "This account signs in with a phone code. Use POST /v1/auth/otp/verify.",
    );
  }

  const valid = await pbkdf2Verify(password, user.salt, user.passwordHash);
  if (!valid) {
    const failure = await ctx.runMutation(internal.endUsers.loginFailed, {
      projectId,
      id: user._id,
    });
    if (failure.lockedUntil) {
      const retryAfter = Math.ceil((failure.lockedUntil - Date.now()) / 1000);
      throw new HttpError(
        429,
        "account_locked",
        `Too many failed attempts. Locked for ${Math.ceil(retryAfter / 60)} minute(s).`,
        { "Retry-After": String(retryAfter) },
      );
    }
    throw new HttpError(
      401,
      "invalid_credentials",
      `Email/phone or password is incorrect. ${failure.remaining} attempt(s) left before lockout.`,
    );
  }

  await ctx.runMutation(internal.endUsers.loginSucceeded, {
    projectId,
    id: user._id,
  });
  const fresh = (await ctx.runQuery(internal.endUsers.byId, {
    projectId,
    id: user._id,
  })) ?? user;

  const issued = await issueSession(ctx, fresh, c.request.headers.get("user-agent"));
  const profile = await ctx.runQuery(internal.identity.profileByEndUser, {
    projectId,
    endUserId: fresh._id,
  });
  return ok({
    user: publicUser(fresh),
    profile: profile ? publicProfile(profile) : null,
    token: issued.token,
    expiresIn: TOKEN_TTL_SECONDS,
    sessionId: issued.sid,
  });
}

// ---------------------------------------------------------------------------
// POST /v1/auth/otp/request  +  POST /v1/auth/otp/verify
// ---------------------------------------------------------------------------

export async function otpRequest(
  ctx: ActionCtx,
  c: RestContext,
): Promise<Response> {
  const body = await readJson(c.request);
  const phone = str(body, "phone", { required: true })!.trim();
  if (!isValidPhone(phone)) {
    throw new HttpError(400, "invalid_phone", 'Use E.164 format, e.g. "+15551234567".');
  }
  const projectId = c.principal.project._id;

  // Throttle: one code per phone number per 60 seconds.
  const existing = await ctx.runQuery(internal.phoneOtps.latest, {
    projectId,
    phone,
  });
  if (existing && existing._creationTime > Date.now() - 60_000) {
    throw new HttpError(
      429,
      "otp_throttled",
      "A code was already sent in the last minute.",
      { "Retry-After": "60" },
    );
  }

  const code = numericCode(6);
  const pepper = await getOrCreateSecret(ctx, "fd53.otp");
  const codeHash = await hmacHex(pepper, `${projectId}:${phone}:${code}`);
  await ctx.runMutation(internal.phoneOtps.create, {
    projectId,
    phone,
    codeHash,
    expiresAt: Date.now() + OTP_TTL_MS,
  });

  return ok({
    status: "sent",
    phone,
    expiresIn: Math.floor(OTP_TTL_MS / 1000),
    // v1 has no SMS provider wired up yet — the code is returned here so phone
    // flows are testable. Replace this with your SMS provider before launch.
    delivery: "console",
    devCode: code,
    note: "No SMS provider is configured in v1, so the code is returned in this response. Wire an SMS provider (e.g. Twilio) before production.",
  });
}

export async function otpVerify(ctx: ActionCtx, c: RestContext): Promise<Response> {
  const body = await readJson(c.request);
  const phone = str(body, "phone", { required: true })!.trim();
  const code = str(body, "code", { required: true })!.trim();
  const projectId = c.principal.project._id;

  const otp = await ctx.runQuery(internal.phoneOtps.latest, { projectId, phone });
  if (!otp) {
    throw new HttpError(
      400,
      "no_otp",
      "Request a code first with POST /v1/auth/otp/request.",
    );
  }
  if (otp.expiresAt < Date.now()) {
    throw new HttpError(410, "otp_expired", "That code expired — request a new one.");
  }

  const pepper = await getOrCreateSecret(ctx, "fd53.otp");
  const expected = await hmacHex(pepper, `${projectId}:${phone}:${code}`);
  const matched = timingSafeEqual(expected, otp.codeHash);

  const attempt = await ctx.runMutation(internal.phoneOtps.recordAttempt, {
    projectId,
    phone,
    matched,
  });
  if (!matched) {
    if (attempt.exhausted) {
      throw new HttpError(
        429,
        "too_many_attempts",
        "Too many wrong codes — request a new one.",
      );
    }
    throw new HttpError(
      401,
      "invalid_code",
      `Wrong code. ${attempt.remaining} attempt(s) left.`,
    );
  }

  const role = await defaultRoleName(ctx, projectId);
  const ensured = await ctx.runMutation(internal.endUsers.ensureByPhone, {
    projectId,
    phone,
    role,
  });
  await ctx.runMutation(internal.endUsers.loginSucceeded, {
    projectId,
    id: ensured.id,
  });
  const user = await ctx.runQuery(internal.endUsers.byId, {
    projectId,
    id: ensured.id,
  });
  if (!user) throw new HttpError(500, "internal_error", "Could not load the user.");

  const issued = await issueSession(ctx, user, c.request.headers.get("user-agent"));
  return ok({
    user: publicUser(user),
    token: issued.token,
    expiresIn: TOKEN_TTL_SECONDS,
    sessionId: issued.sid,
    created: ensured.status === "created",
  });
}

// ---------------------------------------------------------------------------
// GET /v1/auth/me  |  POST /v1/auth/logout  |  POST /v1/auth/token/verify
// ---------------------------------------------------------------------------

export async function me(ctx: ActionCtx, c: RestContext): Promise<Response> {
  const projectId = c.principal.project._id;
  const endUser = await authenticateEndUser(ctx, c.request, projectId);
  const role = await ctx.runQuery(internal.roles.byName, {
    projectId,
    name: endUser.user.role,
  });
  const profile = await ctx.runQuery(internal.identity.profileByEndUser, {
    projectId,
    endUserId: endUser.user._id,
  });
  return ok({
    user: publicUser(endUser.user),
    profile: profile ? publicProfile(profile) : null,
    role: role
      ? { name: role.name, permissions: role.permissions }
      : { name: endUser.user.role, permissions: endUser.permissions },
    session: {
      id: endUser.session.sid,
      createdAt: endUser.session.createdAt,
      expiresAt: endUser.session.expiresAt,
    },
    serverTime: new Date().toISOString(),
  });
}

export async function logout(ctx: ActionCtx, c: RestContext): Promise<Response> {
  const projectId = c.principal.project._id;
  const endUser = await authenticateEndUser(ctx, c.request, projectId);
  await ctx.runMutation(internal.sessions.revokeBySid, {
    projectId,
    sid: endUser.session.sid,
  });
  return ok({ status: "signed_out" });
}

export async function verifyToken(ctx: ActionCtx, c: RestContext): Promise<Response> {
  const projectId = c.principal.project._id;
  const endUser = await authenticateEndUser(ctx, c.request, projectId);
  return ok({
    valid: true,
    userId: endUser.user._id,
    role: endUser.user.role,
    expiresAt: endUser.session.expiresAt,
  });
}

// ---------------------------------------------------------------------------
// Password management
// ---------------------------------------------------------------------------

export async function changePassword(
  ctx: ActionCtx,
  c: RestContext,
): Promise<Response> {
  const body = await readJson(c.request);
  const currentPassword = str(body, "currentPassword", { required: true })!;
  const newPassword = requirePassword({ newPassword: body.newPassword });

  const projectId = c.principal.project._id;
  const endUser = await authenticateEndUser(ctx, c.request, projectId);
  if (!endUser.user.salt || !endUser.user.passwordHash) {
    throw new HttpError(
      400,
      "no_password_set",
      "This account has no password (phone OTP only).",
    );
  }
  const valid = await pbkdf2Verify(
    currentPassword,
    endUser.user.salt,
    endUser.user.passwordHash,
  );
  if (!valid) {
    throw new HttpError(401, "invalid_password", "Current password is incorrect.");
  }

  const salt = randomHex(16);
  const passwordHash = await pbkdf2Hash(newPassword, salt);
  await ctx.runMutation(internal.endUsers.setPassword, {
    projectId,
    id: endUser.user._id,
    salt,
    passwordHash,
  });
  return ok({ status: "password_changed" });
}

export async function requestReset(ctx: ActionCtx, c: RestContext): Promise<Response> {
  const body = await readJson(c.request);
  const email = str(body, "email", { required: true })!.trim().toLowerCase();
  if (!isValidEmail(email)) {
    throw new HttpError(400, "invalid_email", "That email address isn't valid.");
  }
  const projectId = c.principal.project._id;

  const user = await ctx.runQuery(internal.endUsers.byEmail, { projectId, email });
  if (!user) {
    // Never reveal whether an account exists.
    return ok({
      status: "reset_requested",
      delivery: "none",
      message: "If that email is registered, a reset token was generated.",
    });
  }

  const token = randomHex(24);
  await ctx.runMutation(internal.passwordResets.create, {
    projectId,
    endUserId: user._id,
    tokenHash: await sha256Hex(token),
    expiresAt: Date.now() + RESET_TTL_MS,
  });

  return ok({
    status: "reset_requested",
    email,
    expiresIn: Math.floor(RESET_TTL_MS / 1000),
    // v1 has no email provider wired up — the token is returned here so the
    // recovery flow is testable. Send it via your email provider instead.
    delivery: "console",
    resetToken: token,
    note: "No email provider is configured in v1, so the token is returned in this response. Send it via your email provider before production.",
  });
}

export async function confirmReset(ctx: ActionCtx, c: RestContext): Promise<Response> {
  const body = await readJson(c.request);
  const token = str(body, "token", { required: true })!;
  const newPassword = requirePassword({ newPassword: body.newPassword });
  const projectId = c.principal.project._id;

  const reset = await ctx.runQuery(internal.passwordResets.byToken, {
    tokenHash: await sha256Hex(token),
  });
  if (!reset || reset.projectId !== projectId) {
    throw new HttpError(400, "invalid_token", "That reset token is invalid.");
  }
  if (reset.usedAt) {
    throw new HttpError(400, "token_used", "That reset token was already used.");
  }
  if (reset.expiresAt < Date.now()) {
    throw new HttpError(410, "token_expired", "That reset token expired.");
  }

  const salt = randomHex(16);
  const passwordHash = await pbkdf2Hash(newPassword, salt);
  await ctx.runMutation(internal.endUsers.setPassword, {
    projectId,
    id: reset.endUserId,
    salt,
    passwordHash,
    invalidateTokens: true,
  });
  await ctx.runMutation(internal.sessions.revokeAllForUser, {
    projectId,
    endUserId: reset.endUserId,
  });
  await ctx.runMutation(internal.passwordResets.markUsed, { id: reset._id });

  return ok({
    status: "password_reset",
    message: "Password updated — all existing sessions were signed out.",
  });
}

// ---------------------------------------------------------------------------
// GET /v1/auth/roles
// ---------------------------------------------------------------------------

export async function roles(ctx: ActionCtx, c: RestContext): Promise<Response> {
  const projectId = c.principal.project._id;
  const roles = await ctx.runQuery(internal.roles.allForApi, { projectId });
  return ok({
    roles: roles.map((r) => ({
      name: r.name,
      description: r.description ?? null,
      permissions: r.permissions,
      isDefault: r.isDefault ?? false,
    })),
  });
}