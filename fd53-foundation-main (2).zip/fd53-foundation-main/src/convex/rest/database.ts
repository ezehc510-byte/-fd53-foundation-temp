/**
 * FD53 Database REST API — tables (schema) and rows (documents).
 *
 * Every handler is protected by the API key + rate limiter in the router;
 * end-user tokens are resolved here for table-level access control.
 */
import type { ActionCtx } from "../_generated/server";
import type { Doc, Id } from "../_generated/dataModel";
import { internal } from "../_generated/api";
import { FREE_PLAN } from "../lib/constants";
import {
  HttpError,
  authenticateEndUser,
  checkTableAccess,
  hasPermission,
  json,
  ok,
  readJson,
  type EndUserContext,
} from "../lib/rest";
import type { RestContext } from "./types";

const RESERVED_QUERY_KEYS = new Set(["limit", "offset", "redirect", "ownerId"]);

type FieldArg = {
  name: string;
  type: "string" | "number" | "boolean" | "datetime" | "json" | "reference";
  required?: boolean;
  unique?: boolean;
  refTable?: string;
  description?: string;
};

function shapeTable(table: Doc<"tables">) {
  return {
    id: table._id,
    name: table.name,
    description: table.description ?? null,
    access: table.access,
    fields: table.fields.map((f) => ({
      name: f.name,
      type: f.type,
      required: f.required ?? false,
      unique: f.unique ?? false,
      refTable: f.refTable ?? null,
      description: f.description ?? null,
    })),
    rowCount: table.rowCount,
    createdAt: table._creationTime,
  };
}

function shapeRow(row: Doc<"rows">) {
  return {
    id: row._id,
    data: row.data,
    ownerId: row.ownerId ?? null,
    createdAt: row._creationTime,
  };
}

function parseFields(body: Record<string, unknown>): FieldArg[] {
  const raw = body.fields;
  if (!Array.isArray(raw)) {
    throw new HttpError(400, "invalid_fields", '"fields" must be an array.');
  }
  return raw.map((entry, index) => {
    if (!entry || typeof entry !== "object") {
      throw new HttpError(400, "invalid_fields", `fields[${index}] must be an object.`);
    }
    const field = entry as Record<string, unknown>;
    if (typeof field.name !== "string" || typeof field.type !== "string") {
      throw new HttpError(
        400,
        "invalid_fields",
        `fields[${index}] needs "name" and "type".`,
      );
    }
    return field as unknown as FieldArg;
  });
}

function parseAccess(body: Record<string, unknown>) {
  const access = body.access;
  if (access === undefined || access === null) return undefined;
  if (access !== "public" && access !== "authenticated" && access !== "owner") {
    throw new HttpError(
      400,
      "invalid_access",
      '"access" must be "public", "authenticated" or "owner".',
    );
  }
  return access;
}

async function tableByName(
  ctx: ActionCtx,
  projectId: Id<"projects">,
  name: string,
): Promise<Doc<"tables">> {
  const table = await ctx.runQuery(internal.tables.byName, { projectId, name });
  if (!table) {
    throw new HttpError(404, "table_not_found", `No table named "${name}".`);
  }
  return table;
}

/**
 * Resolve the end-user context required by a table's access policy.
 *
 * Access levels restrict *end-user tokens*. A call with no bearer token is a
 * server-to-server call authenticated by the project API key, which always
 * has full access (that's what admin/moderation code and FlutterFlow server
 * actions use). A bearer token that is present must be valid.
 */
async function accessFor(
  ctx: ActionCtx,
  c: RestContext,
  table: Doc<"tables">,
  action: "read" | "write",
): Promise<EndUserContext | null> {
  const projectId = c.principal.project._id;
  const hasToken = Boolean(c.request.headers.get("authorization"));

  if (!hasToken) {
    // Developer / server-side access via the API key.
    return null;
  }

  const endUser = await authenticateEndUser(ctx, c.request, projectId);
  checkTableAccess(table, endUser, action);
  return endUser;
}

/** Owner-scoped tables: readers see their own rows (admins see everything). */
function mayReadRow(
  table: Doc<"tables">,
  row: Doc<"rows"> | null,
  endUser: EndUserContext | null,
): boolean {
  if (table.access !== "owner") return true;
  if (!endUser) return false;
  if (hasPermission(endUser, "*")) return true;
  return row?.ownerId === endUser.user._id;
}

function mayWriteRow(
  table: Doc<"tables">,
  row: Doc<"rows"> | null,
  endUser: EndUserContext | null,
): boolean {
  if (table.access !== "owner" || !endUser) return true;
  if (hasPermission(endUser, "*")) return true;
  return row?.ownerId === endUser.user._id;
}

// ---------------------------------------------------------------------------
// Tables
// ---------------------------------------------------------------------------

export async function listTables(ctx: ActionCtx, c: RestContext): Promise<Response> {
  const tables = await ctx.runQuery(internal.tables.allForApi, {
    projectId: c.principal.project._id,
  });
  return ok({ tables: tables.map(shapeTable), total: tables.length });
}

export async function createTable(ctx: ActionCtx, c: RestContext): Promise<Response> {
  const body = await readJson(c.request);
  const name = typeof body.name === "string" ? body.name : "";
  const result = await ctx.runMutation(internal.tables.createTableFromApi, {
    projectId: c.principal.project._id,
    name,
    description:
      typeof body.description === "string" ? body.description : undefined,
    access: parseAccess(body),
    fields: parseFields(body),
  });

  if (result.status === "invalid") {
    throw new HttpError(400, "invalid_table", result.message);
  }
  if (result.status === "exists") {
    throw new HttpError(409, "table_exists", result.message);
  }
  if (result.status === "full") {
    throw new HttpError(402, "plan_limit", result.message);
  }

  const table = await ctx.runQuery(internal.tables.byId, {
    projectId: c.principal.project._id,
    tableId: result.tableId,
  });
  return json({ ok: true, data: { table: shapeTable(table!) } }, 201);
}

export async function getTable(ctx: ActionCtx, c: RestContext): Promise<Response> {
  const table = await tableByName(ctx, c.principal.project._id, c.params.table);
  return ok({ table: shapeTable(table) });
}

export async function updateTable(ctx: ActionCtx, c: RestContext): Promise<Response> {
  const table = await tableByName(ctx, c.principal.project._id, c.params.table);
  const body = await readJson(c.request);
  const result = await ctx.runMutation(internal.tables.updateTableFromApi, {
    projectId: c.principal.project._id,
    tableId: table._id,
    description: typeof body.description === "string" ? body.description : undefined,
    access: parseAccess(body),
    fields: body.fields === undefined ? undefined : parseFields(body),
  });
  if (result.status === "invalid") {
    throw new HttpError(400, "invalid_table", result.message ?? "Invalid table.");
  }
  if (result.status === "not_found") {
    throw new HttpError(404, "table_not_found", result.message ?? "Table not found.");
  }
  const updated = await ctx.runQuery(internal.tables.byId, {
    projectId: c.principal.project._id,
    tableId: table._id,
  });
  return ok({ table: shapeTable(updated!) });
}

export async function deleteTable(ctx: ActionCtx, c: RestContext): Promise<Response> {
  const table = await tableByName(ctx, c.principal.project._id, c.params.table);
  const result = await ctx.runMutation(internal.tables.deleteTableFromApi, {
    projectId: c.principal.project._id,
    tableId: table._id,
  });
  if (result.status === "not_found") {
    throw new HttpError(404, "table_not_found", result.message ?? "Table not found.");
  }
  return ok({ status: "deleted", table: table.name });
}

// ---------------------------------------------------------------------------
// Rows
// ---------------------------------------------------------------------------

function rowPayload(body: Record<string, unknown>): Record<string, unknown> {
  const data = body.data;
  if (data && typeof data === "object" && !Array.isArray(data)) {
    return data as Record<string, unknown>;
  }
  const rest: Record<string, unknown> = { ...body };
  delete rest.ownerId;
  return rest;
}

export async function listRows(ctx: ActionCtx, c: RestContext): Promise<Response> {
  const projectId = c.principal.project._id;
  const table = await tableByName(ctx, projectId, c.params.table);
  const endUser = await accessFor(ctx, c, table, "read");

  const filters: Array<{ field: string; value: string }> = [];
  for (const [key, value] of c.query.entries()) {
    if (RESERVED_QUERY_KEYS.has(key)) continue;
    if (filters.length >= 10) break;
    if (!table.fields.some((f) => f.name === key)) continue;
    filters.push({ field: key, value });
  }

  const ownerId =
    table.access === "owner" && endUser && !hasPermission(endUser, "*")
      ? endUser.user._id
      : undefined;

  const page = await ctx.runQuery(internal.rows.listRows, {
    projectId,
    tableId: table._id,
    limit: numberParam(c.query.get("limit")),
    offset: numberParam(c.query.get("offset")),
    ownerId,
    filters,
  });
  if (!page) throw new HttpError(404, "table_not_found", "Table not found.");

  return ok({
    table: table.name,
    items: page.items.map(shapeRow),
    total: page.total,
    limit: page.limit,
    offset: page.offset,
  });
}

export async function insertRow(ctx: ActionCtx, c: RestContext): Promise<Response> {
  const projectId = c.principal.project._id;
  const table = await tableByName(ctx, projectId, c.params.table);
  const endUser = await accessFor(ctx, c, table, "write");

  const body = await readJson(c.request);
  const result = await ctx.runMutation(internal.rows.insertRow, {
    projectId,
    tableId: table._id,
    data: rowPayload(body),
    ownerId: endUser?.user._id,
  });
  if (result.status === "invalid") {
    throw new HttpError(400, "invalid_row", result.message);
  }
  if (result.status === "conflict") {
    throw new HttpError(409, "unique_violation", result.message);
  }
  if (result.status === "not_found") {
    throw new HttpError(404, "table_not_found", result.message);
  }

  return json({ ok: true, data: { row: shapeRow(result.row) } }, 201);
}

export async function getRow(ctx: ActionCtx, c: RestContext): Promise<Response> {
  const projectId = c.principal.project._id;
  const table = await tableByName(ctx, projectId, c.params.table);
  const endUser = await accessFor(ctx, c, table, "read");

  const row = await rowOr404(ctx, projectId, c.params.id);
  if (!mayReadRow(table, row, endUser)) {
    throw new HttpError(403, "forbidden", "You can only read your own rows here.");
  }
  return ok({ row: shapeRow(row!) });
}

export async function patchRow(ctx: ActionCtx, c: RestContext): Promise<Response> {
  const projectId = c.principal.project._id;
  const table = await tableByName(ctx, projectId, c.params.table);
  const endUser = await accessFor(ctx, c, table, "write");

  const row = await rowOr404(ctx, projectId, c.params.id);
  if (!mayWriteRow(table, row, endUser)) {
    throw new HttpError(403, "forbidden", "You can only modify your own rows here.");
  }

  const body = await readJson(c.request);
  const result = await ctx.runMutation(internal.rows.patchRow, {
    projectId,
    rowId: row!._id,
    data: rowPayload(body),
  });
  if (result.status === "invalid") {
    throw new HttpError(400, "invalid_row", result.message);
  }
  if (result.status === "conflict") {
    throw new HttpError(409, "unique_violation", result.message);
  }
  if (result.status === "not_found") {
    throw new HttpError(404, "row_not_found", result.message);
  }
  return ok({ row: shapeRow(result.row) });
}

export async function deleteRow(ctx: ActionCtx, c: RestContext): Promise<Response> {
  const projectId = c.principal.project._id;
  const table = await tableByName(ctx, projectId, c.params.table);
  const endUser = await accessFor(ctx, c, table, "write");

  const row = await rowOr404(ctx, projectId, c.params.id);
  if (!mayWriteRow(table, row, endUser)) {
    throw new HttpError(403, "forbidden", "You can only delete your own rows here.");
  }

  const result = await ctx.runMutation(internal.rows.deleteRow, {
    projectId,
    rowId: row!._id,
  });
  if (result.status === "not_found") {
    throw new HttpError(404, "row_not_found", result.message ?? "Row not found.");
  }
  return ok({ status: "deleted", id: row!._id });
}

// ---------------------------------------------------------------------------
// helpers
// ---------------------------------------------------------------------------

function numberParam(value: string | null): number | undefined {
  if (value === null) return undefined;
  const parsed = Number(value);
  if (!Number.isFinite(parsed) || parsed < 0) {
    throw new HttpError(400, "invalid_pagination", "limit/offset must be numbers ≥ 0.");
  }
  if (parsed > FREE_PLAN.maxRowsPerPage) return FREE_PLAN.maxRowsPerPage;
  return Math.floor(parsed);
}

async function rowOr404(
  ctx: ActionCtx,
  projectId: Id<"projects">,
  rowId: string,
): Promise<Doc<"rows"> | null> {
  const valid = /^[A-Za-z0-9_-]{16,64}$/.test(rowId);
  if (!valid) {
    throw new HttpError(
      400,
      "invalid_id",
      "Row ids are the ids returned by FD53.",
    );
  }
  const row = await ctx.runQuery(internal.rows.getRow, {
    projectId,
    rowId: rowId as Id<"rows">,
  });
  if (!row) throw new HttpError(404, "row_not_found", "No row with that id.");
  return row;
}