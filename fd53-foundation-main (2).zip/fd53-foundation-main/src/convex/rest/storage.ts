/**
 * FD53 Storage REST API.
 *
 * Supports three upload styles so FlutterFlow, curl and native clients all
 * work: multipart/form-data, JSON + base64, and a raw binary body.
 */
import type { ActionCtx } from "../_generated/server";
import type { Doc, Id } from "../_generated/dataModel";
import { internal } from "../_generated/api";
import {
  FREE_PLAN,
  STORAGE_BUCKET_LIST,
  bucketDef,
  isValidBucket,
} from "../lib/constants";
import {
  HttpError,
  corsHeaders,
  json,
  maybeEndUser,
  ok,
  readJson,
} from "../lib/rest";
import type { RestContext } from "./types";

const encoder = new TextEncoder();

function indexOfBytes(
  haystack: Uint8Array,
  needle: Uint8Array,
  from: number,
): number {
  outer: for (let i = Math.max(0, from); i <= haystack.length - needle.length; i++) {
    for (let j = 0; j < needle.length; j++) {
      if (haystack[i + j] !== needle[j]) continue outer;
    }
    return i;
  }
  return -1;
}

type ParsedPart = { filename: string; contentType: string; bytes: Uint8Array };

/** Minimal binary-safe multipart/form-data parser (no dependencies). */
async function parseMultipart(
  request: Request,
): Promise<{ file: ParsedPart; fields: Record<string, string> } | null> {
  const contentType = request.headers.get("content-type") ?? "";
  const match = /boundary=(?:"([^"]+)"|([^;]+))/i.exec(contentType);
  if (!match) return null;
  const boundary = `--${(match[1] ?? match[2]).trim()}`;
  const body = new Uint8Array(await request.arrayBuffer());
  const boundaryBytes = encoder.encode(boundary);

  let file: ParsedPart | null = null;
  const fields: Record<string, string> = {};

  let cursor = indexOfBytes(body, boundaryBytes, 0);
  while (cursor !== -1) {
    let cursorStart = cursor + boundaryBytes.length;
    // closing boundary "--"
    if (body[cursorStart] === 45 && body[cursorStart + 1] === 45) break;
    if (body[cursorStart] === 13 && body[cursorStart + 1] === 10) cursorStart += 2;

    const headerEnd = indexOfBytes(body, encoder.encode("\r\n\r\n"), cursorStart);
    if (headerEnd === -1) break;
    const headers = new TextDecoder().decode(body.subarray(cursorStart, headerEnd));
    const contentStart = headerEnd + 4;
    const nextBoundary = indexOfBytes(body, encoder.encode(`\r\n${boundary}`), contentStart);
    const contentEnd = nextBoundary === -1 ? body.length : nextBoundary;

    const disposition = /content-disposition:[^\n]*/i.exec(headers)?.[0] ?? "";
    const nameMatch = /name="([^"]*)"/i.exec(disposition);
    const filenameMatch = /filename="([^"]*)"/i.exec(disposition);
    const typeMatch = /content-type:\s*([^\r\n]+)/i.exec(headers);

    if (filenameMatch && filenameMatch[1]) {
      file = {
        filename: filenameMatch[1],
        contentType: typeMatch?.[1].trim() ?? "application/octet-stream",
        bytes: body.subarray(contentStart, contentEnd),
      };
    } else if (nameMatch) {
      fields[nameMatch[1]] = new TextDecoder().decode(
        body.subarray(contentStart, contentEnd),
      );
    }

    if (nextBoundary === -1) break;
    cursor = nextBoundary + 2;
  }

  return file ? { file, fields } : null;
}

function base64ToBytes(input: string): Uint8Array {
  const cleaned = input.replace(/^data:[^;]+;base64,/, "").replace(/\s+/g, "");
  const binary = atob(cleaned);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

function shapeFile(file: Doc<"files"> & { url: string | null }) {
  return {
    id: file._id,
    name: file.name,
    path: file.path,
    mimeType: file.mimeType,
    size: file.size,
    category: file.category,
    bucket: file.bucket ?? null,
    visibility: file.visibility,
    url: file.url,
    ownerId: file.ownerId ?? null,
    createdAt: file._creationTime,
  };
}

/** Buckets only take images/video/audio; anything else belongs in receipts. */
function assertBucketAccepts(bucket: string, mime: string): void {
  const def = bucketDef(bucket);
  if (def && def.accepts === "media" && !/^(image|video|audio)\//.test(mime)) {
    throw new HttpError(
      400,
      "unsupported_media_type",
      `The "${bucket}" bucket only accepts image, video or audio files (got "${mime}").`,
    );
  }
}

// ---------------------------------------------------------------------------
// POST /v1/storage/upload
// ---------------------------------------------------------------------------

export async function upload(ctx: ActionCtx, c: RestContext): Promise<Response> {
  const projectId = c.principal.project._id;
  const contentType = c.request.headers.get("content-type") ?? "";

  let bytes: Uint8Array;
  let filename: string;
  let mime: string;
  let visibility: "public" | "private" =
    c.query.get("visibility") === "public" ? "public" : "private";
  let bucket = c.query.get("bucket") ?? undefined;

  if (contentType.startsWith("multipart/form-data")) {
    const parsed = await parseMultipart(c.request);
    if (!parsed) {
      throw new HttpError(
        400,
        "invalid_multipart",
        'multipart upload needs a file part (name="file").',
      );
    }
    bytes = parsed.file.bytes;
    filename = parsed.file.filename || "upload.bin";
    mime = parsed.file.contentType;
    if (parsed.fields.visibility === "public" || parsed.fields.visibility === "private") {
      visibility = parsed.fields.visibility;
    }
    if (parsed.fields.bucket) bucket = parsed.fields.bucket;
  } else if (contentType.includes("application/json")) {
    const body = await readJson(c.request);
    const contentBase64 = body.contentBase64;
    if (typeof contentBase64 !== "string") {
      throw new HttpError(
        400,
        "missing_content",
        'JSON uploads need "contentBase64" (plus optional "path" and "mimeType").',
      );
    }
    bytes = base64ToBytes(contentBase64);
    filename =
      typeof body.path === "string" && body.path
        ? body.path
        : typeof body.name === "string" && body.name
          ? body.name
          : "upload.bin";
    mime = typeof body.mimeType === "string" ? body.mimeType : "application/octet-stream";
    if (body.visibility === "public" || body.visibility === "private") {
      visibility = body.visibility;
    }
    if (typeof body.bucket === "string" && body.bucket) bucket = body.bucket;
  } else {
    bytes = new Uint8Array(await c.request.arrayBuffer());
    filename = c.query.get("path") ?? c.query.get("name") ?? "upload.bin";
    mime = contentType || "application/octet-stream";
  }

  if (bucket) {
    if (!isValidBucket(bucket)) {
      throw new HttpError(
        400,
        "invalid_bucket",
        `Unknown bucket "${bucket}". Available: ${STORAGE_BUCKET_LIST.map(
          (b) => b.name,
        ).join(", ")}.`,
      );
    }
    assertBucketAccepts(bucket, mime);
    // The bucket dictates visibility — ignore any caller-supplied value.
    visibility = bucketDef(bucket)!.visibility;
  }

  if (bytes.length === 0) {
    throw new HttpError(400, "empty_file", "The uploaded file is empty.");
  }
  if (bytes.length > FREE_PLAN.maxUploadBytes) {
    throw new HttpError(
      413,
      "file_too_large",
      `Single uploads are capped at ${Math.floor(FREE_PLAN.maxUploadBytes / 1024 / 1024)} MB on the free plan.`,
    );
  }

  const endUser = await maybeEndUser(ctx, c.request, projectId);
  const storageId = await ctx.storage.store(
    new Blob([bytes as BlobPart], { type: mime }),
  );

  const result = await ctx.runMutation(internal.files.createFromApi, {
    projectId,
    name: filename.slice(0, 200),
    path: filename,
    mimeType: mime,
    size: bytes.length,
    storageId,
    visibility,
    ownerId: endUser?.user._id,
    bucket,
  });

  if (result.status !== "created") {
    // Quota/invalid — drop the blob we just stored so it isn't orphaned.
    try {
      await ctx.storage.delete(storageId);
    } catch {
      // best effort
    }
    if (result.status === "quota") {
      throw new HttpError(
        413,
        "storage_quota_exceeded",
        `${result.message} Used ${result.used ?? 0} of ${result.limit ?? 0} bytes.`,
      );
    }
    throw new HttpError(400, "invalid_file", result.message);
  }

  return json(
    { ok: true, data: { file: shapeFile(result.file as never), url: result.url } },
    201,
  );
}

// ---------------------------------------------------------------------------
// GET /v1/storage/files  |  GET /v1/storage/files/:id  |  DELETE
// ---------------------------------------------------------------------------

export async function listFiles(ctx: ActionCtx, c: RestContext): Promise<Response> {
  const projectId = c.principal.project._id;
  const endUser = await maybeEndUser(ctx, c.request, projectId);
  const requestedOwner = c.query.get("ownerId");

  // End users can only list their own files unless the caller also holds the
  // storage:read permission for the project-wide view.
  const scopeToSelf =
    endUser && !endUser.permissions.includes("*") && requestedOwner !== "all";

  const result = await ctx.runQuery(internal.files.listForApi, {
    projectId,
    prefix: c.query.get("prefix") ?? undefined,
    limit: c.query.get("limit") ? Number(c.query.get("limit")) : undefined,
    ownerId: scopeToSelf ? endUser.user._id : undefined,
    bucket: c.query.get("bucket") ?? undefined,
  });

  return ok({
    total: result.total,
    files: result.files.map(shapeFile),
    storage: {
      used: c.principal.project.storageBytes,
      limit: c.principal.project.storageLimitBytes,
    },
  });
}

// ---------------------------------------------------------------------------
// GET /v1/storage/buckets
// ---------------------------------------------------------------------------

export async function listBuckets(ctx: ActionCtx, c: RestContext): Promise<Response> {
  const stats = await ctx.runQuery(internal.files.bucketStats, {
    projectId: c.principal.project._id,
  });
  return ok({
    buckets: stats,
    total: stats.length,
    storage: {
      used: c.principal.project.storageBytes,
      limit: c.principal.project.storageLimitBytes,
    },
  });
}

export async function getFile(ctx: ActionCtx, c: RestContext): Promise<Response> {
  const projectId = c.principal.project._id;
  if (!fileIdPattern(c.params.id)) {
    throw new HttpError(400, "invalid_id", "File ids come from FD53 uploads.");
  }
  const file = await ctx.runQuery(internal.files.byId, {
    projectId,
    fileId: c.params.id as Id<"files">,
  });
  if (!file) throw new HttpError(404, "file_not_found", "No file with that id.");

  if (file.visibility === "private") {
    const endUser = await maybeEndUser(ctx, c.request, projectId);
    const permitted =
      endUser === null ||
      endUser.permissions.includes("*") ||
      file.ownerId === endUser.user._id;
    if (!permitted) {
      throw new HttpError(403, "forbidden", "This file is private.");
    }
  }

  if (c.query.get("redirect") === "true" && file.url) {
    return new Response(null, {
      status: 302,
      headers: { Location: file.url, ...corsHeaders() },
    });
  }
  return ok({ file: shapeFile(file as never) });
}

export async function deleteFile(ctx: ActionCtx, c: RestContext): Promise<Response> {
  const projectId = c.principal.project._id;
  if (!fileIdPattern(c.params.id)) {
    throw new HttpError(400, "invalid_id", "File ids come from FD53 uploads.");
  }
  const result = await ctx.runMutation(internal.files.removeFromApi, {
    projectId,
    fileId: c.params.id as Id<"files">,
  });
  if (result.status === "not_found") {
    throw new HttpError(404, "file_not_found", result.message ?? "File not found.");
  }
  return ok({ status: "deleted", id: c.params.id });
}

function fileIdPattern(value: string): boolean {
  return /^[A-Za-z0-9_-]{16,64}$/.test(value);
}