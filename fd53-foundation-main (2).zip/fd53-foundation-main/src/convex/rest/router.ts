/**
 * FD53 REST router.
 *
 * The router is responsible for exactly two things: matching a request to a
 * route, and handing it to the gateway. Every security control — WAF, per-IP
 * flood limiting, `X-API-Key` validation, scope checks, quota enforcement,
 * audit logging, security headers — lives in `./gateway.ts`. Keeping the two
 * apart means a new route inherits the full security posture for free, and
 * there is no way to add an endpoint that quietly skips it.
 *
 * Handlers throw `HttpError` for client problems; the gateway converts
 * anything else into a 500 so internal details never leak.
 */
import type { ActionCtx } from "../_generated/server";
import { fail } from "../lib/rest";
import { runGateway, preflight } from "./gateway";
import type { RestContext, RestRoute } from "./types";
import * as authRoutes from "./auth";
import * as dbRoutes from "./database";
import * as storageRoutes from "./storage";
import * as realtimeRoutes from "./realtime";
import * as metaRoutes from "./meta";
import * as socialRoutes from "./social";
import * as marketplaceRoutes from "./marketplace";
import { openapiDocument } from "./openapi";

type Category = string;

type Handler = (
  ctx: ActionCtx,
  c: RestContext,
) => Promise<Response> | Response;

type Route = RestRoute & {
  method: string;
  segments: string[];
  scope: string;
  category: Category;
  handler: Handler;
};

const apiKeyScopes = "db";
const ALL = ["*"];

function matchSegments(
  pattern: string[],
  actual: string[],
): Record<string, string> | null {
  if (pattern.length !== actual.length) return null;
  const params: Record<string, string> = {};
  for (let i = 0; i < pattern.length; i++) {
    const expected = pattern[i];
    if (expected.startsWith(":")) {
      params[expected.slice(1)] = decodeURIComponent(actual[i]);
    } else if (expected !== actual[i]) {
      return null;
    }
  }
  return params;
}

export const ROUTES: Route[] = [
  // --- system -------------------------------------------------------------
  {
    method: "GET",
    segments: ["v1", "health"],
    scope: "",
    category: "system",
    handler: (ctx, c) => metaRoutes.health(c.request),
  },
  {
    method: "GET",
    segments: ["v1"],
    scope: "",
    category: "system",
    handler: (ctx, c) => metaRoutes.root(c.request),
  },
  {
    method: "GET",
    segments: ["v1", "usage"],
    scope: "usage",
    category: "system",
    handler: metaRoutes.usage,
  },
  {
    // Public on purpose: SDK generators, Postman and Swagger UI need to read
    // the spec before they have a key. It contains no project data.
    method: "GET",
    segments: ["v1", "openapi.json"],
    scope: "",
    category: "system",
    handler: metaRoutes.openapi,
  },

  // --- auth ---------------------------------------------------------------
  {
    method: "POST",
    segments: ["v1", "auth", "register"],
    scope: "auth",
    category: "auth",
    handler: authRoutes.register,
  },
  {
    method: "POST",
    segments: ["v1", "auth", "login"],
    scope: "auth",
    category: "auth",
    handler: authRoutes.login,
  },
  {
    method: "POST",
    segments: ["v1", "auth", "otp", "request"],
    scope: "auth",
    category: "auth",
    handler: authRoutes.otpRequest,
  },
  {
    method: "POST",
    segments: ["v1", "auth", "otp", "verify"],
    scope: "auth",
    category: "auth",
    handler: authRoutes.otpVerify,
  },
  {
    method: "GET",
    segments: ["v1", "auth", "me"],
    scope: "auth",
    category: "auth",
    handler: authRoutes.me,
  },
  {
    method: "POST",
    segments: ["v1", "auth", "logout"],
    scope: "auth",
    category: "auth",
    handler: authRoutes.logout,
  },
  {
    method: "POST",
    segments: ["v1", "auth", "token", "verify"],
    scope: "auth",
    category: "auth",
    handler: authRoutes.verifyToken,
  },
  {
    method: "POST",
    segments: ["v1", "auth", "password"],
    scope: "auth",
    category: "auth",
    handler: authRoutes.changePassword,
  },
  {
    method: "POST",
    segments: ["v1", "auth", "password", "reset"],
    scope: "auth",
    category: "auth",
    handler: authRoutes.requestReset,
  },
  {
    method: "POST",
    segments: ["v1", "auth", "password", "reset", "confirm"],
    scope: "auth",
    category: "auth",
    handler: authRoutes.confirmReset,
  },
  {
    method: "GET",
    segments: ["v1", "auth", "roles"],
    scope: "auth",
    category: "auth",
    handler: authRoutes.roles,
  },

  // --- database schema ----------------------------------------------------
  {
    method: "GET",
    segments: ["v1", "db", "tables"],
    scope: apiKeyScopes,
    category: "database",
    handler: dbRoutes.listTables,
  },
  {
    method: "POST",
    segments: ["v1", "db", "tables"],
    scope: apiKeyScopes,
    category: "database",
    handler: dbRoutes.createTable,
  },
  {
    method: "GET",
    segments: ["v1", "db", "tables", ":table"],
    scope: apiKeyScopes,
    category: "database",
    handler: dbRoutes.getTable,
  },
  {
    method: "PATCH",
    segments: ["v1", "db", "tables", ":table"],
    scope: apiKeyScopes,
    category: "database",
    handler: dbRoutes.updateTable,
  },
  {
    method: "DELETE",
    segments: ["v1", "db", "tables", ":table"],
    scope: apiKeyScopes,
    category: "database",
    handler: dbRoutes.deleteTable,
  },

  // --- database rows ------------------------------------------------------
  {
    method: "GET",
    segments: ["v1", "db", ":table"],
    scope: apiKeyScopes,
    category: "database",
    handler: dbRoutes.listRows,
  },
  {
    method: "POST",
    segments: ["v1", "db", ":table"],
    scope: apiKeyScopes,
    category: "database",
    handler: dbRoutes.insertRow,
  },
  {
    method: "GET",
    segments: ["v1", "db", ":table", ":id"],
    scope: apiKeyScopes,
    category: "database",
    handler: dbRoutes.getRow,
  },
  {
    method: "PATCH",
    segments: ["v1", "db", ":table", ":id"],
    scope: apiKeyScopes,
    category: "database",
    handler: dbRoutes.patchRow,
  },
  {
    method: "DELETE",
    segments: ["v1", "db", ":table", ":id"],
    scope: apiKeyScopes,
    category: "database",
    handler: dbRoutes.deleteRow,
  },

  // --- storage ------------------------------------------------------------
  {
    method: "GET",
    segments: ["v1", "storage", "buckets"],
    scope: "storage",
    category: "storage",
    handler: storageRoutes.listBuckets,
  },
  {
    method: "POST",
    segments: ["v1", "storage", "upload"],
    scope: "storage",
    category: "storage",
    handler: storageRoutes.upload,
  },
  {
    method: "GET",
    segments: ["v1", "storage", "files"],
    scope: "storage",
    category: "storage",
    handler: storageRoutes.listFiles,
  },
  {
    method: "GET",
    segments: ["v1", "storage", "files", ":id"],
    scope: "storage",
    category: "storage",
    handler: storageRoutes.getFile,
  },
  {
    method: "DELETE",
    segments: ["v1", "storage", "files", ":id"],
    scope: "storage",
    category: "storage",
    handler: storageRoutes.deleteFile,
  },

  // --- realtime -----------------------------------------------------------
  {
    method: "POST",
    segments: ["v1", "realtime", "publish"],
    scope: "realtime",
    category: "realtime",
    handler: realtimeRoutes.publish,
  },
  {
    method: "GET",
    segments: ["v1", "realtime", "channels"],
    scope: "realtime",
    category: "realtime",
    handler: realtimeRoutes.listChannels,
  },
  {
    method: "GET",
    segments: ["v1", "realtime", "channels", ":channel", "events"],
    scope: "realtime",
    category: "realtime",
    handler: realtimeRoutes.listEvents,
  },

  // --- LoopUni: profiles + social graph ----------------------------------
  // Literal routes are registered before `:param` routes so
  // `/v1/users/profile/:username` always wins over `/v1/users/:id/…`.
  {
    method: "GET",
    segments: ["v1", "users", "profile", ":username"],
    scope: apiKeyScopes,
    category: "social",
    handler: socialRoutes.getProfile,
  },
  {
    method: "POST",
    segments: ["v1", "users", ":id", "follow"],
    scope: apiKeyScopes,
    category: "social",
    handler: socialRoutes.followUser,
  },
  {
    method: "POST",
    segments: ["v1", "users", ":id", "unfollow"],
    scope: apiKeyScopes,
    category: "social",
    handler: socialRoutes.unfollowUser,
  },

  // --- LoopUni: posts + feed ---------------------------------------------
  {
    method: "POST",
    segments: ["v1", "posts", "create"],
    scope: apiKeyScopes,
    category: "social",
    handler: socialRoutes.createPost,
  },
  {
    method: "GET",
    segments: ["v1", "posts", ":id"],
    scope: apiKeyScopes,
    category: "social",
    handler: socialRoutes.getPost,
  },
  {
    method: "GET",
    segments: ["v1", "feed", "home"],
    scope: apiKeyScopes,
    category: "social",
    handler: socialRoutes.homeFeed,
  },

  // --- LoopUni: messaging + moderation -----------------------------------
  {
    method: "POST",
    segments: ["v1", "messages", "send"],
    scope: apiKeyScopes,
    category: "social",
    handler: socialRoutes.sendMessage,
  },
  {
    method: "GET",
    segments: ["v1", "messages", ":roomId"],
    scope: apiKeyScopes,
    category: "social",
    handler: socialRoutes.listMessages,
  },
  {
    method: "POST",
    segments: ["v1", "reports", "create"],
    scope: apiKeyScopes,
    category: "social",
    handler: socialRoutes.createReport,
  },

  // --- LoopUni: marketplace ----------------------------------------------
  {
    method: "POST",
    segments: ["v1", "marketplace", "products"],
    scope: apiKeyScopes,
    category: "marketplace",
    handler: marketplaceRoutes.createProduct,
  },
  {
    method: "GET",
    segments: ["v1", "marketplace", "products"],
    scope: apiKeyScopes,
    category: "marketplace",
    handler: marketplaceRoutes.listProducts,
  },
  {
    method: "GET",
    segments: ["v1", "marketplace", "products", ":id"],
    scope: apiKeyScopes,
    category: "marketplace",
    handler: marketplaceRoutes.getProduct,
  },
  {
    method: "POST",
    segments: ["v1", "marketplace", "orders", "checkout"],
    scope: apiKeyScopes,
    category: "marketplace",
    handler: marketplaceRoutes.checkout,
  },
  {
    method: "GET",
    segments: ["v1", "marketplace", "orders"],
    scope: apiKeyScopes,
    category: "marketplace",
    handler: marketplaceRoutes.listOrders,
  },
  {
    method: "GET",
    segments: ["v1", "marketplace", "earnings"],
    scope: apiKeyScopes,
    category: "marketplace",
    handler: marketplaceRoutes.earnings,
  },
];

/** Canonical route pattern, used for logging and dashboard grouping. */
export function routeLabel(route: Route): string {
  return "/" + route.segments.join("/");
}

/** CORS preflight for browsers (FlutterFlow web builds, native apps ignore it). */
export function options(request: Request): Response {
  return preflight(request);
}

/**
 * Match a request to a route and run it through the gateway.
 *
 * On a miss this returns a plain 404 with the platform's error envelope; a
 * matched route gets the full gateway pipeline (WAF, throttling, API-key
 * validation, quota, audit, security headers).
 */
export async function handle(
  ctx: ActionCtx,
  request: Request,
  method: string,
): Promise<Response> {
  const url = new URL(request.url);
  const segments = url.pathname.split("/").filter(Boolean);

  for (const route of ROUTES) {
    if (route.method !== method) continue;
    const params = matchSegments(route.segments, segments);
    if (!params) continue;

    return await runGateway({
      ctx,
      request,
      method,
      route: {
        label: routeLabel(route),
        scope: route.scope,
        category: route.category as never,
      },
      dispatch: (rest) =>
        route.handler(ctx, { ...rest, params, query: url.searchParams }),
    });
  }

  // Unmatched: still run it through the gateway so a probe cannot enumerate
  // endpoints without hitting the WAF and per-IP throttle. Scope is empty so a
  // missing route reports 404 rather than 401 — a client with a bad path should
  // not be told its credentials are the problem.
  return await runGateway({
    ctx,
    request,
    method,
    route: {
      label: "unmatched",
      scope: "",
      category: "system",
    },
    dispatch: () =>
      fail(
        404,
        "not_found",
        `No FD53 endpoint matches ${method} ${url.pathname}. See /dashboard/docs for the API reference.`,
      ),
  });
}

export { ALL as DEFAULT_SCOPES };
export { openapiDocument };