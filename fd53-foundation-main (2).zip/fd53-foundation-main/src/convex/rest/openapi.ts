/**
 * FD53 OpenAPI 3.1 specification.
 *
 * The document is *generated from the live route table* rather than
 * hand-maintained, so it can never drift from what the router actually serves:
 * add a route to `ROUTES`, describe it here, and the spec updates itself.
 *
 * Serve it from `GET /v1/openapi.json` (public — no API key) and point
 * Swagger UI, Postman, FlutterFlow's API import and code generators at that
 * URL. This is also the input to the SDK generator.
 */
import { FD53_VERSION, FREE_PLAN, STORAGE_BUCKET_LIST } from "../lib/constants";
import { KNOWN_PERMISSIONS } from "../lib/constants";
import { ROUTES } from "./router";

/** Server the spec describes. Overridden per deployment. */
export const OPENAPI_SERVERS = [
  { url: "https://api.fd53.dev/v1", description: "Production" },
  { url: "https://staging.fd53.dev/v1", description: "Staging" },
];

// ---------------------------------------------------------------------------
// Reusable components
// ---------------------------------------------------------------------------

const errorResponse = {
  type: "object",
  required: ["ok", "error"],
  properties: {
    ok: { type: "boolean", const: false },
    error: {
      type: "object",
      required: ["code", "message"],
      properties: {
        code: {
          type: "string",
          description: "Machine-readable error code.",
          examples: [
            "missing_api_key",
            "invalid_api_key",
            "insufficient_scope",
            "forbidden",
            "validation_error",
          ],
        },
        message: { type: "string", description: "Human-readable explanation." },
      },
    },
  },
};

/** The standard `ok: true` envelope wrapping every successful response. */
const successEnvelope = (dataSchema: unknown) => ({
  type: "object",
  required: ["ok", "data"],
  properties: {
    ok: { type: "boolean", const: true },
    data: dataSchema,
  },
});

const components = {
  securitySchemes: {
    apiKey: {
      type: "apiKey",
      in: "header",
      name: "X-API-Key",
      description:
        "Your FD53 server-side API key. Minted in the developer dashboard and shown once. " +
        "Keys look like `fd53_live_<40 hex characters>` and are stored hashed (SHA-256) — " +
        "FD53 never stores or displays the plaintext again. " +
        "You may also send it as `Authorization: Bearer fd53_live_…`.",
    },
    endUserToken: {
      type: "http",
      scheme: "bearer",
      bearerFormat: "JWT",
      description:
        "An end-user access token issued by `/v1/auth/login` or `/v1/auth/register`. " +
        "This authenticates *your app's users*; the API key authenticates *your backend*. " +
        "Send it as `Authorization: Bearer <token>` alongside `X-API-Key`.",
    },
  },
  schemas: {
    Error: errorResponse,

    // --- Auth -------------------------------------------------------------
    RegisterRequest: {
      type: "object",
      required: ["email", "password"],
      properties: {
        email: { type: "string", format: "email", example: "sam@example.com" },
        password: {
          type: "string",
          format: "password",
          minLength: 8,
          maxLength: 200,
          description: "Stored as PBKDF2-SHA256 (60,000 iterations, 16-byte salt).",
        },
        name: { type: "string", maxLength: 120, example: "Sam Rivera" },
        phone: {
          type: "string",
          description: "E.164 format.",
          example: "+15551234567",
        },
        username: {
          type: "string",
          description: "Optional @handle, unique per project.",
          example: "sam_r",
        },
        data: {
          type: "object",
          additionalProperties: true,
          description: "Free-form profile data stored on the end-user record.",
        },
      },
    },
    LoginRequest: {
      type: "object",
      required: ["email", "password"],
      properties: {
        email: { type: "string", format: "email" },
        password: { type: "string", format: "password" },
      },
    },
    /**
     * The credential fields returned by `/auth/register` and `/auth/login`.
     * These are flat siblings of `user` and `profile`, not a nested `session`
     * object — the spec mirrors the live response exactly.
     */
    Session: {
      type: "object",
      description:
        "Credential fields returned by register and login. Persist `token` and send it as `Authorization: Bearer <token>`.",
      properties: {
        token: {
          type: "string",
          description:
            "HS256 JWT bound to a revocable server-side session. Send as `Authorization: Bearer <token>`.",
        },
        expiresIn: {
          type: "integer",
          description: "Access-token lifetime in seconds (86400 = 24 hours).",
          example: 86400,
        },
        sessionId: {
          type: "string",
          description: "Server-side session id embedded in the token.",
        },
      },
    },
    EndUser: {
      type: "object",
      properties: {
        id: { type: "string", example: "kg2ab1c9…" },
        email: { type: "string", nullable: true },
        phone: { type: "string", nullable: true },
        name: { type: "string", nullable: true },
        role: { type: "string", example: "user" },
        status: { type: "string", enum: ["active", "banned"] },
        permissions: {
          type: "array",
          items: { type: "string" },
          example: ["db:read", "db:write", "storage:read", "storage:write"],
        },
        profile: { type: "object", additionalProperties: true, nullable: true },
        createdAt: { type: "integer", format: "int64" },
        lastLoginAt: { type: "integer", format: "int64", nullable: true },
      },
    },

    // --- Database ---------------------------------------------------------
    FieldDef: {
      type: "object",
      required: ["name", "type"],
      properties: {
        name: { type: "string", pattern: "^[a-z][a-z0-9_]{0,63}$" },
        type: {
          type: "string",
          enum: ["string", "number", "boolean", "datetime", "json", "reference"],
        },
        required: { type: "boolean", default: false },
        unique: { type: "boolean", default: false },
        refTable: {
          type: "string",
          description: "Target table for `reference` columns.",
        },
        description: { type: "string" },
      },
    },
    Table: {
      type: "object",
      properties: {
        id: { type: "string" },
        name: { type: "string" },
        description: { type: "string", nullable: true },
        access: {
          type: "string",
          enum: ["public", "authenticated", "owner"],
          description:
            "Row visibility. `public` needs no end-user token. `authenticated` needs any valid token. " +
            "`owner` restricts reads and writes to the row's creator.",
        },
        fields: { type: "array", items: { $ref: "#/components/schemas/FieldDef" } },
        rowCount: { type: "integer" },
        createdAt: { type: "integer", format: "int64" },
      },
    },
    Row: {
      type: "object",
      additionalProperties: true,
      description:
        "A schema-on-write document. `_id` and `_creationTime` are managed by FD53.",
      properties: {
        _id: { type: "string" },
        _creationTime: { type: "integer", format: "int64" },
        ownerId: { type: "string", nullable: true },
      },
    },
    RowPage: {
      type: "object",
      properties: {
        table: { type: "string" },
        items: { type: "array", items: { $ref: "#/components/schemas/Row" } },
        total: { type: "integer" },
        limit: { type: "integer" },
        offset: { type: "integer" },
      },
    },

    // --- Storage ----------------------------------------------------------
    File: {
      type: "object",
      properties: {
        id: { type: "string" },
        name: { type: "string" },
        path: { type: "string" },
        mimeType: { type: "string", example: "image/jpeg" },
        size: { type: "integer", format: "int64" },
        category: {
          type: "string",
          enum: ["image", "video", "audio", "document", "other"],
        },
        bucket: {
          type: "string",
          enum: STORAGE_BUCKET_LIST.map((b) => b.name),
        },
        visibility: { type: "string", enum: ["public", "private"] },
        url: { type: "string", nullable: true },
        ownerId: { type: "string", nullable: true },
        createdAt: { type: "integer", format: "int64" },
      },
    },
    Bucket: {
      type: "object",
      properties: {
        name: { type: "string" },
        visibility: { type: "string", enum: ["public", "private"] },
        description: { type: "string" },
        fileCount: { type: "integer" },
        bytes: { type: "integer", format: "int64" },
      },
    },
  },
  responses: {
    BadRequest: { description: "Malformed request.", content: { "application/json": { schema: { $ref: "#/components/schemas/Error" } } } },
    Unauthorized: { description: "Missing or invalid API key / end-user token.", content: { "application/json": { schema: { $ref: "#/components/schemas/Error" } } } },
    Forbidden: { description: "Authenticated but not permitted (scope, role, IP or origin policy).", content: { "application/json": { schema: { $ref: "#/components/schemas/Error" } } } },
    NotFound: { description: "Resource does not exist.", content: { "application/json": { schema: { $ref: "#/components/schemas/Error" } } } },
    RateLimited: { description: "Rate limit exceeded. Includes a `Retry-After` header.", headers: { "Retry-After": { schema: { type: "integer" }, description: "Seconds to wait." } }, content: { "application/json": { schema: { $ref: "#/components/schemas/Error" } } } },
  },
  parameters: {
    RequestId: {
      name: "X-FD53-Request-Id",
      in: "header",
      required: false,
      schema: { type: "string" },
      description:
        "Correlation id. Send one to have it echoed back and recorded in the audit trail.",
    },
    ApiVersion: {
      name: "X-FD53-Api-Version",
      in: "header",
      required: false,
      schema: { type: "string", enum: ["2024-01-01", "2024-06-01"] },
      description: "Pinned API version. Defaults to the latest.",
    },
  },
} as const;

// ---------------------------------------------------------------------------
// Per-route documentation
// ---------------------------------------------------------------------------

type OperationDoc = {
  summary: string;
  description?: string;
  tags?: string[];
  requestBody?: unknown;
  parameters?: unknown[];
  responses?: Record<string, unknown>;
};

/**
 * Hand-written detail for the Auth, Storage and Database endpoints — the
 * surface SDK generators and FlutterFlow consume.
 *
 * Anything not listed here still appears in the spec, generated from the route
 * table with a generic description, so the document is always complete.
 */
const OPERATION_DOCS: Record<string, OperationDoc> = {
  // --- system ------------------------------------------------------------
  "GET /": {
    summary: "Service index",
    description: "Lists every FD53 endpoint grouped by module. No API key required.",
    tags: ["System"],
    responses: { 200: { description: "Service metadata.", content: { "application/json": { schema: successEnvelope({ type: "object", additionalProperties: true }) } } } },
  },
  "GET /health": {
    summary: "Health check",
    description: "Liveness probe for the FD53 API. No API key required.",
    tags: ["System"],
    responses: { 200: { description: "Service is operational.", content: { "application/json": { schema: successEnvelope({ type: "object", properties: { status: { type: "string", example: "operational" }, version: { type: "string", example: FD53_VERSION } } }) } } } },
  },
  "GET /openapi.json": {
    summary: "This OpenAPI document",
    description:
      "Returns the full OpenAPI 3.1 specification. Point Swagger UI, Postman or any SDK generator at this URL.",
    tags: ["System"],
    responses: { 200: { description: "OpenAPI 3.1 document.", content: { "application/json": { schema: { type: "object", additionalProperties: true } } } } },
  },

  // --- auth --------------------------------------------------------------
  "POST /auth/register": {
    summary: "Create an end user",
    description:
      "Registers a user and returns a session in one call. The password is hashed with PBKDF2-SHA256 and never stored or returned in plaintext.",
    tags: ["Auth"],
    requestBody: {
      required: true,
      content: { "application/json": { schema: { $ref: "#/components/schemas/RegisterRequest" } } },
    },
    responses: {
      201: { description: "User created.", content: { "application/json": { schema: successEnvelope({ type: "object", properties: { user: { $ref: "#/components/schemas/EndUser" }, profile: { type: "object", additionalProperties: true, nullable: true }, token: { type: "string", description: "Access token — send as `Authorization: Bearer <token>`." }, expiresIn: { type: "integer", example: 86400 }, sessionId: { type: "string" } } }) } } },
      400: { $ref: "#/components/responses/BadRequest" },
      409: { description: "Email or username already taken.", content: { "application/json": { schema: { $ref: "#/components/schemas/Error" } } } },
      429: { $ref: "#/components/responses/RateLimited" },
    },
  },
  "POST /auth/login": {
    summary: "Sign in",
    description:
      "Exchanges credentials for an access token. Repeated failures lock the account for 15 minutes after 10 attempts.",
    tags: ["Auth"],
    requestBody: {
      required: true,
      content: { "application/json": { schema: { $ref: "#/components/schemas/LoginRequest" } } },
    },
    responses: {
      200: { description: "Signed in.", content: { "application/json": { schema: successEnvelope({ type: "object", properties: { user: { $ref: "#/components/schemas/EndUser" }, profile: { type: "object", additionalProperties: true, nullable: true }, token: { type: "string", description: "Access token — send as `Authorization: Bearer <token>`." }, expiresIn: { type: "integer", example: 86400 }, sessionId: { type: "string" } } }) } } },
      401: { $ref: "#/components/responses/Unauthorized" },
      429: { $ref: "#/components/responses/RateLimited" },
    },
  },
  "POST /auth/otp/request": {
    summary: "Send a phone OTP",
    description: "Creates a one-time code challenge. Codes are HMAC-peppered at rest and expire after 10 minutes.",
    tags: ["Auth"],
    requestBody: { required: true, content: { "application/json": { schema: { type: "object", required: ["phone"], properties: { phone: { type: "string", example: "+15551234567" } } } } } },
    responses: { 200: { description: "Code sent." }, 400: { $ref: "#/components/responses/BadRequest" }, 429: { $ref: "#/components/responses/RateLimited" } },
  },
  "POST /auth/otp/verify": {
    summary: "Verify a phone OTP",
    description: "Consumes the code and returns a session. Five wrong attempts invalidate the challenge.",
    tags: ["Auth"],
    requestBody: { required: true, content: { "application/json": { schema: { type: "object", required: ["phone", "code"], properties: { phone: { type: "string" }, code: { type: "string", minLength: 4, maxLength: 8 } } } } } },
    responses: { 200: { description: "Verified.", content: { "application/json": { schema: successEnvelope({ type: "object", properties: { user: { $ref: "#/components/schemas/EndUser" }, token: { type: "string" }, expiresIn: { type: "integer", example: 86400 }, sessionId: { type: "string" } } }) } } }, 401: { $ref: "#/components/responses/Unauthorized" } },
  },
  "GET /auth/me": {
    summary: "Current end user",
    description: "Resolves the end-user token and returns the profile plus effective permissions.",
    tags: ["Auth"],
    responses: { 200: { description: "The authenticated user.", content: { "application/json": { schema: successEnvelope({ type: "object", properties: { user: { $ref: "#/components/schemas/EndUser" } } }) } } }, 401: { $ref: "#/components/responses/Unauthorized" } },
  },
  "POST /auth/logout": {
    summary: "Revoke the current session",
    description: "Marks the session revoked server-side. The access token stops working immediately, without waiting for expiry.",
    tags: ["Auth"],
    responses: { 200: { description: "Signed out." }, 401: { $ref: "#/components/responses/Unauthorized" } },
  },
  "POST /auth/token/verify": {
    summary: "Verify an access token",
    description: "Cheap server-to-server token check for a backend that did not issue the token.",
    tags: ["Auth"],
    responses: { 200: { description: "Token is valid.", content: { "application/json": { schema: successEnvelope({ type: "object", properties: { valid: { type: "boolean" }, userId: { type: "string" } } }) } } }, 401: { $ref: "#/components/responses/Unauthorized" } },
  },
  "POST /auth/password": {
    summary: "Change password",
    description: "Requires the current password and bumps `tokenVersion`, revoking every other session.",
    tags: ["Auth"],
    responses: { 200: { description: "Password changed." }, 400: { $ref: "#/components/responses/BadRequest" }, 401: { $ref: "#/components/responses/Unauthorized" } },
  },
  "POST /auth/password/reset": {
    summary: "Request a password reset",
    description: "Creates a single-use token valid for 30 minutes. Delivery is provider-configured.",
    tags: ["Auth"],
    responses: { 200: { description: "Reset requested." }, 400: { $ref: "#/components/responses/BadRequest" }, 429: { $ref: "#/components/responses/RateLimited" } },
  },
  "POST /auth/password/reset/confirm": {
    summary: "Complete a password reset",
    description: "Consumes the reset token, sets the new password and revokes all sessions.",
    tags: ["Auth"],
    responses: { 200: { description: "Password reset." }, 400: { $ref: "#/components/responses/BadRequest" } },
  },
  "GET /auth/roles": {
    summary: "List project roles",
    description: "Returns the role/permission matrix configured for this project.",
    tags: ["Auth"],
    responses: { 200: { description: "Roles.", content: { "application/json": { schema: successEnvelope({ type: "array", items: { type: "object", properties: { name: { type: "string" }, permissions: { type: "array", items: { type: "string", enum: [...KNOWN_PERMISSIONS] } }, isDefault: { type: "boolean" } } } }) } } } },
  },

  // --- database: schema --------------------------------------------------
  "GET /db/tables": {
    summary: "List tables",
    description: `Every table in the project with its column definitions and row count. Maximum ${FREE_PLAN.maxTablesPerProject} tables on the free plan.`,
    tags: ["Database"],
    responses: { 200: { description: "Tables.", content: { "application/json": { schema: successEnvelope({ type: "object", properties: { tables: { type: "array", items: { $ref: "#/components/schemas/Table" } }, total: { type: "integer" } } }) } } } },
  },
  "POST /db/tables": {
    summary: "Create a table",
    description: "Schema-on-write. Columns marked `unique` are enforced through a materialised unique index, so a duplicate returns 409 instead of a race.",
    tags: ["Database"],
    requestBody: { required: true, content: { "application/json": { schema: { type: "object", required: ["name"], properties: { name: { type: "string", pattern: "^[a-z][a-z0-9_]{0,63}$", example: "todos" }, description: { type: "string" }, access: { type: "string", enum: ["public", "authenticated", "owner"], default: "authenticated" }, fields: { type: "array", items: { $ref: "#/components/schemas/FieldDef" } } } } } } },
    responses: { 201: { description: "Table created.", content: { "application/json": { schema: successEnvelope({ $ref: "#/components/schemas/Table" }) } } }, 400: { $ref: "#/components/responses/BadRequest" }, 409: { description: "A table with that name already exists." } },
  },
  "GET /db/tables/{table}": {
    summary: "Get a table definition",
    tags: ["Database"],
    responses: { 200: { description: "Table.", content: { "application/json": { schema: successEnvelope({ $ref: "#/components/schemas/Table" }) } } }, 404: { $ref: "#/components/responses/NotFound" } },
  },
  "PATCH /db/tables/{table}": {
    summary: "Update a table definition",
    description: "Add, rename or drop columns. Dropping a column deletes its data — FD53 will not do this implicitly.",
    tags: ["Database"],
    responses: { 200: { description: "Table updated." }, 400: { $ref: "#/components/responses/BadRequest" }, 404: { $ref: "#/components/responses/NotFound" } },
  },
  "DELETE /db/tables/{table}": {
    summary: "Delete a table",
    description: "Removes the table and every row in it. Irreversible unless a backup exists.",
    tags: ["Database"],
    responses: { 200: { description: "Table deleted." }, 404: { $ref: "#/components/responses/NotFound" } },
  },

  // --- database: rows ----------------------------------------------------
  "GET /db/{table}": {
    summary: "List rows",
    description:
      "Paginated read. Supports `limit` (max " + FREE_PLAN.maxRowsPerPage + "), `offset`, `order` (`asc`/`desc`) and `orderBy` on an indexed column.",
    tags: ["Database"],
    parameters: [
      { name: "limit", in: "query", schema: { type: "integer", maximum: FREE_PLAN.maxRowsPerPage, default: 50 } },
      { name: "offset", in: "query", schema: { type: "integer", minimum: 0, default: 0 } },
      { name: "orderBy", in: "query", schema: { type: "string" } },
      { name: "order", in: "query", schema: { type: "string", enum: ["asc", "desc"] } },
    ],
    responses: { 200: { description: "Rows.", content: { "application/json": { schema: successEnvelope({ $ref: "#/components/schemas/RowPage" }) } } }, 403: { $ref: "#/components/responses/Forbidden" }, 404: { $ref: "#/components/responses/NotFound" } },
  },
  "POST /db/{table}": {
    summary: "Insert a row",
    description: "Validates the payload against the table's column definitions. On an `owner`-access table the row records the calling end user.",
    tags: ["Database"],
    requestBody: { required: true, content: { "application/json": { schema: { type: "object", additionalProperties: true } } } },
    responses: { 201: { description: "Row created.", content: { "application/json": { schema: successEnvelope({ $ref: "#/components/schemas/Row" }) } } }, 400: { $ref: "#/components/responses/BadRequest" }, 403: { $ref: "#/components/responses/Forbidden" }, 409: { description: "A unique column rejected the value." } },
  },
  "GET /db/{table}/{id}": {
    summary: "Get a row",
    tags: ["Database"],
    responses: { 200: { description: "Row.", content: { "application/json": { schema: successEnvelope({ $ref: "#/components/schemas/Row" }) } } }, 403: { $ref: "#/components/responses/Forbidden" }, 404: { $ref: "#/components/responses/NotFound" } },
  },
  "PATCH /db/{table}/{id}": {
    summary: "Update a row",
    description: "Partial update. Omitted fields are left untouched.",
    tags: ["Database"],
    requestBody: { required: true, content: { "application/json": { schema: { type: "object", additionalProperties: true } } } },
    responses: { 200: { description: "Row updated.", content: { "application/json": { schema: successEnvelope({ $ref: "#/components/schemas/Row" }) } } }, 400: { $ref: "#/components/responses/BadRequest" }, 403: { $ref: "#/components/responses/Forbidden" }, 404: { $ref: "#/components/responses/NotFound" } },
  },
  "DELETE /db/{table}/{id}": {
    summary: "Delete a row",
    tags: ["Database"],
    responses: { 200: { description: "Row deleted." }, 403: { $ref: "#/components/responses/Forbidden" }, 404: { $ref: "#/components/responses/NotFound" } },
  },

  // --- storage -----------------------------------------------------------
  "GET /storage/buckets": {
    summary: "List buckets",
    description: "Returns each bucket with its file count and byte usage. Bucket visibility is fixed per bucket and enforced on upload.",
    tags: ["Storage"],
    responses: { 200: { description: "Buckets.", content: { "application/json": { schema: successEnvelope({ type: "object", properties: { buckets: { type: "array", items: { $ref: "#/components/schemas/Bucket" } }, total: { type: "integer" }, storage: { type: "object", properties: { used: { type: "integer", format: "int64" }, limit: { type: "integer", format: "int64" } } } } }) } } } },
  },
  "POST /storage/upload": {
    summary: "Upload a file",
    description:
      "Accepts `multipart/form-data` (part name `file`), JSON with `contentBase64`, or a raw binary body. " +
      `Single files are capped at ${Math.floor(FREE_PLAN.maxUploadBytes / 1024 / 1024)} MB and the project at ${Math.floor(FREE_PLAN.storageLimitBytes / 1024 / 1024)} MB. ` +
      "Bucket visibility overrides any `visibility` you send — a private bucket's files can never be published through the API.",
    tags: ["Storage"],
    requestBody: {
      required: true,
      content: {
        "multipart/form-data": {
          schema: {
            type: "object",
            properties: {
              file: { type: "string", format: "binary" },
              bucket: { type: "string", enum: STORAGE_BUCKET_LIST.map((b) => b.name) },
              visibility: { type: "string", enum: ["public", "private"] },
            },
            required: ["file"],
          },
        },
        "application/json": {
          schema: {
            type: "object",
            required: ["contentBase64"],
            properties: {
              contentBase64: { type: "string", format: "byte" },
              path: { type: "string", example: "avatars/me.jpg" },
              mimeType: { type: "string" },
              bucket: { type: "string", enum: STORAGE_BUCKET_LIST.map((b) => b.name) },
            },
          },
        },
        "application/octet-stream": { schema: { type: "string", format: "binary" } },
      },
    },
    responses: { 201: { description: "Uploaded.", content: { "application/json": { schema: successEnvelope({ type: "object", properties: { file: { $ref: "#/components/schemas/File" }, url: { type: "string", nullable: true } } }) } } }, 400: { $ref: "#/components/responses/BadRequest" }, 413: { description: "File too large, or the project storage quota is exhausted." } },
  },
  "GET /storage/files": {
    summary: "List files",
    description: "Filter by `prefix`, `bucket`, `ownerId` and `limit`.",
    tags: ["Storage"],
    parameters: [
      { name: "prefix", in: "query", schema: { type: "string" } },
      { name: "bucket", in: "query", schema: { type: "string", enum: STORAGE_BUCKET_LIST.map((b) => b.name) } },
      { name: "ownerId", in: "query", schema: { type: "string" }, description: "`all` requires the `storage:read` permission; otherwise an end user sees only their own files." },
      { name: "limit", in: "query", schema: { type: "integer", maximum: 200 } },
    ],
    responses: { 200: { description: "Files.", content: { "application/json": { schema: successEnvelope({ type: "object", properties: { total: { type: "integer" }, files: { type: "array", items: { $ref: "#/components/schemas/File" } } } }) } } } },
  },
  "GET /storage/files/{id}": {
    summary: "Get a file",
    description: "Returns metadata. Private files are readable only by their owner or a caller with full project access. Pass `redirect=true` to get a 302 to the file.",
    tags: ["Storage"],
    parameters: [{ name: "redirect", in: "query", schema: { type: "boolean", default: false } }],
    responses: { 200: { description: "File.", content: { "application/json": { schema: successEnvelope({ type: "object", properties: { file: { $ref: "#/components/schemas/File" } } }) } } }, 302: { description: "Redirect to the stored object." }, 403: { $ref: "#/components/responses/Forbidden" }, 404: { $ref: "#/components/responses/NotFound" } },
  },
  "DELETE /storage/files/{id}": {
    summary: "Delete a file",
    description: "Removes the object and decrements the project's storage usage.",
    tags: ["Storage"],
    responses: { 200: { description: "Deleted." }, 403: { $ref: "#/components/responses/Forbidden" }, 404: { $ref: "#/components/responses/NotFound" } },
  },

  // --- realtime ----------------------------------------------------------
  "POST /realtime/publish": {
    summary: "Publish an event",
    description: "Broadcasts to a channel. Clients subscribe with the realtime SDK or poll `/v1/realtime/channels/{channel}/events`.",
    tags: ["Realtime"],
    responses: { 200: { description: "Published." }, 403: { $ref: "#/components/responses/Forbidden" } },
  },
  "GET /realtime/channels": {
    summary: "List channels",
    tags: ["Realtime"],
    responses: { 200: { description: "Channels." } },
  },
  "GET /realtime/channels/{channel}/events": {
    summary: "Recent events on a channel",
    description: "Polling fallback for clients that cannot hold a WebSocket open (mobile background, FlutterFlow web).",
    tags: ["Realtime"],
    responses: { 200: { description: "Events." } },
  },
};

// ---------------------------------------------------------------------------
// Document assembly
// ---------------------------------------------------------------------------

/**
 * `/v1/db/:table` → `/db/{table}`.
 *
 * The leading `v1` is stripped because every entry in `servers` already ends
 * in `/v1` — including it in the path would resolve to `/v1/v1/db/...`.
 */
function toOpenApiPath(segments: string[]): string {
  const withoutVersion =
    segments[0] === "v1" ? segments.slice(1) : segments;
  const rendered = withoutVersion.map((s) =>
    s.startsWith(":") ? `{${s.slice(1)}}` : s,
  );
  return rendered.length === 0 ? "/" : "/" + rendered.join("/");
}

/** Humanise a route when no hand-written doc exists. */
function fallbackDoc(method: string, segments: string[]): OperationDoc {
  const path = "/" + segments.join("/");
  const last = segments[segments.length - 1];
  const label = last.startsWith(":") ? last.slice(1) : last;
  return {
    summary: `${method} ${label}`,
    description: `${method} ${path}`,
    responses: {
      200: { description: "Success." },
      401: { $ref: "#/components/responses/Unauthorized" },
      403: { $ref: "#/components/responses/Forbidden" },
      404: { $ref: "#/components/responses/NotFound" },
      429: { $ref: "#/components/responses/RateLimited" },
    },
  };
}

/**
 * Build the complete OpenAPI 3.1 document from the live route table.
 *
 * Note: `openapi.json` is served by a route that lives in the table itself, so
 * it is documented here explicitly rather than picked up from `ROUTES`.
 */
export function openapiDocument(baseUrl?: string): Record<string, unknown> {
  const paths: Record<string, Record<string, unknown>> = {};
  const tagNames = new Set<string>();
  const matchedDocs = new Set<string>();

  for (const route of ROUTES) {
    const segments = [...route.segments];
    const path = toOpenApiPath(segments);
    const method = route.method.toLowerCase();
    const key = `${route.method} ${path}`;
    const doc = OPERATION_DOCS[key] ?? fallbackDoc(route.method, segments);
    const tags = doc.tags ?? [route.category];
    matchedDocs.add(key);

    for (const tag of tags) tagNames.add(tag);

    paths[path] = paths[path] ?? {};
    paths[path][method] = {
      summary: doc.summary,
      description: doc.description,
      tags,
      operationId: operationId(route.method, segments),
      security: route.scope
        ? [{ apiKey: [] }, { apiKey: [], endUserToken: [] }]
        : [],
      parameters: [
        { $ref: "#/components/parameters/RequestId" },
        { $ref: "#/components/parameters/ApiVersion" },
        ...pathParams(segments),
        ...(doc.parameters ?? []),
      ],
      ...(doc.requestBody ? { requestBody: doc.requestBody } : {}),
      responses: doc.responses ?? {
        200: { description: "Success." },
        400: { $ref: "#/components/responses/BadRequest" },
        401: { $ref: "#/components/responses/Unauthorized" },
        403: { $ref: "#/components/responses/Forbidden" },
        404: { $ref: "#/components/responses/NotFound" },
        429: { $ref: "#/components/responses/RateLimited" },
      },
    };
  }

  // The spec endpoint documents itself.
  paths["/openapi.json"] = {
    get: {
      summary: "This OpenAPI document",
      description:
        "The full FD53 API specification. Point Swagger UI, Postman, Insomnia or any SDK generator at this URL.",
      tags: ["System"],
      operationId: "getOpenApiDocument",
      security: [],
      responses: {
        200: {
          description: "OpenAPI 3.1 document.",
          content: { "application/json": { schema: { type: "object", additionalProperties: true } } },
        },
      },
    },
  };
  tagNames.add("System");

  // Fail loudly when a hand-written doc entry drifts away from the route table.
  // A silent fallback here means a real endpoint ships with a generic
  // description and no one notices, which is exactly what happened once before.
  const orphans = Object.keys(OPERATION_DOCS).filter((k) => !matchedDocs.has(k));
  if (orphans.length > 0) {
    console.warn(
      `FD53 openapi: ${orphans.length} OPERATION_DOCS keys match no route. ` +
        `Keys must be "METHOD /path" with the /v1 prefix stripped: ` +
        orphans.join(", "),
    );
  }
  const undocumented = [...matchedDocs].filter((k) => !OPERATION_DOCS[k]);

  return {
    openapi: "3.1.0",
    info: {
      title: "FD53 API",
      version: `v1.${FD53_VERSION}`,
      summary: "Backend-as-a-service: auth, database, storage, realtime and an API platform.",
      description: [
        "FD53 is a proprietary backend platform. Every request carries your project API key in",
        "`X-API-Key`. End users of your app additionally send `Authorization: Bearer <token>` — the",
        "API key authenticates *your backend*, the bearer token authenticates *your users*.",
        "",
        "## Response envelope",
        "Successful responses are `{ \"ok\": true, \"data\": … }`; failures are",
        "`{ \"ok\": false, \"error\": { \"code\", \"message\" } }`. Branch on `code`, not on the message.",
        "",
        "## Security",
        "Requests pass through a WAF, a per-IP flood limiter, `X-API-Key` validation, scope checks",
        "and per-key quota enforcement before reaching a handler. Every rejection carries a distinct",
        "error code and is written to the audit trail.",
      ].join("\n"),
      contact: { name: "FD53", url: "https://fd53.dev" },
      license: { name: "Proprietary" },
    },
    servers: baseUrl
      ? [{ url: baseUrl, description: "This deployment" }, ...OPENAPI_SERVERS]
      : OPENAPI_SERVERS,
    tags: [...tagNames].sort().map((name) => ({ name })),
    paths,
    components,
    security: [{ apiKey: [] }],
    "x-fd53": {
      platformVersion: FD53_VERSION,
      /** Routes with a hand-written description. */
      documentedRoutes: Array.from(matchedDocs).filter(
        (k) => !!OPERATION_DOCS[k],
      ).length,
      /** Routes still using the generic generated description. */
      genericRoutes: undocumented,
      permissions: [...KNOWN_PERMISSIONS],
      freePlanLimits: {
        requestsPerMinute: FREE_PLAN.requestsPerMinute,
        maxUploadBytes: FREE_PLAN.maxUploadBytes,
        maxRowsPerPage: FREE_PLAN.maxRowsPerPage,
        maxTablesPerProject: FREE_PLAN.maxTablesPerProject,
      },
      buckets: STORAGE_BUCKET_LIST.map((bucket) => ({
        name: bucket.name,
        visibility: bucket.visibility,
        accepts: bucket.accepts,
      })),
    },
  };
}

/** Turn `:table` segments into declared OpenAPI path parameters. */
function pathParams(segments: string[]): unknown[] {
  return segments
    .filter((segment) => segment.startsWith(":"))
    .map((segment) => ({
      name: segment.slice(1),
      in: "path",
      required: true,
      schema: { type: "string" },
    }));
}

/**
 * Stable, unique operation id derived from the route, e.g.
 * `getDbTableRowId` and `postUsersIdFollow`.
 *
 * Every segment contributes, including literals that follow a parameter — the
 * earlier version skipped the segment after `:id`, which collided
 * `/users/{id}/follow` with `/users/{id}/unfollow`.
 */
function operationId(method: string, segments: string[]): string {
  const parts = [method.toLowerCase()];
  const withoutVersion = segments[0] === "v1" ? segments.slice(1) : segments;
  for (const segment of withoutVersion) {
    parts.push(segment.startsWith(":") ? segment.slice(1) : segment);
  }
  return parts
    .map((part, index) =>
      index === 0 ? part : part.charAt(0).toUpperCase() + part.slice(1),
    )
    .join("")
    .replace(/[^A-Za-z0-9]/g, "");
}