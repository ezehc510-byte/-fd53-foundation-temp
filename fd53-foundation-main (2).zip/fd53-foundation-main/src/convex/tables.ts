import { v } from "convex/values";
import { requireOwnedProject } from "./lib/authz";
import { FREE_PLAN, isValidIdentifier } from "./lib/constants";
import type { Doc, Id } from "./_generated/dataModel";
import {
  internalMutation,
  internalQuery,
  mutation,
  query,
  type MutationCtx,
  type QueryCtx,
} from "./_generated/server";

const RESERVED_NAMES = new Set(["id", "data", "metadata"]);

const fieldValidator = v.object({
  name: v.string(),
  type: v.union(
    v.literal("string"),
    v.literal("number"),
    v.literal("boolean"),
    v.literal("datetime"),
    v.literal("json"),
    v.literal("reference"),
  ),
  required: v.optional(v.boolean()),
  unique: v.optional(v.boolean()),
  refTable: v.optional(v.string()),
  description: v.optional(v.string()),
});

const accessValidatorArg = v.union(
  v.literal("public"),
  v.literal("authenticated"),
  v.literal("owner"),
);

type CreateArgs = {
  projectId: Id<"projects">;
  name: string;
  description?: string;
  access?: "public" | "authenticated" | "owner";
  fields: Array<{
    name: string;
    type: "string" | "number" | "boolean" | "datetime" | "json" | "reference";
    required?: boolean;
    unique?: boolean;
    refTable?: string;
    description?: string;
  }>;
};

type Result =
  | { status: "created"; tableId: Id<"tables"> }
  | { status: "invalid"; message: string }
  | { status: "exists"; message: string }
  | { status: "full"; message: string };

/** Shared table-creation logic (dashboard + REST). */
export async function doCreateTable(
  ctx: MutationCtx,
  args: CreateArgs,
): Promise<Result> {
  const name = args.name.trim().toLowerCase();
  if (!isValidIdentifier(name) || RESERVED_NAMES.has(name)) {
    return {
      status: "invalid",
      message:
        "Table names are lowercase identifiers starting with a letter (a–z, 0–9, _).",
    };
  }

  const existingTables = await ctx.db
    .query("tables")
    .withIndex("by_project", (q) => q.eq("projectId", args.projectId))
    .collect();
  if (existingTables.length >= FREE_PLAN.maxTablesPerProject) {
    return {
      status: "full",
      message: `Plan limit reached (${FREE_PLAN.maxTablesPerProject} tables).`,
    };
  }
  if (existingTables.some((t) => t.name === name)) {
    return { status: "exists", message: `Table "${name}" already exists.` };
  }

  const fieldError = await validateFields(ctx, args.projectId, args.fields);
  if (fieldError) return { status: "invalid", message: fieldError };

  const tableId = await ctx.db.insert("tables", {
    projectId: args.projectId,
    name,
    description: args.description?.trim() || undefined,
    access: args.access ?? "public",
    fields: args.fields.map((f) => ({
      name: f.name,
      type: f.type,
      required: f.required ?? false,
      unique: f.unique ?? false,
      refTable: f.type === "reference" ? f.refTable : undefined,
      description: f.description || undefined,
    })),
    rowCount: 0,
  });
  return { status: "created", tableId };
}

/**
 * Validate a column list: identifier names, no duplicates, reference targets
 * exist. Returns an error message, or null when valid.
 */
async function validateFields(
  ctx: MutationCtx | QueryCtx,
  projectId: Id<"projects">,
  fields: CreateArgs["fields"],
): Promise<string | null> {
  if (fields.length === 0) return "Add at least one column.";
  if (fields.length > 50) return "Maximum 50 columns per table.";

  const seen = new Set<string>();
  let needsTableLookup = false;
  for (const field of fields) {
    if (!isValidIdentifier(field.name) || RESERVED_NAMES.has(field.name)) {
      return `Column "${field.name}" must be a lowercase identifier.`;
    }
    if (seen.has(field.name)) return `Duplicate column "${field.name}".`;
    seen.add(field.name);
    if (field.type === "reference") needsTableLookup = true;
  }

  if (needsTableLookup) {
    const tables = await ctx.db
      .query("tables")
      .withIndex("by_project", (q) => q.eq("projectId", projectId))
      .collect();
    for (const field of fields) {
      if (field.type !== "reference") continue;
      if (!field.refTable || !isValidIdentifier(field.refTable)) {
        return `Column "${field.name}" needs a reference table.`;
      }
      if (!tables.some((t) => t.name === field.refTable)) {
        return `Reference table "${field.refTable}" doesn't exist yet.`;
      }
    }
  }
  return null;
}

/** Shared table update logic: description, access level, columns. */
export async function doUpdateTable(
  ctx: MutationCtx,
  args: {
    projectId: Id<"projects">;
    tableId: Id<"tables">;
    description?: string;
    access?: "public" | "authenticated" | "owner";
    fields?: CreateArgs["fields"];
  },
): Promise<{ status: "ok" } | { status: "invalid" | "not_found"; message?: string }> {
  const table = await ctx.db.get(args.tableId);
  if (!table || table.projectId !== args.projectId) {
    return { status: "not_found", message: "Table not found." };
  }

  const patch: {
    description?: string | undefined;
    access?: "public" | "authenticated" | "owner";
    fields?: Doc<"tables">["fields"];
  } = {};
  if (args.description !== undefined) {
    patch.description = args.description.trim() || undefined;
  }
  if (args.access !== undefined) patch.access = args.access;

  if (args.fields !== undefined) {
    const fieldError = await validateFields(ctx, args.projectId, args.fields);
    if (fieldError) return { status: "invalid", message: fieldError };

    const seen = new Set<string>();
    for (const f of args.fields) {
      seen.add(f.name);
      if (f.unique) {
        const dupes = await findDuplicateValues(
          ctx,
          args.projectId,
          table,
          f.name,
        );
        if (dupes > 0) {
          return {
            status: "invalid",
            message: `${dupes} existing row(s) share a value in "${f.name}" — unique can't be enabled.`,
          };
        }
      }
    }
    patch.fields = args.fields.map((f) => ({
      name: f.name,
      type: f.type,
      required: f.required ?? false,
      unique: f.unique ?? false,
      refTable: f.type === "reference" ? f.refTable : undefined,
      description: f.description || undefined,
    }));
  }

  await ctx.db.patch(args.tableId, patch);
  return { status: "ok" };
}

async function findDuplicateValues(
  ctx: QueryCtx | MutationCtx,
  projectId: Id<"projects">,
  table: Doc<"tables">,
  field: string,
): Promise<number> {
  const rows = await ctx.db
    .query("rows")
    .withIndex("by_table", (q) => q.eq("projectId", projectId).eq("tableId", table._id))
    .collect();
  const seen = new Set<string>();
  let dupes = 0;
  for (const row of rows) {
    const value = row.data[field];
    if (value === undefined || value === null) continue;
    const key = typeof value === "object" ? JSON.stringify(value) : String(value);
    if (seen.has(key)) dupes += 1;
    else seen.add(key);
  }
  return dupes;
}

/** Shared table delete: drops rows + unique keys first. */
export async function doDeleteTable(
  ctx: MutationCtx,
  projectId: Id<"projects">,
  tableId: Id<"tables">,
): Promise<{ status: "deleted" } | { status: "not_found"; message?: string }> {
  const table = await ctx.db.get(tableId);
  if (!table || table.projectId !== projectId) {
    return { status: "not_found", message: "Table not found." };
  }
  const rows = await ctx.db
    .query("rows")
    .withIndex("by_table", (q) => q.eq("projectId", projectId).eq("tableId", tableId))
    .collect();
  for (const row of rows) await ctx.db.delete(row._id);

  const uniques = await ctx.db
    .query("uniqueValues")
    .withIndex("by_key", (q) =>
      q.eq("projectId", projectId).eq("tableId", tableId),
    )
    .collect();
  for (const u of uniques) await ctx.db.delete(u._id);

  await ctx.db.delete(tableId);
  return { status: "deleted" };
}

// ---------------------------------------------------------------------------
// Dashboard-facing functions (owner checked)
// ---------------------------------------------------------------------------

export const list = query({
  args: { projectId: v.id("projects") },
  handler: async (ctx, args) => {
    await requireOwnedProject(ctx, args.projectId);
    const tables = await ctx.db
      .query("tables")
      .withIndex("by_project", (q) => q.eq("projectId", args.projectId))
      .collect();
    return tables.sort((a, b) => a.name.localeCompare(b.name));
  },
});

export const byName = internalQuery({
  args: { projectId: v.id("projects"), name: v.string() },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("tables")
      .withIndex("by_project_name", (q) =>
        q.eq("projectId", args.projectId).eq("name", args.name),
      )
      .first();
  },
});

export const byId = internalQuery({
  args: { projectId: v.id("projects"), tableId: v.id("tables") },
  handler: async (ctx, args) => {
    const table = await ctx.db.get(args.tableId);
    if (!table || table.projectId !== args.projectId) return null;
    return table;
  },
});

export const createTable = mutation({
  args: {
    projectId: v.id("projects"),
    name: v.string(),
    description: v.optional(v.string()),
    access: v.optional(accessValidatorArg),
    fields: v.array(fieldValidator),
  },
  handler: async (ctx, args) => {
    await requireOwnedProject(ctx, args.projectId);
    return await doCreateTable(ctx, args);
  },
});

export const updateTable = mutation({
  args: {
    projectId: v.id("projects"),
    tableId: v.id("tables"),
    description: v.optional(v.string()),
    access: v.optional(accessValidatorArg),
    fields: v.optional(v.array(fieldValidator)),
  },
  handler: async (ctx, args) => {
    await requireOwnedProject(ctx, args.projectId);
    return await doUpdateTable(ctx, args);
  },
});

// ---------------------------------------------------------------------------
// Internal functions — REST database API (API-key auth happens in the handler)
// ---------------------------------------------------------------------------

export const allForApi = internalQuery({
  args: { projectId: v.id("projects") },
  handler: async (ctx, args) => {
    const tables = await ctx.db
      .query("tables")
      .withIndex("by_project", (q) => q.eq("projectId", args.projectId))
      .collect();
    return tables.sort((a, b) => a.name.localeCompare(b.name));
  },
});

export const createTableFromApi = internalMutation({
  args: {
    projectId: v.id("projects"),
    name: v.string(),
    description: v.optional(v.string()),
    access: v.optional(accessValidatorArg),
    fields: v.array(fieldValidator),
  },
  handler: async (ctx, args) => await doCreateTable(ctx, args),
});

export const updateTableFromApi = internalMutation({
  args: {
    projectId: v.id("projects"),
    tableId: v.id("tables"),
    description: v.optional(v.string()),
    access: v.optional(accessValidatorArg),
    fields: v.optional(v.array(fieldValidator)),
  },
  handler: async (ctx, args) => await doUpdateTable(ctx, args),
});

export const deleteTableFromApi = internalMutation({
  args: { projectId: v.id("projects"), tableId: v.id("tables") },
  handler: async (ctx, args) =>
    await doDeleteTable(ctx, args.projectId, args.tableId),
});

export const deleteTable = mutation({
  args: { projectId: v.id("projects"), tableId: v.id("tables") },
  handler: async (ctx, args) => {
    await requireOwnedProject(ctx, args.projectId);
    return await doDeleteTable(ctx, args.projectId, args.tableId);
  },
});
