/**
 * LoopUni marketplace: listings, orders and the creator earnings ledger.
 *
 * Money is stored in minor units (cents) as integers — never floats. Each paid
 * order writes exactly one `creatorEarnings` row so a seller's balance is a
 * simple sum, and the platform fee is computed once at checkout from
 * `PLATFORM_FEE_BPS` rather than trusted from the client.
 */
import { v } from "convex/values";
import { requireOwnedProject } from "./lib/authz";
import { PLATFORM_FEE_BPS } from "./lib/constants";
import type { Doc, Id } from "./_generated/dataModel";
import { internalMutation, internalQuery, query } from "./_generated/server";

const MAX_TITLE = 140;
const MAX_DESCRIPTION = 4000;

export function platformFee(amountCents: number): number {
  return Math.round((amountCents * PLATFORM_FEE_BPS) / 10_000);
}

// ---------------------------------------------------------------------------
// Products
// ---------------------------------------------------------------------------

export const createProduct = internalMutation({
  args: {
    projectId: v.id("projects"),
    sellerId: v.id("users"),
    title: v.string(),
    description: v.optional(v.string()),
    priceCents: v.number(),
    currency: v.optional(v.string()),
    category: v.optional(v.string()),
    kind: v.optional(v.union(v.literal("digital"), v.literal("physical"))),
    status: v.optional(
      v.union(v.literal("active"), v.literal("draft")), 
    ),
    mediaIds: v.optional(v.array(v.id("media"))),
    assetFileId: v.optional(v.id("files")),
    inventory: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const title = args.title.trim();
    if (!title) {
      return { status: "invalid" as const, message: '"title" is required.' };
    }
    if (title.length > MAX_TITLE) {
      return {
        status: "invalid" as const,
        message: `"title" must be at most ${MAX_TITLE} characters.`,
      };
    }
    if ((args.description?.length ?? 0) > MAX_DESCRIPTION) {
      return {
        status: "invalid" as const,
        message: `"description" must be at most ${MAX_DESCRIPTION} characters.`,
      };
    }
    if (!Number.isInteger(args.priceCents) || args.priceCents < 0) {
      return {
        status: "invalid" as const,
        message: '"priceCents" must be an integer ≥ 0 (e.g. 499 for $4.99).',
      };
    }
    if (args.priceCents > 100_000_000) {
      return {
        status: "invalid" as const,
        message: '"priceCents" above 1,000,000.00 is not accepted.',
      };
    }
    if (args.inventory !== undefined && (!Number.isInteger(args.inventory) || args.inventory < 0)) {
      return {
        status: "invalid" as const,
        message: '"inventory" must be an integer ≥ 0.',
      };
    }
    if (args.assetFileId) {
      // Digital goods must ship from the private receipts bucket.
      const asset = await ctx.db.get(args.assetFileId);
      if (!asset || asset.projectId !== args.projectId) {
        return { status: "invalid" as const, message: "Unknown assetFileId." };
      }
      if (asset.bucket !== "receipts" || asset.visibility !== "private") {
        return {
          status: "invalid" as const,
          message:
            'Digital assets must be uploaded to the private "receipts" bucket.',
        };
      }
    }

    // Selling requires a creator profile.
    const profile = await ctx.db
      .query("profiles")
      .withIndex("by_user", (q) => q.eq("userId", args.sellerId))
      .filter((q) => q.eq(q.field("projectId"), args.projectId))
      .unique();
    if (profile && !profile.isCreator) {
      await ctx.db.patch(profile._id, { isCreator: true });
    }

    const productId = await ctx.db.insert("products", {
      projectId: args.projectId,
      sellerId: args.sellerId,
      title,
      description: args.description,
      priceCents: args.priceCents,
      currency: (args.currency ?? "usd").toLowerCase(),
      category: args.category,
      kind: args.kind ?? "digital",
      status: args.status ?? "active",
      mediaIds: args.mediaIds,
      assetFileId: args.assetFileId,
      inventory: args.inventory,
      salesCount: 0,
    });

    return { status: "created" as const, productId };
  },
});

export const listProducts = internalQuery({
  args: {
    projectId: v.id("projects"),
    sellerId: v.optional(v.id("users")),
    category: v.optional(v.string()),
    limit: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const limit = Math.min(Math.max(1, args.limit ?? 20), 50);
    let rows: Doc<"products">[];
    const sellerId = args.sellerId;
    if (sellerId) {
      rows = await ctx.db
        .query("products")
        .withIndex("by_seller", (q) =>
          q.eq("projectId", args.projectId).eq("sellerId", sellerId),
        )
        .order("desc")
        .take(limit);
    } else {
      rows = await ctx.db
        .query("products")
        .withIndex("by_project", (q) => q.eq("projectId", args.projectId))
        .order("desc")
        .take(limit);
    }

    let filtered = rows;
    if (args.category) {
      filtered = filtered.filter(
        (p) => (p.category ?? "").toLowerCase() === args.category!.toLowerCase(),
      );
    }
    // Draft and removed listings never appear on the public marketplace.
    return filtered.filter((p) => p.status === "active" || p.status === "sold_out");
  },
});

export const productById = internalQuery({
  args: { projectId: v.id("projects"), productId: v.id("products") },
  handler: async (ctx, args) => {
    const product = await ctx.db.get(args.productId);
    if (!product || product.projectId !== args.projectId) return null;
    return product;
  },
});

// ---------------------------------------------------------------------------
// Orders
// ---------------------------------------------------------------------------

export const checkout = internalMutation({
  args: {
    projectId: v.id("projects"),
    buyerId: v.id("users"),
    productId: v.id("products"),
    quantity: v.optional(v.number()),
    paymentRef: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const quantity = args.quantity ?? 1;
    if (!Number.isInteger(quantity) || quantity < 1 || quantity > 100) {
      return {
        status: "invalid" as const,
        message: '"quantity" must be an integer between 1 and 100.',
      };
    }
    const product = await ctx.db.get(args.productId);
    if (!product || product.projectId !== args.projectId) {
      return { status: "not_found" as const, message: "No such product." };
    }
    if (product.status !== "active") {
      return {
        status: "unavailable" as const,
        message: `This listing is ${product.status}.`,
      };
    }
    if (product.sellerId === args.buyerId) {
      return {
        status: "invalid" as const,
        message: "You cannot buy your own listing.",
      };
    }
    if (product.inventory !== undefined && product.inventory < quantity) {
      return {
        status: "out_of_stock" as const,
        message: `Only ${product.inventory} left.`,
      };
    }

    const amountCents = product.priceCents * quantity;
    const platformFeeCents = platformFee(amountCents);
    const now = Date.now();

    const orderId = await ctx.db.insert("orders", {
      projectId: args.projectId,
      buyerId: args.buyerId,
      sellerId: product.sellerId,
      productId: product._id,
      quantity,
      amountCents,
      platformFeeCents,
      currency: product.currency,
      status: "paid",
      paymentRef: args.paymentRef?.slice(0, 120),
      purchasedAt: now,
    });

    // Ledger row — one per order, so the seller balance is a plain sum.
    await ctx.db.insert("creatorEarnings", {
      projectId: args.projectId,
      creatorId: product.sellerId,
      orderId,
      productId: product._id,
      grossCents: amountCents,
      platformFeeCents,
      netCents: amountCents - platformFeeCents,
      currency: product.currency,
      status: "available",
      availableAt: now,
    });

    const salesCount = product.salesCount + quantity;
    const patch: Partial<Doc<"products">> = { salesCount };
    if (product.inventory !== undefined) {
      const remaining = Math.max(0, product.inventory - quantity);
      patch.inventory = remaining;
      if (remaining === 0) patch.status = "sold_out";
    }
    await ctx.db.patch(product._id, patch);

    return {
      status: "paid" as const,
      orderId,
      amountCents,
      platformFeeCents,
      currency: product.currency,
      purchasedAt: now,
    };
  },
});

export const ordersForBuyer = internalQuery({
  args: {
    projectId: v.id("projects"),
    buyerId: v.id("users"),
    limit: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const limit = Math.min(Math.max(1, args.limit ?? 20), 100);
    return await ctx.db
      .query("orders")
      .withIndex("by_project_buyer", (q) =>
        q.eq("projectId", args.projectId).eq("buyerId", args.buyerId),
      )
      .order("desc")
      .take(limit);
  },
});

export const ordersForSeller = internalQuery({
  args: {
    projectId: v.id("projects"),
    sellerId: v.id("users"),
    limit: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const limit = Math.min(Math.max(1, args.limit ?? 20), 100);
    return await ctx.db
      .query("orders")
      .withIndex("by_project_seller", (q) =>
        q.eq("projectId", args.projectId).eq("sellerId", args.sellerId),
      )
      .order("desc")
      .take(limit);
  },
});

export const orderById = internalQuery({
  args: { projectId: v.id("projects"), orderId: v.id("orders") },
  handler: async (ctx, args) => {
    const order = await ctx.db.get(args.orderId);
    if (!order || order.projectId !== args.projectId) return null;
    return order;
  },
});

/** Attach the private purchase invoice to a paid order. */
export const attachReceipt = internalMutation({
  args: {
    projectId: v.id("projects"),
    orderId: v.id("orders"),
    receiptFileId: v.id("files"),
  },
  handler: async (ctx, args) => {
    const order = await ctx.db.get(args.orderId);
    if (!order || order.projectId !== args.projectId) {
      return { status: "not_found" as const };
    }
    const receipt = await ctx.db.get(args.receiptFileId);
    if (!receipt || receipt.projectId !== args.projectId) {
      return { status: "invalid" as const, message: "Unknown receiptFileId." };
    }
    if (receipt.bucket !== "receipts" || receipt.visibility !== "private") {
      return {
        status: "invalid" as const,
        message: 'Receipts must live in the private "receipts" bucket.',
      };
    }
    await ctx.db.patch(args.orderId, { receiptFileId: args.receiptFileId });
    return { status: "ok" as const };
  },
});

// ---------------------------------------------------------------------------
// Earnings
// ---------------------------------------------------------------------------

export const earningsForCreator = internalQuery({
  args: { projectId: v.id("projects"), creatorId: v.id("users") },
  handler: async (ctx, args) => {
    const rows = await ctx.db
      .query("creatorEarnings")
      .withIndex("by_creator", (q) =>
        q.eq("projectId", args.projectId).eq("creatorId", args.creatorId),
      )
      .collect();

    let grossCents = 0;
    let platformFeeCents = 0;
    let availableCents = 0;
    let pendingCents = 0;
    let paidCents = 0;
    for (const row of rows) {
      grossCents += row.grossCents;
      platformFeeCents += row.platformFeeCents;
      if (row.status === "available") availableCents += row.netCents;
      else if (row.status === "pending") pendingCents += row.netCents;
      else paidCents += row.netCents;
    }

    return {
      sales: rows.length,
      grossCents,
      platformFeeCents,
      netCents: grossCents - platformFeeCents,
      availableCents,
      pendingCents,
      paidCents,
      currency: rows[0]?.currency ?? "usd",
      ledger: rows
        .sort((a, b) => b._creationTime - a._creationTime)
        .slice(0, 50)
        .map((row) => ({
          id: row._id,
          orderId: row.orderId ?? null,
          grossCents: row.grossCents,
          platformFeeCents: row.platformFeeCents,
          netCents: row.netCents,
          status: row.status,
          createdAt: row._creationTime,
        })),
    };
  },
});

// ---------------------------------------------------------------------------
// Dashboard
// ---------------------------------------------------------------------------

export const marketplaceStats = query({
  args: { projectId: v.id("projects") },
  handler: async (ctx, args) => {
    await requireOwnedProject(ctx, args.projectId);
    const products = await ctx.db
      .query("products")
      .withIndex("by_project", (q) => q.eq("projectId", args.projectId))
      .collect();
    const orders = await ctx.db
      .query("orders")
      .withIndex("by_project_buyer", (q) => q.eq("projectId", args.projectId))
      .collect();
    const grossCents = orders
      .filter((o) => o.status === "paid")
      .reduce((sum, o) => sum + o.amountCents, 0);
    const feesCents = orders
      .filter((o) => o.status === "paid")
      .reduce((sum, o) => sum + o.platformFeeCents, 0);
    return {
      products: products.length,
      activeProducts: products.filter((p) => p.status === "active").length,
      orders: orders.length,
      grossCents,
      platformFeeCents: feesCents,
    };
  },
});