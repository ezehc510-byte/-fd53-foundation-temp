/**
 * Moderation reports.
 *
 * `targetType`/`targetId` is deliberately polymorphic: the same table backs
 * reports against users, posts, comments, messages and products without a
 * join. Duplicate open reports on the same target are collapsed by the REST
 * handler so a coordinated spam wave cannot flood the moderation queue.
 */
import { v } from "convex/values";
import { requireOwnedProject } from "./lib/authz";
import { ANTI_SPAM_LIMITS } from "./lib/constants";
import type { Id } from "./_generated/dataModel";
import { internalMutation, internalQuery, mutation, query } from "./_generated/server";

const MAX_DETAILS = 2000;

const TARGET_TYPES = ["user", "post", "comment", "message", "product"] as const;
export type TargetType = (typeof TARGET_TYPES)[number];

const STATUSES = ["open", "reviewing", "resolved", "dismissed"] as const;
export type ReportStatus = (typeof STATUSES)[number];

export function isTargetType(value: string): value is TargetType {
  return (TARGET_TYPES as readonly string[]).includes(value);
}

export function isReportStatus(value: string): value is ReportStatus {
  return (STATUSES as readonly string[]).includes(value);
}

export const create = internalMutation({
  args: {
    projectId: v.id("projects"),
    reporterId: v.optional(v.id("users")),
    targetType: v.string(),
    targetId: v.string(),
    reason: v.string(),
    details: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const targetType = args.targetType;
    if (!isTargetType(targetType)) {
      return {
        status: "invalid" as const,
        message: `"targetType" must be one of ${TARGET_TYPES.join(", ")}.`,
      };
    }
    const reason = args.reason.trim();
    if (!reason) {
      return { status: "invalid" as const, message: '"reason" is required.' };
    }
    if (reason.length > 200) {
      return {
        status: "invalid" as const,
        message: '"reason" must be at most 200 characters.',
      };
    }
    if (!args.targetId) {
      return { status: "invalid" as const, message: '"targetId" is required.' };
    }
    if ((args.details?.length ?? 0) > MAX_DETAILS) {
      return {
        status: "invalid" as const,
        message: `"details" must be at most ${MAX_DETAILS} characters.`,
      };
    }

    const duplicate = await ctx.db
      .query("reports")
      .withIndex("by_target", (q) =>
        q
          .eq("projectId", args.projectId)
          .eq("targetType", targetType)
          .eq("targetId", args.targetId),
      )
      .filter((q) =>
        q.or(q.eq(q.field("status"), "open"), q.eq(q.field("status"), "reviewing")),
      )
      .unique();
    if (duplicate) {
      return {
        status: "duplicate" as const,
        reportId: duplicate._id,
        message: "This content is already under review.",
      };
    }

    const reportId = await ctx.db.insert("reports", {
      projectId: args.projectId,
      reporterId: args.reporterId,
      targetType,
      targetId: args.targetId,
      reason,
      details: args.details,
      status: "open",
    });
    return { status: "created" as const, reportId };
  },
});

export const listForApi = internalQuery({
  args: { projectId: v.id("projects"), status: v.optional(v.string()) },
  handler: async (ctx, args) => {
    const status = args.status;
    if (status && isReportStatus(status)) {
      return await ctx.db
        .query("reports")
        .withIndex("by_status", (q) =>
          q.eq("projectId", args.projectId).eq("status", status),
        )
        .order("desc")
        .take(100);
    }
    return await ctx.db
      .query("reports")
      .withIndex("by_project", (q) => q.eq("projectId", args.projectId))
      .order("desc")
      .take(100);
  },
});

/** Moderation queue for the dashboard. */
export const queue = query({
  args: { projectId: v.id("projects") },
  handler: async (ctx, args) => {
    await requireOwnedProject(ctx, args.projectId);
    const rows = await ctx.db
      .query("reports")
      .withIndex("by_project", (q) => q.eq("projectId", args.projectId))
      .order("desc")
      .take(100);
    const byStatus: Record<string, number> = {};
    for (const row of rows) byStatus[row.status] = (byStatus[row.status] ?? 0) + 1;
    return { total: rows.length, byStatus, reports: rows };
  },
});

/** Resolve or dismiss a report (owner-only dashboard action). */
export const resolve = mutation({
  args: {
    projectId: v.id("projects"),
    reportId: v.id("reports"),
    status: v.union(v.literal("resolved"), v.literal("dismissed")),
  },
  handler: async (ctx, args) => {
    const ownerId = await requireOwnedProject(ctx, args.projectId).then(
      (p) => p.ownerId,
    );
    const report = await ctx.db.get(args.reportId);
    if (!report || report.projectId !== args.projectId) {
      return { status: "not_found" as const };
    }
    await ctx.db.patch(args.reportId, {
      status: args.status,
      resolvedAt: Date.now(),
      resolvedBy: ownerId,
    });
    return { status: "ok" as const };
  },
});

/** Per-user report allowance, exposed so the REST layer can 429 early. */
export function reportLimit() {
  return ANTI_SPAM_LIMITS.report;
}

export type ReportRowId = Id<"reports">;