import { action } from "./_generated/server";
import { v } from "convex/values";
import { requireOwnedProject } from "./lib/authz";
import { randomHex, sha256Hex } from "./lib/crypto";
import { isValidIp, isIpv4, isIpv6 } from "./lib/net";
import { tryRecord } from "./audit";
import { internal } from "./_generated/api";
import type { Id } from "./_generated/dataModel";
import { internalMutation, internalQuery, mutation, query } from "./_generated/server";

type CreateKeyResult =
  | { status: "created"; id: Id<"apiKeys">; key: string; keyPrefix: string }
  | { status: "invalid"; message: string };

/** Resolve a presented key by its sha256 (REST layer). */
export const byHash = internalQuery({
  args: { hash: v.string() },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("apiKeys")
      .withIndex("by_hash", (q) => q.eq("keyHash", args.hash))
      .first();
  },
});

/**
 * Record that a key was just used. Called by the gateway on every
 * authenticated request so the dashboard's "last used" column is meaningful.
 */
export const touch = internalMutation({
  args: { id: v.id("apiKeys") },
  handler: async (ctx, args) => {
    const key = await ctx.db.get(args.id);
    if (key) await ctx.db.patch(args.id, { lastUsedAt: Date.now() });
    return { status: "ok" as const };
  },
});

/** Keys for a project — plaintext is never returned after creation. */
export const list = query({
  args: { projectId: v.id("projects") },
  handler: async (ctx, args) => {
    await requireOwnedProject(ctx, args.projectId);
    const keys = await ctx.db
      .query("apiKeys")
      .withIndex("by_project", (q) => q.eq("projectId", args.projectId))
      .collect();
    return keys.sort((a, b) => b._creationTime - a._creationTime);
  },
});

/**
 * Mint a new API key. Runs as an action because the plaintext key needs
 * cryptographic randomness — it is returned exactly once, never stored.
 */
export const create = action({
  args: {
    projectId: v.id("projects"),
    name: v.string(),
    rateLimit: v.optional(v.number()),
    scopes: v.optional(v.array(v.string())),
    /** Defaults to "live"; use "test" for sandbox keys. */
    environment: v.optional(v.union(v.literal("live"), v.literal("test"))),
    /** Epoch ms after which the key stops working. */
    expiresAt: v.optional(v.number()),
    allowedIps: v.optional(v.array(v.string())),
    blockedIps: v.optional(v.array(v.string())),
    allowedOrigins: v.optional(v.array(v.string())),
  },
  handler: async (ctx, args): Promise<CreateKeyResult> => {
    const project = await ctx.runQuery(internal.projects.requireOwner, {
      projectId: args.projectId,
    });
    const name = args.name.trim();
    if (name.length < 1 || name.length > 60) {
      return { status: "invalid" as const, message: "Key name must be 1–60 characters." };
    }

    // Reject malformed IP rules at creation time. A typo'd allowlist silently
    // widening access is a far worse outcome than a failed creation.
    const badIpRule = [...(args.allowedIps ?? []), ...(args.blockedIps ?? [])].find(
      (rule) => !isValidIpRule(rule),
    );
    if (badIpRule) {
      return {
        status: "invalid" as const,
        message: `"${badIpRule}" is not a valid IP address or CIDR block.`,
      };
    }

    const environment = args.environment ?? "live";
    const key = `fd53_${environment}_${randomHex(20)}`;
    const keyHash = await sha256Hex(key);
    const scopes =
      args.scopes && args.scopes.length > 0 ? args.scopes : ["*"];
    const rateLimit = Math.max(
      1,
      Math.min(args.rateLimit ?? project.requestsPerMinute, project.requestsPerMinute),
    );

    const id = await ctx.runMutation(internal.apiKeys.insert, {
      projectId: args.projectId,
      name,
      keyPrefix: key.slice(0, 20),
      keyHash,
      scopes,
      rateLimit,
      environment,
      expiresAt: args.expiresAt,
      allowedIps: args.allowedIps,
      blockedIps: args.blockedIps,
      allowedOrigins: args.allowedOrigins,
    });

    await ctx.runMutation(internal.audit.record, {
      event: "key.created",
      outcome: "success",
      projectId: args.projectId,
      apiKeyId: id,
      detail: `name=${name} env=${environment} scopes=${scopes.join(",") || "*"}`,
    });

    return { status: "created" as const, id, key, keyPrefix: key.slice(0, 20) };
  },
});

/**
 * Validate an IP rule: a bare address (`203.0.113.7`, `2001:db8::1`) or a CIDR
 * block (`203.0.113.0/24`, `2001:db8::/32`).
 */
function isValidIpRule(rule: string): boolean {
  const trimmed = rule.trim();
  if (!trimmed) return false;
  if (!trimmed.includes("/")) return isValidIp(trimmed);
  const slash = trimmed.lastIndexOf("/");
  const base = trimmed.slice(0, slash);
  const prefixText = trimmed.slice(slash + 1);
  if (!/^\d{1,3}$/.test(prefixText)) return false;
  const prefix = Number(prefixText);
  if (isIpv4(base)) return prefix >= 0 && prefix <= 32;
  if (isIpv6(base)) return prefix >= 0 && prefix <= 128;
  return false;
}

export const insert = internalMutation({
  args: {
    projectId: v.id("projects"),
    name: v.string(),
    keyPrefix: v.string(),
    keyHash: v.string(),
    scopes: v.array(v.string()),
    rateLimit: v.number(),
    environment: v.optional(v.union(v.literal("live"), v.literal("test"))),
    expiresAt: v.optional(v.number()),
    allowedIps: v.optional(v.array(v.string())),
    blockedIps: v.optional(v.array(v.string())),
    allowedOrigins: v.optional(v.array(v.string())),
  },
  handler: async (ctx, args) => {
    return await ctx.db.insert("apiKeys", {
      projectId: args.projectId,
      name: args.name,
      keyPrefix: args.keyPrefix,
      keyHash: args.keyHash,
      scopes: args.scopes,
      rateLimit: args.rateLimit,
      environment: args.environment,
      expiresAt: args.expiresAt,
      allowedIps: args.allowedIps,
      blockedIps: args.blockedIps,
      allowedOrigins: args.allowedOrigins,
    });
  },
});

export const revoke = mutation({
  args: { projectId: v.id("projects"), keyId: v.id("apiKeys") },
  handler: async (ctx, args) => {
    const project = await requireOwnedProject(ctx, args.projectId);
    const key = await ctx.db.get(args.keyId);
    if (!key || key.projectId !== project._id) {
      return { status: "not_found" as const };
    }
    if (!key.revokedAt) {
      await ctx.db.patch(args.keyId, { revokedAt: Date.now() });
      await tryRecord(ctx, {
        event: "key.revoked",
        outcome: "success",
        projectId: project._id,
        apiKeyId: key._id,
        detail: key.name,
      });
    }
    return { status: "revoked" as const };
  },
});

export const update = mutation({
  args: {
    projectId: v.id("projects"),
    keyId: v.id("apiKeys"),
    name: v.optional(v.string()),
    rateLimit: v.optional(v.number()),
    scopes: v.optional(v.array(v.string())),
    expiresAt: v.optional(v.number()),
    allowedIps: v.optional(v.array(v.string())),
    blockedIps: v.optional(v.array(v.string())),
    allowedOrigins: v.optional(v.array(v.string())),
  },
  handler: async (ctx, args) => {
    const project = await requireOwnedProject(ctx, args.projectId);
    const key = await ctx.db.get(args.keyId);
    if (!key || key.projectId !== project._id) {
      return { status: "not_found" as const };
    }

    // Validate IP rules before writing — see the note in `create`.
    const badIpRule = [...(args.allowedIps ?? []), ...(args.blockedIps ?? [])].find(
      (rule) => !isValidIpRule(rule),
    );
    if (badIpRule) {
      return {
        status: "invalid" as const,
        message: `"${badIpRule}" is not a valid IP address or CIDR block.`,
      };
    }

    const patch: {
      name?: string;
      rateLimit?: number;
      scopes?: string[];
      expiresAt?: number;
      allowedIps?: string[];
      blockedIps?: string[];
      allowedOrigins?: string[];
    } = {};
    if (args.name !== undefined && args.name.trim()) {
      patch.name = args.name.trim();
    }
    if (args.rateLimit !== undefined) {
      patch.rateLimit = Math.max(
        1,
        Math.min(args.rateLimit, project.requestsPerMinute),
      );
    }
    if (args.scopes !== undefined && args.scopes.length > 0) {
      patch.scopes = args.scopes;
    }
    if (args.expiresAt !== undefined) patch.expiresAt = args.expiresAt;
    if (args.allowedIps !== undefined) patch.allowedIps = args.allowedIps;
    if (args.blockedIps !== undefined) patch.blockedIps = args.blockedIps;
    if (args.allowedOrigins !== undefined) patch.allowedOrigins = args.allowedOrigins;

    if (Object.keys(patch).length > 0) {
      await ctx.db.patch(args.keyId, patch);
      await tryRecord(ctx, {
        event: "key.updated",
        outcome: "success",
        projectId: project._id,
        apiKeyId: key._id,
        detail: Object.keys(patch).join(","),
      });
    }
    return { status: "ok" as const };
  },
});
