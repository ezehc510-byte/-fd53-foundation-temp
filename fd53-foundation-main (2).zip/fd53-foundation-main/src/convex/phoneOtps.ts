import { v } from "convex/values";
import { MAX_OTP_ATTEMPTS } from "./lib/constants";
import { internalMutation, internalQuery } from "./_generated/server";

/** Store a fresh OTP for a phone number (replacing any previous challenge). */
export const create = internalMutation({
  args: {
    projectId: v.id("projects"),
    phone: v.string(),
    codeHash: v.string(),
    expiresAt: v.number(),
  },
  handler: async (ctx, args) => {
    const existing = await ctx.db
      .query("phoneOtps")
      .withIndex("by_phone", (q) =>
        q.eq("projectId", args.projectId).eq("phone", args.phone),
      )
      .collect();
    for (const otp of existing) await ctx.db.delete(otp._id);

    await ctx.db.insert("phoneOtps", {
      projectId: args.projectId,
      phone: args.phone,
      codeHash: args.codeHash,
      expiresAt: args.expiresAt,
      attempts: 0,
    });
    return { status: "ok" as const };
  },
});

/** Latest unconsumed challenge for a phone number. */
export const latest = internalQuery({
  args: { projectId: v.id("projects"), phone: v.string() },
  handler: async (ctx, args) => {
    const otps = await ctx.db
      .query("phoneOtps")
      .withIndex("by_phone", (q) =>
        q.eq("projectId", args.projectId).eq("phone", args.phone),
      )
      .collect();
    const active = otps.filter((o) => !o.consumedAt);
    return active.length > 0 ? active[active.length - 1] : null;
  },
});

/** Record a verification attempt; burns the challenge after MAX_OTP_ATTEMPTS. */
export const recordAttempt = internalMutation({
  args: {
    projectId: v.id("projects"),
    phone: v.string(),
    matched: v.boolean(),
  },
  handler: async (ctx, args) => {
    const otps = await ctx.db
      .query("phoneOtps")
      .withIndex("by_phone", (q) =>
        q.eq("projectId", args.projectId).eq("phone", args.phone),
      )
      .collect();
    const active = otps.filter((o) => !o.consumedAt);
    const otp = active.length > 0 ? active[active.length - 1] : undefined;
    if (!otp) return { status: "not_found" as const, attempts: 0, exhausted: true };

    const attempts = otp.attempts + 1;
    const exhausted = attempts >= MAX_OTP_ATTEMPTS;
    await ctx.db.patch(otp._id, {
      attempts,
      consumedAt: args.matched || exhausted ? Date.now() : undefined,
    });
    return {
      status: "ok" as const,
      attempts,
      exhausted,
      remaining: Math.max(0, MAX_OTP_ATTEMPTS - attempts),
    };
  },
});