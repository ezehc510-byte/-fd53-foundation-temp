/** Client-side helpers for talking about (and with) the FD53 API. */

/** Convex site origin (where the /v1 REST API is served from). */
export function apiOrigin(): string {
  const site = import.meta.env.VITE_CONVEX_SITE_URL as string | undefined;
  if (site) return site.replace(/\/$/, "");

  const deployment = (import.meta.env.VITE_CONVEX_URL as string | undefined) ?? "";
  if (!deployment) return "https://your-deployment.convex.site";
  return deployment.replace(/\.convex\.cloud$/, ".convex.site").replace(/\/$/, "");
}

/** Base URL of the FD53 REST API, e.g. https://abc-123.convex.site/v1 */
export function apiBase(): string {
  return `${apiOrigin()}/v1`;
}

export function formatBytes(bytes: number): string {
  if (!bytes) return "0 B";
  const units = ["B", "KB", "MB", "GB", "TB"];
  const index = Math.min(
    units.length - 1,
    Math.floor(Math.log(bytes) / Math.log(1024)),
  );
  const value = bytes / 1024 ** index;
  return `${value >= 100 || index === 0 ? Math.round(value) : value.toFixed(1)} ${units[index]}`;
}

export function formatNumber(value: number): string {
  return new Intl.NumberFormat().format(value);
}

export function formatDate(ts: number): string {
  return new Date(ts).toLocaleDateString(undefined, {
    month: "short",
    day: "numeric",
    year: "numeric",
  });
}

export function timeAgo(ts: number): string {
  const seconds = Math.max(0, Math.floor((Date.now() - ts) / 1000));
  if (seconds < 60) return `${seconds}s ago`;
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  if (days < 30) return `${days}d ago`;
  return formatDate(ts);
}

export async function copyText(text: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    return false;
  }
}

/** Highlight a JSON-ish value for table cells. */
export function previewValue(value: unknown): string {
  if (value === null || value === undefined) return "—";
  if (typeof value === "object") {
    const text = JSON.stringify(value);
    return text.length > 60 ? `${text.slice(0, 60)}…` : text;
  }
  const text = String(value);
  return text.length > 60 ? `${text.slice(0, 60)}…` : text;
}